
import React, { useState, useEffect } from "react";
import { Contact, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import ContactsTable from "../components/contacts/ContactsTable";
import ContactForm from "../components/contacts/ContactForm";

export default function ContactsPage() {
  const [contacts, setContacts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingContact, setEditingContact] = useState(null);
  const [organizationId, setOrganizationId] = useState(null);

  useEffect(() => {
    const init = async () => {
        try {
            const user = await User.me();
            if (user.organization_id) {
                setOrganizationId(user.organization_id);
                loadContacts(user.organization_id);
            } else {
                console.warn("User has no organization ID.");
                setIsLoading(false);
            }
        } catch(e) {
            console.error("Failed to get user:", e);
            setIsLoading(false);
        }
    }
    init();
  }, []);

  const loadContacts = async (orgId) => {
    if(!orgId) return;
    setIsLoading(true);
    try {
      const data = await Contact.filter({ organization_id: orgId }, "-last_message_date");
      setContacts(data);
    } catch (error) {
      console.error("Error loading contacts:", error);
    }
    setIsLoading(false);
  };

  const handleSave = async (contactData) => {
    if (!organizationId) {
        console.error("Cannot save contact without an organization ID.");
        return;
    }
    try {
      if (editingContact) {
        await Contact.update(editingContact.id, contactData);
      } else {
        await Contact.create({ ...contactData, organization_id: organizationId });
      }
      setShowForm(false);
      setEditingContact(null);
      loadContacts(organizationId);
    } catch (error) {
      console.error("Error saving contact:", error);
    }
  };

  const handleEdit = (contact) => {
    setEditingContact(contact);
    setShowForm(true);
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingContact(null);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Contacts</h1>
          <p className="text-gray-500 mt-1">Manage your WhatsApp contacts and customer information</p>
        </div>
        <Button 
          onClick={() => setShowForm(true)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Contact
        </Button>
      </div>

      {showForm && (
        <div className="mb-8">
          <ContactForm
            contact={editingContact}
            onSave={handleSave}
            onCancel={handleCancel}
          />
        </div>
      )}

      <ContactsTable
        contacts={contacts}
        isLoading={isLoading}
        onEdit={handleEdit}
        onUpdate={() => loadContacts(organizationId)}
      />
    </div>
  );
}
