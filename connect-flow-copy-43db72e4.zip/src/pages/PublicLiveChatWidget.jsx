
import React, { useState, useEffect, useRef, useCallback } from "react";
import { ChannelIntegration } from "@/api/entities";
import { Contact } from "@/api/entities";
import { Conversation } from "@/api/entities";
import { Message } from "@/api/entities";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, Bot, User, X, MessageSquare } from "lucide-react";
import { format } from "date-fns";

export default function LiveChatWidgetPage() {
  const [channelId, setChannelId] = useState(null);
  const [config, setConfig] = useState({ color: "#1e40af", title: "Chat", welcomeMessage: "Hello!" });
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [sessionId, setSessionId] = useState(null);
  const [contactId, setContactId] = useState(null);
  const [conversationId, setConversationId] = useState(null);
  const [organizationId, setOrganizationId] = useState(null);
  const messagesEndRef = useRef(null);

  const fetchAndSetMessages = useCallback(async (convId, welcomeMsg) => {
    let currentMessages = [{ type: "system", content: welcomeMsg, timestamp: new Date(0) }]; // Use Date(0) to ensure welcome message is always first
    if (convId) {
      try {
        // Assuming Message.filter supports sorting by timestamp
        const previousMessages = await Message.filter({ conversation_id: convId }, "timestamp"); 
        // CRITICAL: Filter out internal notes - customers should never see them
        const customerVisibleMessages = previousMessages.filter(m => !m.is_internal);
        const formattedMessages = customerVisibleMessages.map(m => ({
            type: m.direction === 'inbound' ? 'user' : 'system',
            content: m.content,
            timestamp: new Date(m.timestamp)
        }));
        currentMessages = [...currentMessages, ...formattedMessages];
      } catch (error) {
          console.error("Error fetching messages:", error);
          // If fetching fails, we still want to display the welcome message.
      }
    }
    setMessages(currentMessages);
  }, []);

  useEffect(() => {
    // This code runs inside the iframe on the client's website
    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");
    if (!id) return; // Exit early if no ID provided

    setChannelId(id);

    // Get or create a session ID
    let storedSession = localStorage.getItem("livechat_session_id");
    if (!storedSession) {
      storedSession = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem("livechat_session_id", storedSession);
    }
    setSessionId(storedSession);
    
    const storedContactId = localStorage.getItem(`livechat_contact_id_${id}`);
    const storedConversationId = localStorage.getItem(`livechat_conversation_id_${id}`);
    setContactId(storedContactId);
    setConversationId(storedConversationId);

    const loadChannel = async () => {
      try {
        const channel = await ChannelIntegration.get(id);
        const channelConfig = channel.config_data || { color: "#1e40af", title: "Chat", welcomeMessage: "Hello!" };
        setConfig(channelConfig);
        setOrganizationId(channel.organization_id);
        
        // Initial message load using the new fetchAndSetMessages function
        await fetchAndSetMessages(storedConversationId, channelConfig.welcomeMessage);
      } catch (error) {
        console.error("Failed to load channel config", error);
        // Fallback to default welcome message if channel config fails
        await fetchAndSetMessages(storedConversationId, "Hello!");
      }
    };
    loadChannel();
  }, [fetchAndSetMessages]); // Added fetchAndSetMessages to dependencies

  // Add polling for real-time updates
  useEffect(() => {
    const pollInterval = setInterval(() => {
      if (conversationId) { // Only poll if a conversation has started
        fetchAndSetMessages(conversationId, config.welcomeMessage);
      }
    }, 3000); // Poll every 3 seconds

    return () => clearInterval(pollInterval); // Cleanup on component unmount
  }, [conversationId, config.welcomeMessage, fetchAndSetMessages]);


  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);
  
  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !channelId || !organizationId) return;

    const userMessage = { type: "user", content: newMessage, timestamp: new Date() };
    setMessages(prev => [...prev, userMessage]); // Optimistically add user's message
    setNewMessage("");

    try {
      let currentContactId = contactId;
      let currentConversationId = conversationId;
      let conv;

      // 1. Create Contact if it doesn't exist
      if (!currentContactId) {
        const newContact = await Contact.create({
          name: `Visitor ${sessionId.substring(8, 12)}`,
          phone: sessionId, // Using session ID as a unique identifier
          organization_id: organizationId,
          status: "active"
        });
        currentContactId = newContact.id;
        setContactId(newContact.id);
        localStorage.setItem(`livechat_contact_id_${channelId}`, newContact.id);
      }
      
      // 2. Create or get Conversation
      if (!currentConversationId) {
        const newConversation = await Conversation.create({
          contact_id: currentContactId,
          organization_id: organizationId,
          status: "open",
          channel: "livechat", // Set channel for livechat widget
          unread_count: 1
        });
        currentConversationId = newConversation.id;
        conv = newConversation;
        setConversationId(newConversation.id);
        localStorage.setItem(`livechat_conversation_id_${channelId}`, newConversation.id);
      } else {
        conv = await Conversation.get(currentConversationId); // Fetch existing conversation
      }
      
      // 3. Create the Message
      const messageData = {
        conversation_id: currentConversationId,
        content: newMessage,
        direction: "inbound",
        status: "delivered",
        organization_id: organizationId,
        timestamp: new Date().toISOString()
      };
      await Message.create(messageData);
      
      // 4. Update conversation: Re-open if concluded, or increment unread count
      if(currentConversationId) {
          const updatePayload = { 
            last_message_content: newMessage,
            last_message_date: messageData.timestamp
          };

          if (conv.status === 'concluded') {
            // Re-open the conversation and move to "Novos"
            updatePayload.status = 'open';
            updatePayload.assigned_to = null;
            updatePayload.unread_count = 1;
          } else {
            // Just increment unread count for an active conversation
            updatePayload.unread_count = (conv.unread_count || 0) + 1;
          }
          
          await Conversation.update(currentConversationId, updatePayload);
      }

    } catch (error) {
      console.error("Error sending message:", error);
      const errorMessage = { type: 'system', content: 'Could not send message. Please try again later.', timestamp: new Date() };
      setMessages(prev => [...prev, errorMessage]);
    }
  };
  
  const handleCloseWidget = () => {
    // Send a message to the parent window (the one with Layout.js) to close the widget
    window.parent.postMessage('hootspy-close-widget', '*');
  };

  return (
    <div style={{ height: '100%', width: '100%', display: 'flex', flexDirection: 'column', fontFamily: 'system-ui, -apple-system, sans-serif', backgroundColor: 'white', overflow: 'hidden', position: 'relative' }}>
      <style>{`
        html, body, #base44-root-render-node { 
          height: 100%;
          margin: 0; 
          padding: 0;
          overflow: hidden;
        }
        * {
          box-sizing: border-box;
        }
      `}</style>
      
      {/* Header - Fixed at top */}
      <div 
        style={{ 
          backgroundColor: config.color,
          color: 'white',
          padding: '12px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          flexShrink: 0,
          minHeight: '56px',
          position: 'relative',
          zIndex: 10
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ 
            width: '32px', 
            height: '32px', 
            backgroundColor: 'rgba(255,255,255,0.2)', 
            borderRadius: '50%', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            flexShrink: 0
          }}>
            <MessageSquare style={{ width: '16px', height: '16px' }}/>
          </div>
          <div style={{ minWidth: 0 }}>
            <h3 style={{ fontWeight: 'bold', fontSize: '14px', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {config.title}
            </h3>
            <p style={{ fontSize: '12px', opacity: 0.8, margin: 0, overflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              We typically reply in a few minutes
            </p>
          </div>
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={handleCloseWidget}
          className="text-white hover:bg-white/20 h-8 w-8 rounded-full"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>
      
      {/* Messages Area - Scrollable with bottom padding */}
      <div style={{ 
        position: 'absolute',
        top: '56px', // Height of header
        left: 0,
        right: 0,
        bottom: '72px', // Height of footer + padding
        padding: '12px',
        overflowY: 'auto',
        backgroundColor: '#f8fafc'
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', paddingBottom: '12px' }}>
          {messages.map((msg, index) => (
            <div key={index} style={{ 
              display: 'flex', 
              gap: '8px', 
              alignItems: 'flex-end',
              justifyContent: msg.type === 'user' ? 'flex-end' : 'flex-start'
            }}>
              {msg.type !== 'user' && (
                <div style={{ 
                  width: '24px', 
                  height: '24px', 
                  borderRadius: '50%', 
                  backgroundColor: '#e5e7eb', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  flexShrink: 0
                }}>
                  <Bot style={{ width: '12px', height: '12px', color: '#6b7280' }} />
                </div>
              )}
              <div style={{
                padding: '10px',
                borderRadius: '16px',
                boxShadow: '0 1px 2px rgba(0,0,0,0.1)',
                maxWidth: '220px',
                fontSize: '14px',
                backgroundColor: msg.type === 'user' ? (config.color || '#2563eb') : 'white',
                color: msg.type === 'user' ? 'white' : '#1f2937'
              }}>
                <p style={{ margin: 0, lineHeight: 1.4 }}>{msg.content}</p>
                <p style={{ 
                  fontSize: '12px', 
                  marginTop: '4px', 
                  margin: 0,
                  color: msg.type === 'user' ? 'rgba(255,255,255,0.7)' : '#9ca3af'
                }}>
                  {format(msg.timestamp, "h:mm a")}
                </p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Footer with Input - Fixed at bottom */}
      <div style={{ 
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        padding: '12px',
        borderTop: '1px solid #e5e7eb',
        backgroundColor: 'white',
        zIndex: 10
      }}>
        <form onSubmit={handleSendMessage} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            style={{
              flex: 1,
              height: '36px',
              borderRadius: '18px',
              backgroundColor: '#f1f5f9',
              border: 'transparent',
              fontSize: '14px',
              paddingLeft: '12px',
              paddingRight: '12px'
            }}
            autoFocus
          />
          <Button 
            type="submit" 
            size="icon" 
            style={{
              borderRadius: '50%',
              width: '36px',
              height: '36px',
              backgroundColor: config.color || '#2563eb',
              flexShrink: 0
            }}
            className="hover:bg-blue-700"
          >
            <Send style={{ width: '16px', height: '16px' }} />
          </Button>
        </form>
      </div>
    </div>
  );
}
