
import React, { useState, useEffect, useCallback } from "react";
import { Contact } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  Users, 
  TrendingUp, 
  DollarSign, 
  Calendar,
  Search,
  Filter,
  MoreHorizontal
} from "lucide-react";
import { Input } from "@/components/ui/input";

// Mock CRM stages - these will become dynamic in the future
const crmStages = [
  { id: "lead", name: "Leads", color: "bg-gray-100", count: 0 },
  { id: "contact", name: "Contacted", color: "bg-blue-100", count: 0 },
  { id: "qualified", name: "Qualified", color: "bg-yellow-100", count: 0 },
  { id: "proposal", name: "Proposal", color: "bg-orange-100", count: 0 },
  { id: "negotiation", name: "Negotiation", color: "bg-purple-100", count: 0 },
  { id: "closed-won", name: "Closed Won", color: "bg-green-100", count: 0 },
  { id: "closed-lost", name: "Closed Lost", color: "bg-red-100", count: 0 }
];

export default function CRMPage() {
  const [contacts, setContacts] = useState([]);
  const [stages, setStages] = useState(crmStages);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [organizationId, setOrganizationId] = useState(null);

  const loadContacts = useCallback(async (orgId) => {
    if (!orgId) return;
    setIsLoading(true);
    try {
      const data = await Contact.filter({ organization_id: orgId }, "-last_message_date");
      setContacts(data);
      
      // Update stage counts based on contacts (for now, all contacts go to "Leads")
      // Ensure 'stages' state is the latest when this callback runs.
      const updatedStages = stages.map(stage => ({
        ...stage,
        count: stage.id === "lead" ? data.length : 0
      }));
      setStages(updatedStages);
    } catch (error) {
      console.error("Error loading contacts:", error);
    }
    setIsLoading(false);
  }, [stages, setContacts, setIsLoading, setStages]); // Added stages as a dependency because it's used inside the callback. State setters are stable.

  useEffect(() => {
    const init = async () => {
      try {
        const user = await User.me();
        if (user.organization_id) {
          setOrganizationId(user.organization_id);
          loadContacts(user.organization_id);
        } else {
          setIsLoading(false);
        }
      } catch (e) {
        console.error("Error loading user data:", e);
        setIsLoading(false);
      }
    };
    init();
  }, [loadContacts, setIsLoading, setOrganizationId]); // Added loadContacts as a dependency because it's called inside init. State setters are stable.

  const filteredContacts = contacts.filter(contact =>
    contact.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.phone?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">CRM Dashboard</h1>
          <p className="text-gray-500 mt-1">Manage your customer relationships and sales pipeline</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filters
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Deal
          </Button>
        </div>
      </div>

      {/* CRM Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Contacts</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{contacts.length}</div>
            <p className="text-xs text-muted-foreground">Active in pipeline</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Deals</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0</div>
            <p className="text-xs text-muted-foreground">Coming soon</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$0</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0%</div>
            <p className="text-xs text-muted-foreground">Lead to customer</p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <div className="mb-6">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search contacts and deals..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Kanban Board */}
      <div className="grid grid-cols-1 xl:grid-cols-7 gap-6 min-h-[600px]">
        {stages.map((stage) => (
          <Card key={stage.id} className="flex flex-col">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">{stage.name}</CardTitle>
                <Badge variant="secondary" className="text-xs">
                  {stage.count}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="space-y-3">
                {stage.id === "lead" && filteredContacts.map((contact) => (
                  <Card key={contact.id} className="p-3 cursor-pointer hover:shadow-md transition-shadow">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium text-sm">{contact.name}</h4>
                        <Button variant="ghost" size="icon" className="h-6 w-6">
                          <MoreHorizontal className="w-3 h-3" />
                        </Button>
                      </div>
                      <p className="text-xs text-gray-500">{contact.phone}</p>
                      {contact.company && (
                        <p className="text-xs text-gray-600">{contact.company}</p>
                      )}
                      <div className="flex gap-1 flex-wrap">
                        {contact.tags?.slice(0, 2).map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </Card>
                ))}
                
                {stage.id !== "lead" && (
                  <div className="text-center py-8 text-gray-400">
                    <TrendingUp className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No deals in this stage</p>
                    <p className="text-xs">Drag contacts here to add them</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Future Features Notice */}
      <Card className="mt-8 border-blue-200 bg-blue-50">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-blue-900 mb-2">Coming Soon: Full CRM Features</h3>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Drag & drop deals between stages</li>
                <li>• Deal value tracking and revenue forecasting</li>
                <li>• Task management and follow-up reminders</li>
                <li>• Custom pipeline stages and workflows</li>
                <li>• Sales performance analytics and reporting</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
