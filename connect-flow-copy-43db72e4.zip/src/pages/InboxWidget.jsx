import React, { useState, useEffect, useCallback } from "react";
import { Message } from "@/api/entities";
import { MessageCircle, AlertCircle } from "lucide-react";
import ConversationList from "../components/inbox/ConversationList";
import ChatView from "../components/inbox/ChatView";
import ContactInfo from "../components/inbox/ContactInfo";
import { widgetAuth } from "@/api/functions";
import { widgetMessages } from "@/api/functions";

// This is a self-contained version of the Inbox, designed to be run inside an iframe.
// It uses API key authentication instead of user session authentication.
export default function InboxWidgetPage() {
  // State for the widget
  const [conversations, setConversations] = useState([]);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [showContactInfo, setShowContactInfo] = useState(false);
  const [error, setError] = useState(null);
  
  // Config from URL
  const [organizationId, setOrganizationId] = useState(null);
  const [groupId, setGroupId] = useState(null);
  const [apiKey, setApiKey] = useState(null);

  // Load data using API key authentication
  const authenticateAndLoad = useCallback(async (orgId, groupIdParam, key) => {
    if (!orgId || !key) {
      setError("Missing required parameters: organizationId and apiKey");
      setIsLoading(false);
      return;
    }
    
    setIsLoading(true);
    setError(null);
    
    try {
      // Call the backend function to validate API key and fetch data
      const response = await widgetAuth({
        apiKey: key,
        organizationId: orgId,
        groupId: groupIdParam
      });

      if (response.data.error) {
        setError(response.data.error);
        setIsLoading(false);
        return;
      }

      const { conversations: conversationsData, contacts: contactsData } = response.data;

      setConversations(conversationsData || []);
      setContacts(contactsData || []);

    } catch (error) {
      console.error("Error loading widget data:", error);
      setError("Failed to load inbox data. Please check your API key and try again.");
    }
    
    setIsLoading(false);
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const orgId = params.get('organizationId');
    const groupIdParam = params.get('groupId');
    const key = params.get('apiKey');

    setOrganizationId(orgId);
    setGroupId(groupIdParam);
    setApiKey(key);
    
    authenticateAndLoad(orgId, groupIdParam, key);
  }, [authenticateAndLoad]);

  const loadMessages = useCallback(async (conversationId) => {
    if (!organizationId || !apiKey) return;
    
    setIsLoadingMessages(true);
    try {
      const response = await widgetMessages({
        apiKey,
        organizationId,
        conversationId
      });

      if (response.data.error) {
        console.error("Error loading messages:", response.data.error);
        setMessages([]);
      } else {
        setMessages(response.data.messages || []);
      }
    } catch (error) {
      console.error("Error loading messages:", error);
      setMessages([]);
    } finally {
      setIsLoadingMessages(false);
    }
  }, [organizationId, apiKey]);

  const handleConversationSelect = (conversation) => {
    if (selectedConversation?.id === conversation.id) return;
    setSelectedConversation(conversation);
    setMessages([]);
    loadMessages(conversation.id);
  };
  
  const getContactForConversation = (conversationId) => {
    const conversation = conversations.find(c => c.id === conversationId);
    return contacts.find(c => c.id === conversation?.contact_id);
  };
  
  const sendMessage = async (content) => {
     if (!selectedConversation || !organizationId) return;
     // This would require another backend function to send messages
     console.log("Sending message (not implemented yet):", content);
  };

  const sendInternalNote = async (content) => {
     if (!selectedConversation || !organizationId) return;
     console.log("Sending internal note (not implemented yet):", content);
  };

  // Error state
  if (error) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-gray-50">
        <div className="text-center max-w-md p-6">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Authentication Error</h3>
          <p className="text-sm text-gray-600 mb-4">{error}</p>
          <p className="text-xs text-gray-500">Please check your API key and organization ID.</p>
        </div>
      </div>
    );
  }

  // Loading state
  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center text-gray-500">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p>Loading Inbox...</p>
        </div>
      </div>
    );
  }
  
  // Empty state - no channels in group
  if (groupId && conversations.length === 0) {
    return (
      <div className="flex h-screen w-full items-center justify-center text-gray-500">
        <div className="text-center">
          <MessageCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <h3 className="text-lg font-medium text-gray-700">No Channels Found</h3>
          <p className="text-sm text-gray-500 mt-1">Group ID: {groupId}</p>
          <p className="text-xs text-gray-400 mt-2">No channels are configured for this group.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-full flex bg-white overflow-hidden font-sans">
      <style>{`
        /* Minimal reset for iframe */
        html, body, #base44-root-render-node { 
          height: 100%;
          margin: 0; 
          padding: 0;
          overflow: hidden;
          font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji';
          font-size: 14px;
        }
      `}</style>
      
      <div className="w-80 border-r border-gray-200 flex flex-col">
        <ConversationList
          conversations={conversations}
          contacts={contacts}
          selectedConversation={selectedConversation}
          onConversationSelect={handleConversationSelect}
          isLoading={false}
          currentUser={null}
        />
      </div>

      <div className="flex-1 flex flex-col">
        {selectedConversation ? (
          <ChatView
            conversation={selectedConversation}
            contact={getContactForConversation(selectedConversation.id)}
            messages={messages}
            isLoadingMessages={isLoadingMessages}
            onSendMessage={sendMessage}
            onSendInternalNote={sendInternalNote}
            onToggleContactInfo={() => setShowContactInfo(!showContactInfo)}
            onStartConversation={()=>{}}
            onFinishConversation={()=>{}}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center bg-gray-50">
            <div className="text-center">
              <MessageCircle className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <h3 className="text-lg font-medium text-gray-900">Hootspy Inbox</h3>
              <p className="text-gray-500">Select a conversation to begin.</p>
              {groupId && (
                <p className="text-xs text-gray-400 mt-2">Group: {groupId}</p>
              )}
            </div>
          </div>
        )}
      </div>
      
      {showContactInfo && selectedConversation && (
        <div className="w-80 border-l border-gray-200">
          <ContactInfo
            contact={getContactForConversation(selectedConversation.id)}
            conversation={selectedConversation}
            onClose={() => setShowContactInfo(false)}
            onContactUpdate={()=>{}}
          />
        </div>
      )}
    </div>
  );
}