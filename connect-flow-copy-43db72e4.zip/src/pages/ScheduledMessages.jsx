import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Calendar,
  Clock,
  Search,
  MessageSquare,
  User as UserIcon,
  Send,
  Pause,
  Play,
  Trash2,
  Plus
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";

// Mock scheduled messages data - will be replaced with real data later
const mockScheduledMessages = [
  {
    id: 1,
    contactName: "John Doe",
    contactPhone: "+1234567890",
    message: "Hi John, just following up on our conversation about the new product launch...",
    scheduledDate: "2024-01-15T14:30:00Z",
    status: "scheduled",
    channel: "whatsapp",
    template: "Follow-up Template"
  },
  {
    id: 2,
    contactName: "Sarah Wilson",
    contactPhone: "+1987654321",
    message: "Hello Sarah, your appointment is confirmed for tomorrow at 3 PM.",
    scheduledDate: "2024-01-16T10:00:00Z",
    status: "scheduled",
    channel: "sms",
    template: "Appointment Reminder"
  },
  {
    id: 3,
    contactName: "Mike Johnson",
    contactPhone: "+1122334455",
    message: "Thank you for your purchase! Your order will be shipped soon.",
    scheduledDate: "2024-01-14T09:15:00Z",
    status: "sent",
    channel: "whatsapp",
    template: "Order Confirmation"
  }
];

export default function ScheduledMessagesPage() {
  const [scheduledMessages, setScheduledMessages] = useState(mockScheduledMessages);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [isLoading, setIsLoading] = useState(false);
  const [organizationId, setOrganizationId] = useState(null);

  useEffect(() => {
    const init = async () => {
      try {
        const user = await User.me();
        if (user.organization_id) {
          setOrganizationId(user.organization_id);
          // TODO: Load real scheduled messages from database
          // loadScheduledMessages(user.organization_id);
        }
      } catch (e) {
        console.error("Error loading user data:", e);
      }
    };
    init();
  }, []);

  const filteredMessages = scheduledMessages.filter(message => {
    const matchesSearch = 
      message.contactName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      message.contactPhone.includes(searchQuery) ||
      message.message.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || message.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'sent': return 'bg-green-100 text-green-800';
      case 'paused': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getChannelIcon = (channel) => {
    switch (channel) {
      case 'whatsapp': return <MessageSquare className="w-4 h-4 text-green-600" />;
      case 'sms': return <MessageSquare className="w-4 h-4 text-blue-600" />;
      case 'email': return <Send className="w-4 h-4 text-purple-600" />;
      default: return <MessageSquare className="w-4 h-4 text-gray-600" />;
    }
  };

  const upcomingCount = scheduledMessages.filter(msg => msg.status === 'scheduled').length;
  const sentCount = scheduledMessages.filter(msg => msg.status === 'sent').length;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Scheduled Messages</h1>
          <p className="text-gray-500 mt-1">Manage your future automated communications</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Schedule Message
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Messages</CardTitle>
            <Clock className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{upcomingCount}</div>
            <p className="text-xs text-muted-foreground">Ready to be sent</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sent Today</CardTitle>
            <Send className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{sentCount}</div>
            <p className="text-xs text-muted-foreground">Successfully delivered</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Scheduled</CardTitle>
            <Calendar className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{scheduledMessages.length}</div>
            <p className="text-xs text-muted-foreground">All time</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search messages, contacts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="flex gap-2">
              {["all", "scheduled", "sent", "paused", "failed"].map((status) => (
                <Button
                  key={status}
                  variant={statusFilter === status ? "default" : "outline"}
                  size="sm"
                  onClick={() => setStatusFilter(status)}
                  className="capitalize"
                >
                  {status}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Messages Table */}
      <Card>
        <CardHeader>
          <CardTitle>Scheduled Messages</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredMessages.length === 0 ? (
            <div className="text-center py-12">
              <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {searchQuery || statusFilter !== "all" 
                  ? "No messages found" 
                  : "No scheduled messages yet"
                }
              </h3>
              <p className="text-gray-500 mb-6">
                {searchQuery || statusFilter !== "all"
                  ? "Try adjusting your search or filters"
                  : "Schedule your first message to automate customer communications"
                }
              </p>
              {!(searchQuery || statusFilter !== "all") && (
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Schedule Your First Message
                </Button>
              )}
            </div>
          ) : (
            <div className="border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Contact</TableHead>
                    <TableHead>Message Preview</TableHead>
                    <TableHead>Scheduled Time</TableHead>
                    <TableHead>Channel</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-[100px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMessages.map((message) => (
                    <TableRow key={message.id} className="hover:bg-gray-50">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                            <UserIcon className="w-5 h-5 text-gray-600" />
                          </div>
                          <div>
                            <div className="font-medium">{message.contactName}</div>
                            <div className="text-sm text-gray-500">{message.contactPhone}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="max-w-xs">
                        <div className="truncate text-sm">
                          {message.message.substring(0, 60)}...
                        </div>
                        {message.template && (
                          <div className="text-xs text-gray-500 mt-1">
                            Template: {message.template}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <div className="text-sm">
                            {format(new Date(message.scheduledDate), "MMM dd, yyyy 'at' h:mm a")}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getChannelIcon(message.channel)}
                          <span className="capitalize">{message.channel}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(message.status)}>
                          {message.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              Actions
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {message.status === 'scheduled' && (
                              <>
                                <DropdownMenuItem>
                                  <Pause className="w-4 h-4 mr-2" />
                                  Pause
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Send className="w-4 h-4 mr-2" />
                                  Send Now
                                </DropdownMenuItem>
                              </>
                            )}
                            {message.status === 'paused' && (
                              <DropdownMenuItem>
                                <Play className="w-4 h-4 mr-2" />
                                Resume
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem className="text-red-600">
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Future Features Notice */}
      <Card className="mt-8 border-blue-200 bg-blue-50">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <Calendar className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-blue-900 mb-2">Coming Soon: Advanced Scheduling</h3>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Recurring message campaigns</li>
                <li>• Time zone-aware scheduling</li>
                <li>• A/B testing for scheduled messages</li>
                <li>• Conditional scheduling based on contact behavior</li>
                <li>• Bulk scheduling for multiple contacts</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}