
import React, { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { ChannelIntegration, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Save, Copy, Check, Palette, MessageSquare, Bot, Globe } from "lucide-react";
import { createPageUrl } from "@/utils";

// This is the public facing widget component that would be loaded in an iframe
const LiveWidgetPreview = ({ color, title, welcomeMessage }) => {
  return (
    <div className="flex flex-col h-full w-full rounded-lg shadow-2xl bg-white overflow-hidden">
      <div style={{ backgroundColor: color }} className="p-4 text-white">
        <h3 className="font-bold text-lg">{title}</h3>
      </div>
      <div className="flex-1 p-4 space-y-4 bg-gray-50">
        <div className="flex gap-2 items-end">
          <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center">
            <Bot className="w-5 h-5 text-gray-600" />
          </div>
          <div className="p-3 rounded-2xl bg-white shadow-sm max-w-xs">
            <p className="text-sm text-gray-800">{welcomeMessage}</p>
          </div>
        </div>
      </div>
      <div className="p-2 border-t bg-white">
        <Input placeholder="Type your message..." className="text-sm" />
      </div>
    </div>
  );
};

export default function CreateLiveChatWidgetPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const editingChannelId = searchParams.get("id");

  const [formData, setFormData] = useState({
    name: "Website Live Chat",
    header_title: "Chat with us!",
    welcome_message: "Hello! How can we help you today?",
    primary_color: "#1e40af",
  });
  const [organizationId, setOrganizationId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [createdChannel, setCreatedChannel] = useState(null);

  useEffect(() => {
    const init = async () => {
      try {
        const user = await User.me();
        setOrganizationId(user.organization_id);
        
        if (editingChannelId) {
          setIsLoading(true);
          const channel = await ChannelIntegration.get(editingChannelId);
          setCreatedChannel(channel); // Used to show the script block
          setFormData({
            name: channel.name,
            header_title: channel.config_data.title,
            welcome_message: channel.config_data.welcomeMessage,
            primary_color: channel.config_data.color,
          });
          setIsLoading(false);
        }
      } catch (error) {
        console.error("Error loading initial data:", error);
        setIsLoading(false);
      }
    };
    init();
  }, [editingChannelId]);

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };
  
  const handleSave = async () => {
    if (!formData.name || !organizationId) {
      alert("Please provide a name for the widget.");
      return;
    }
    
    setIsLoading(true);
    try {
      const channelData = {
        name: formData.name,
        channel_type: "livechat",
        organization_id: organizationId,
        status: "connected",
        config_data: {
          title: formData.header_title,
          welcomeMessage: formData.welcome_message,
          color: formData.primary_color,
        },
      };

      if (editingChannelId) {
        const updatedChannel = await ChannelIntegration.update(editingChannelId, channelData);
        setCreatedChannel(updatedChannel);
        alert("Widget updated successfully!");
      } else {
        const newChannel = await ChannelIntegration.create(channelData);
        setCreatedChannel(newChannel);
      }
    } catch (error) {
      console.error("Error saving live chat widget:", error);
      alert("Failed to save widget. Please try again.");
    }
    setIsLoading(false);
  };
  
  const handleCopy = () => {
    const scriptText = document.getElementById("widget-script-code")?.innerText;
    if (scriptText) {
      navigator.clipboard.writeText(scriptText);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  const getScriptContent = (channelId) => {
    const iframeSrc = `${window.location.origin}${createPageUrl(`PublicLiveChatWidget?id=${channelId}`)}`;

    // This function now generates a full, self-contained script
    const scriptLogic = `
    (function() {
      const channelId = '${channelId}';
      if (document.getElementById('hootspy-widget-container')) return;

      const widgetContainer = document.createElement('div');
      widgetContainer.id = 'hootspy-widget-container';
      document.body.appendChild(widgetContainer);

      const style = document.createElement('style');
      style.innerHTML = \`
        #hootspy-widget-container {
          position: fixed;
          bottom: 20px;
          right: 20px;
          width: 60px;
          height: 60px;
          z-index: 999999;
          transition: all 0.3s ease;
        }
        #hootspy-widget-container.open {
          width: 370px;
          height: 70vh;
          max-height: 700px;
        }
        #hootspy-widget-iframe {
          width: 100%;
          height: 100%;
          border: none;
          border-radius: 15px;
          box-shadow: 0 10px 25px -5px rgba(0,0,0,0.2), 0 5px 10px -5px rgba(0,0,0,0.1);
        }
        #hootspy-widget-bubble {
          position: absolute;
          bottom: 0;
          right: 0;
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background-color: #1e40af;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          box-shadow: 0 4px 8px rgba(0,0,0,0.2);
          transition: all 0.3s ease;
        }
        #hootspy-widget-bubble svg {
            width: 30px;
            height: 30px;
        }
      \`;
      document.head.appendChild(style);

      const iframe = document.createElement('iframe');
      iframe.id = 'hootspy-widget-iframe';
      iframe.src = '${iframeSrc}';
      iframe.style.display = 'none';
      
      const chatBubble = document.createElement('div');
      chatBubble.id = 'hootspy-widget-bubble';
      const bubbleIconOpen = \`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"></path></svg>\`;
      const bubbleIconClose = \`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>\`;
      chatBubble.innerHTML = bubbleIconOpen;
      
      widgetContainer.appendChild(chatBubble);
      widgetContainer.appendChild(iframe);

      function toggleWidget() {
        widgetContainer.classList.toggle('open');
        const isOpen = widgetContainer.classList.contains('open');
        if (isOpen) {
          iframe.style.display = 'block';
          chatBubble.innerHTML = bubbleIconClose;
        } else {
          iframe.style.display = 'none';
          chatBubble.innerHTML = bubbleIconOpen;
        }
      }

      chatBubble.addEventListener('click', toggleWidget);
      
      window.addEventListener('message', function(event) {
          if (event.data === 'hootspy-close-widget') {
              toggleWidget();
          }
      });

      // We need to fetch the channel data from the parent app's domain
      fetch('${window.location.origin}/api/entities/ChannelIntegration/records/' + channelId)
        .then(response => response.json())
        .then(data => {
          if(data && data.config_data && data.config_data.color) {
            chatBubble.style.backgroundColor = data.config_data.color;
          }
        })
        .catch(console.error);
    })();
    `;
    return `<script>${scriptLogic}</script>`;
  };
  
  const pageTitle = editingChannelId ? "Configure Live Chat Widget" : "Create Live Chat Widget";
  const pageDescription = editingChannelId ? "Edit your widget settings and copy the installation code." : "Customize and set up your new website chat widget.";
  const buttonText = editingChannelId ? "Save Changes" : "Create and Get Code";

  // This success view is now shown after creation, not just on a separate screen.
  const SuccessAndInstallView = ({ channel }) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="w-5 h-5 text-green-600" />
          Installation Code
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-gray-600 mb-4">
          Copy the code below and paste it just before the `&lt;/body&gt;` tag on your website.
        </p>
        <div className="bg-gray-900 text-white p-4 rounded-lg font-mono text-sm relative">
          <pre><code id="widget-script-code">{getScriptContent(channel.id)}</code></pre>
          <Button
            size="sm"
            variant="secondary"
            onClick={handleCopy}
            className="absolute top-2 right-2"
          >
            {isCopied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
            {isCopied ? "Copied!" : "Copy"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex items-center gap-4 mb-8">
        <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Settings"))}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{pageTitle}</h1>
          <p className="text-gray-500">{pageDescription}</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Side: Configuration */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Widget Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="e.g. Main Website Chat"
                />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Palette className="w-5 h-5" />Appearance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="header_title">Header Title</Label>
                <Input
                  id="header_title"
                  value={formData.header_title}
                  onChange={(e) => handleInputChange("header_title", e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="welcome_message">Welcome Message</Label>
                <Input
                  id="welcome_message"
                  value={formData.welcome_message}
                  onChange={(e) => handleInputChange("welcome_message", e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="primary_color">Primary Color</Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="color"
                    className="w-12 h-10 p-1"
                    value={formData.primary_color}
                    onChange={(e) => handleInputChange("primary_color", e.target.value)}
                  />
                  <Input
                    value={formData.primary_color}
                    onChange={(e) => handleInputChange("primary_color", e.target.value)}
                    placeholder="#1e40af"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          
          {createdChannel && <SuccessAndInstallView channel={createdChannel} />}

          <div className="flex justify-end">
            <Button onClick={handleSave} disabled={isLoading}>
              <Save className="w-4 h-4 mr-2" />
              {isLoading ? "Saving..." : buttonText}
            </Button>
          </div>
        </div>

        {/* Right Side: Preview */}
        <div>
          <Label className="text-lg font-semibold mb-2 block">Live Preview</Label>
          <div className="aspect-[9/16] max-h-[70vh] relative">
            <LiveWidgetPreview
              color={formData.primary_color}
              title={formData.header_title}
              welcomeMessage={formData.welcome_message}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
