import Layout from "./Layout.jsx";

import Inbox from "./Inbox";

import Contacts from "./Contacts";

import ContactProfile from "./ContactProfile";

import Settings from "./Settings";

import Campaigns from "./Campaigns";

import CreateMessageTemplate from "./CreateMessageTemplate";

import CreateLiveChatWidget from "./CreateLiveChatWidget";

import PublicLiveChatWidget from "./PublicLiveChatWidget";

import CRM from "./CRM";

import ScheduledMessages from "./ScheduledMessages";

import Test from "./Test";

import InboxWidget from "./InboxWidget";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Inbox: Inbox,
    
    Contacts: Contacts,
    
    ContactProfile: ContactProfile,
    
    Settings: Settings,
    
    Campaigns: Campaigns,
    
    CreateMessageTemplate: CreateMessageTemplate,
    
    CreateLiveChatWidget: CreateLiveChatWidget,
    
    PublicLiveChatWidget: PublicLiveChatWidget,
    
    CRM: CRM,
    
    ScheduledMessages: ScheduledMessages,
    
    Test: Test,
    
    InboxWidget: InboxWidget,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Inbox />} />
                
                
                <Route path="/Inbox" element={<Inbox />} />
                
                <Route path="/Contacts" element={<Contacts />} />
                
                <Route path="/ContactProfile" element={<ContactProfile />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Campaigns" element={<Campaigns />} />
                
                <Route path="/CreateMessageTemplate" element={<CreateMessageTemplate />} />
                
                <Route path="/CreateLiveChatWidget" element={<CreateLiveChatWidget />} />
                
                <Route path="/PublicLiveChatWidget" element={<PublicLiveChatWidget />} />
                
                <Route path="/CRM" element={<CRM />} />
                
                <Route path="/ScheduledMessages" element={<ScheduledMessages />} />
                
                <Route path="/Test" element={<Test />} />
                
                <Route path="/InboxWidget" element={<InboxWidget />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}