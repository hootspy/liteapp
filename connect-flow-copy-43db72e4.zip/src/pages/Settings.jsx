import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import {
  Users,
  UserIcon,
  Globe,
  Settings as SettingsIcon,
  Crown,
  Code
} from "lucide-react";
import UserManagement from "../components/settings/UserManagement";
import AccountManagement from "../components/settings/AccountManagement";
import ChannelManagement from "../components/settings/ChannelManagement";
import SuperAdminPanel from "../components/settings/SuperAdminPanel";
import SDKManagement from "../components/settings/SDKManagement";

export default function SettingsPage() {
  const [activeSection, setActiveSection] = useState("users");
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadCurrentUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Error loading current user:", error);
      }
      setIsLoading(false);
    };
    loadCurrentUser();
  }, []);

  if (isLoading) {
    return <div className="flex h-full items-center justify-center">Loading...</div>;
  }

  const baseSections = [
    { id: "users", icon: Users, label: "Users", component: UserManagement },
    { id: "account", icon: UserIcon, label: "Account", component: AccountManagement },
    { id: "channels", icon: Globe, label: "Channels", component: ChannelManagement },
    { id: "sdk", icon: Code, label: "SDK", component: SDKManagement }
  ];

  // Add Super Admin section only for platform_admin users
  const sections = currentUser?.role === 'platform_admin'
    ? [
        { id: "super-admin", icon: Crown, label: "Super Admin", component: SuperAdminPanel },
        ...baseSections
      ]
    : baseSections;

  const ActiveComponent = sections.find(section => section.id === activeSection)?.component;

  return (
    <div className="flex h-full bg-gray-50">
      {/* Settings Navigation Sidebar */}
      <div className="w-64 bg-white border-r border-gray-200 flex-shrink-0">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <SettingsIcon className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-gray-900">Settings</h2>
              <p className="text-sm text-gray-500">Manage your workspace</p>
            </div>
          </div>
        </div>

        <nav className="p-4">
          <ul className="space-y-2">
            {sections.map((section) => {
              const Icon = section.icon;
              const isSuperAdmin = section.id === "super-admin";
              return (
                <li key={section.id}>
                  <button
                    onClick={() => setActiveSection(section.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                      activeSection === section.id
                        ? isSuperAdmin
                          ? "bg-red-50 text-red-700 border border-red-200"
                          : "bg-blue-50 text-blue-700 border border-blue-200"
                        : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${isSuperAdmin ? 'text-red-600' : ''}`} />
                    <span className="font-medium">{section.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto">
        {ActiveComponent && <ActiveComponent currentUser={currentUser} />}
      </div>
    </div>
  );
}