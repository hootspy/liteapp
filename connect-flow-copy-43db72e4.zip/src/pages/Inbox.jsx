
import React, { useState, useEffect, useCallback } from "react";
import { Conversation } from "@/api/entities";
import { Contact } from "@/api/entities";
import { Message } from "@/api/entities";
import { Organization } from "@/api/entities";
import { User } from "@/api/entities";
import { MessageCircle } from "lucide-react";
import ConversationList from "../components/inbox/ConversationList";
import ChatView from "../components/inbox/ChatView";
import ContactInfo from "../components/inbox/ContactInfo";

export default function InboxPage() {
  const [conversations, setConversations] = useState([]);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false); // Add loading state for messages
  const [showContactInfo, setShowContactInfo] = useState(false);
  const [organizationId, setOrganizationId] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  const loadData = useCallback(async (orgId, isSilentRefresh = false) => {
    if (!orgId) return;
    if (!isSilentRefresh) setIsLoading(true);
    try {
      let [conversationsData, contactsData] = await Promise.all([
        Conversation.filter({ organization_id: orgId }, "-last_message_date"), // Assuming Conversation entity now has last_message_date
        Contact.filter({ organization_id: orgId }),
      ]);

      const contactsById = contactsData.reduce((acc, contact) => {
        acc[contact.id] = contact;
        return acc;
      }, {});
      const hasLinkedConversations = conversationsData.some(conv => contactsById[conv.contact_id]);

      // Only create demo data on the initial load, not on silent refreshes
      if (!isSilentRefresh && !hasLinkedConversations && contactsData.length === 0) {
        console.log("Creating demo data for new organization...");
        const sampleContacts = await Contact.bulkCreate([
            { name: "Brenda Smith", phone: "+15551234567", organization_id: orgId, tags: ['Lead'] },
            { name: "John Doe", phone: "+15559876543", organization_id: orgId, tags: ['VIP'] }
        ]);
        
        const convPromises = sampleContacts.map((contact, index) => {
          return Conversation.create({
            contact_id: contact.id,
            status: "open",
            channel: index === 0 ? "whatsapp" : "livechat", // Mix channels for demo
            priority: "normal",
            unread_count: Math.floor(Math.random() * 3) + 1,
            organization_id: orgId
          });
        });
        
        const newConversations = await Promise.all(convPromises);

        const messagePromises = newConversations.flatMap((conv, index) => [
          Message.create({
            conversation_id: conv.id,
            content: `Hello! This is a sample message for ${sampleContacts[index].name}.`,
            direction: "inbound",
            status: "delivered",
            timestamp: new Date(Date.now() - (index + 1) * 60000).toISOString(),
            organization_id: orgId
          }),
          Message.create({
            conversation_id: conv.id,
            content: `Thanks for your message. We will get back to you shortly.`,
            direction: "outbound",
            status: "sent",
            timestamp: new Date(Date.now() - index * 60000).toISOString(),
            organization_id: orgId
          })
        ]);
        await Promise.all(messagePromises);

        // After creating messages, update the conversations with last message content and date
        await Promise.all(newConversations.map(async (conv, index) => {
          const lastMsg = (await Message.filter({ conversation_id: conv.id }, '-timestamp', 1))[0];
          if (lastMsg) {
            await Conversation.update(conv.id, {
              last_message_content: lastMsg.content,
              last_message_date: lastMsg.timestamp
            });
          }
        }));


        // Re-fetch data after creation
        [conversationsData, contactsData] = await Promise.all([
            Conversation.filter({ organization_id: orgId }, "-last_message_date"),
            Contact.filter({ organization_id: orgId }),
        ]);
      }
      
      // The Conversation entity is now assumed to store last_message_content and last_message_date directly
      setConversations(conversationsData.sort((a,b) => new Date(b.last_message_date) - new Date(a.last_message_date)));
      setContacts(contactsData);
    } catch (error) {
      console.error("Error loading inbox data:", error);
    }
    if (!isSilentRefresh) setIsLoading(false);
  }, [setConversations, setContacts, setIsLoading]);

  const loadMessages = useCallback(async (conversationId) => {
    if (!organizationId) return;
    setIsLoadingMessages(true);
    try {
      const messagesData = await Message.filter({ conversation_id: conversationId, organization_id: organizationId }, "timestamp");
      setMessages(messagesData);
    } catch (error) {
      console.error("Error loading messages:", error);
    }
    setIsLoadingMessages(false);
  }, [organizationId, setMessages, setIsLoadingMessages]);

  // New function to check for new messages without reloading everything
  const checkForNewMessages = useCallback(async (conversationId) => {
    if (!organizationId || !conversationId) return;
    
    try {
      const messagesData = await Message.filter({ conversation_id: conversationId, organization_id: organizationId }, "timestamp");
      
      // Only update if there are actually new messages
      setMessages(currentMessages => {
        if (messagesData.length !== currentMessages.length) {
          return messagesData;
        }
        return currentMessages; // No change, keep existing messages
      });
    } catch (error) {
      console.error("Error checking for new messages:", error);
    }
  }, [organizationId]);

  useEffect(() => {
    const init = async () => {
      setIsLoading(true);
      try {
        let user = await User.me();
        setCurrentUser(user);
        let orgId = user.organization_id;

        if (!orgId) {
          console.log("No organization found, creating one for the user.");
          const newOrg = await Organization.create({ name: `${user.full_name}'s Organization`, owner_id: user.id });
          await User.updateMyUserData({ organization_id: newOrg.id });
          orgId = newOrg.id;
        }
        
        setOrganizationId(orgId);
        await loadData(orgId);

      } catch (error) {
        console.error("Initialization error:", error);
      }
      setIsLoading(false);
    };
    init();
  }, [loadData, setIsLoading, setOrganizationId, setCurrentUser]);

  // Modified polling - less aggressive and smarter
  useEffect(() => {
    const pollInterval = setInterval(() => {
      if (organizationId) {
        // Always refresh conversations list silently
        loadData(organizationId, true);
        
        // Only check for new messages in the current conversation (don't reload everything)
        if (selectedConversation) {
          checkForNewMessages(selectedConversation.id);
        }
      }
    }, 10000); // Increased to 10 seconds to be less aggressive

    return () => clearInterval(pollInterval);
  }, [organizationId, selectedConversation, loadData, checkForNewMessages]);


  const handleConversationSelect = async (conversation) => {
    // Don't reload if selecting the same conversation
    if (selectedConversation?.id === conversation.id) return;
    
    setSelectedConversation(conversation);
    // Clear previous messages immediately for instant feedback
    setMessages([]);
    loadMessages(conversation.id);
    setShowContactInfo(false);
    
    // Mark conversation as read if it has unread messages
    if (conversation.unread_count && conversation.unread_count > 0) {
      try {
        // Update the backend
        await Conversation.update(conversation.id, { unread_count: 0 });
        
        // Optimistically update the UI
        const updatedConversations = conversations.map(c => 
          c.id === conversation.id ? { ...c, unread_count: 0 } : c
        );
        setConversations(updatedConversations.sort((a,b) => new Date(b.last_message_date) - new Date(a.last_message_date)));
        
        // Update the selected conversation state as well
        setSelectedConversation({ ...conversation, unread_count: 0 });
        
      } catch (error) {
        console.error("Error marking conversation as read:", error);
      }
    }
  };

  const getContactForConversation = (conversationId) => {
    const conversation = conversations.find(c => c.id === conversationId);
    return contacts.find(c => c.id === conversation?.contact_id);
  };

  const handleContactUpdate = (updatedContact) => {
    setContacts(prevContacts => 
      prevContacts.map(contact => 
        contact.id === updatedContact.id ? updatedContact : contact
      )
    );
    // Also reload conversations to reflect any changes that might affect sorting
    if (organizationId) loadData(organizationId, true); // Silently refresh data
  };

  const sendMessage = async (content) => {
    if (!selectedConversation || !organizationId) return;

    const newMessageData = {
      conversation_id: selectedConversation.id,
      content,
      direction: "outbound",
      status: "sent",
      timestamp: new Date().toISOString(),
      organization_id: organizationId
    };

    try {
      // Create the message
      const createdMessage = await Message.create(newMessageData);
      
      // Update the conversation with last message details
      await Conversation.update(selectedConversation.id, {
          last_message_content: content,
          last_message_date: newMessageData.timestamp
      });

      // Optimistically update UI
      setMessages(prev => [...prev, createdMessage]);
      const updatedConversations = conversations.map(c => 
        c.id === selectedConversation.id 
        ? { ...c, last_message_content: content, last_message_date: newMessageData.timestamp }
        : c
      );
      setConversations(updatedConversations.sort((a,b) => new Date(b.last_message_date) - new Date(a.last_message_date)));
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  const sendInternalNote = async (content) => {
    if (!selectedConversation || !organizationId) return;

    const newNoteData = {
      conversation_id: selectedConversation.id,
      content,
      direction: "outbound", // Notes are from an agent
      status: "sent", // Notes are considered 'sent' internally
      timestamp: new Date().toISOString(),
      organization_id: organizationId,
      is_internal: true, // This is the crucial flag
    };

    try {
      const createdNote = await Message.create(newNoteData);
      // IMPORTANT: Do not update the conversation's last message details
      // This prevents the conversation from jumping to the top of the list
      
      // Just update the messages in the current view
      setMessages(prev => [...prev, createdNote]);
    } catch (error) {
      console.error("Error sending internal note:", error);
    }
  };

  const handleStartConversation = async (conversation) => {
    // Allow starting if it's unassigned OR if it's concluded (re-opening from archive)
    if (!currentUser || !conversation) return;
    if (conversation.assigned_to && conversation.status !== 'concluded') return; // Don't allow if already assigned and open

    try {
      // Update the backend: set status to in_progress and assign to current user
      const updatedConversation = await Conversation.update(conversation.id, { 
        assigned_to: currentUser.id,
        status: 'in_progress' 
      });
      
      // Optimistically update the UI
      const newConversations = conversations.map(c => 
        c.id === conversation.id ? updatedConversation : c
      );
      setConversations(newConversations.sort((a,b) => new Date(b.last_message_date) - new Date(a.last_message_date)));
      
      if (selectedConversation?.id === conversation.id) {
        setSelectedConversation(updatedConversation);
      }

    } catch (error) {
      console.error("Error starting conversation:", error);
    }
  };

  const handleFinishConversation = async (conversation) => {
    if (!conversation) return;

    try {
      // Update the conversation to concluded status and remove assignment
      const updatedConversation = await Conversation.update(conversation.id, { 
        status: 'concluded',
        assigned_to: null // Remove assignment when finishing
      });
      
      // Optimistically update the UI
      const newConversations = conversations.map(c => 
        c.id === conversation.id ? updatedConversation : c
      );
      setConversations(newConversations.sort((a,b) => new Date(b.last_message_date) - new Date(a.last_message_date)));
      
      // If this was the selected conversation, clear the selection
      if (selectedConversation?.id === conversation.id) {
        setSelectedConversation(null);
      }

    } catch (error) {
      console.error("Error finishing conversation:", error);
    }
  };

  return (
    <div className="h-full flex bg-white overflow-hidden" style={{height: 'calc(100vh - 65px)'}}>
      {/* Conversations List */}
      <div className="w-80 border-r border-gray-200 flex flex-col min-h-0">
        <ConversationList
          conversations={conversations}
          contacts={contacts}
          selectedConversation={selectedConversation}
          onConversationSelect={handleConversationSelect}
          isLoading={isLoading}
          currentUser={currentUser}
        />
      </div>

      {/* Chat View */}
      <div className="flex-1 flex flex-col min-h-0">
        {selectedConversation ? (
          <ChatView
            conversation={selectedConversation}
            contact={getContactForConversation(selectedConversation.id)}
            messages={messages}
            isLoadingMessages={isLoadingMessages}
            onSendMessage={sendMessage}
            onSendInternalNote={sendInternalNote}
            onToggleContactInfo={() => setShowContactInfo(!showContactInfo)}
            onStartConversation={handleStartConversation}
            onFinishConversation={handleFinishConversation}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center bg-gray-50">
            <div className="text-center">
              {isLoading ? (
                <>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Loading Workspace...</h3>
                  <p className="text-gray-500">Setting things up for you.</p>
                </>
              ) : (
                <>
                  <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MessageCircle className="w-8 h-8 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Select a conversation</h3>
                  <p className="text-gray-500">Choose a conversation from the list to start messaging</p>
                </>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Contact Info Panel */}
      {showContactInfo && selectedConversation && (
        <div className="w-80 border-l border-gray-200 flex-shrink-0 transition-all duration-300 ease-in-out">
          <ContactInfo
            contact={getContactForConversation(selectedConversation.id)}
            conversation={selectedConversation}
            onClose={() => setShowContactInfo(false)}
            onContactUpdate={handleContactUpdate}
          />
        </div>
      )}
    </div>
  );
}
