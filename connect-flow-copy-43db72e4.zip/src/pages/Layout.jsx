

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { 
  MessageCircle, 
  Users, 
  Send, 
  Bot, 
  Brain, 
  LayoutDashboard,
  Settings,
  Bell,
  Menu,
  ChevronDown,
  LogOut,
  UserIcon,
  FlaskConical
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
  },
  {
    title: "Inbox",
    url: createPageUrl("Inbox"),
    icon: MessageCircle,
    badge: "3"
  },
  {
    title: "Contacts",
    icon: Users,
    dropdown: [
      {
        title: "Contacts",
        url: createPageUrl("Contacts"),
        description: "Manage your contact database"
      },
      {
        title: "CRM",
        url: createPageUrl("CRM"),
        description: "Customer relationship management"
      },
      {
        title: "Scheduled Messages",
        url: createPageUrl("ScheduledMessages"),
        description: "Future scheduled communications"
      }
    ]
  },
  {
    title: "Campaigns",
    url: createPageUrl("Campaigns"),
    icon: Send,
  },
  {
    title: "Test",
    url: createPageUrl("Test"),
    icon: FlaskConical,
  }
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [currentUser, setCurrentUser] = React.useState(null);

  // Load current user data
  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleLogout = async () => {
    try {
      await User.logout();
      // The User.logout() method will automatically redirect to the login page
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  return (
    <SidebarProvider>
      <style>
        {`
          :root {
            --primary-blue: #1e40af;
            --primary-purple: #7c3aed;
            --whatsapp-green: #25d366;
            --accent-emerald: #059669;
            --neutral-50: #f8fafc;
            --neutral-100: #f1f5f9;
            --neutral-900: #0f172a;
          }
          
          .gradient-bg {
            background: linear-gradient(135deg, var(--primary-blue) 0%, var(--primary-purple) 100%);
          }
          
          .whatsapp-gradient {
            background: linear-gradient(135deg, var(--whatsapp-green) 0%, var(--accent-emerald) 100%);
          }
          
          .glass-effect {
            backdrop-filter: blur(12px);
            background: rgba(255, 255, 255, 0.85);
            border: 1px solid rgba(255, 255, 255, 0.2);
          }
        `}
      </style>
      
      <div className="min-h-screen flex flex-col w-full bg-gradient-to-br from-slate-50 to-blue-50 text-sm">
        
        {/* Static Horizontal Header - Always Visible */}
        <header className="flex items-center justify-between px-4 py-2 bg-white/95 backdrop-blur-xl border-b border-slate-200/60 sticky top-0 z-50 shadow-sm">
          {/* Mobile Menu Trigger - Only visible on mobile */}
          <div className="lg:hidden">
            <SidebarTrigger className="p-2 rounded-lg hover:bg-slate-100">
              <Menu className="w-5 h-5" />
            </SidebarTrigger>
          </div>
          
          {/* Left: Logo & App Name */}
          <div className="flex items-center gap-3">
            <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68cc4b937429b1b8992ce1e4/5a6950d23_hootspy-website-favicon-black.png" alt="Hootspy Logo" className="w-8 h-8" />
            <div className="hidden sm:block">
              <h2 className="font-bold text-slate-900 text-base">Hootspy</h2>
              <p className="text-xs text-slate-500 font-medium">Business Suite</p>
            </div>
          </div>
          
          {/* Middle: Navigation - Hidden on mobile, visible on desktop */}
          <nav className="hidden lg:flex items-center gap-1">
            {navigationItems.map((item) => {
              if (item.dropdown) {
                // Handle dropdown navigation items
                return (
                  <DropdownMenu key={item.title}>
                    <DropdownMenuTrigger asChild>
                      <button className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900">
                        <item.icon className="w-4 h-4" />
                        <span>{item.title}</span>
                        <ChevronDown className="w-3 h-3 ml-1" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start" className="w-64">
                      {item.dropdown.map((subItem) => (
                        <DropdownMenuItem key={subItem.title} asChild>
                          <Link to={subItem.url} className="flex flex-col items-start gap-1 p-3">
                            <div className="font-medium text-sm">{subItem.title}</div>
                            <div className="text-xs text-gray-500">{subItem.description}</div>
                          </Link>
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                );
              } else {
                // Handle regular navigation items
                const isActive = location.pathname === item.url;
                return (
                  <Link
                    key={item.title}
                    to={item.url}
                    className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-200 ${
                      isActive
                        ? 'bg-blue-50 text-blue-700 shadow-sm'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    <span>{item.title}</span>
                    {item.badge && (
                      <Badge className="absolute -top-1.5 -right-1.5 h-4 w-4 p-0 flex items-center justify-center text-[10px] bg-red-500 text-white">
                        {item.badge}
                      </Badge>
                    )}
                  </Link>
                );
              }
            })}
          </nav>
          
          {/* Right: User Menu & Actions */}
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="hover:bg-slate-100 hidden sm:flex h-8 w-8">
              <Bell className="w-4 h-4 text-slate-600" />
            </Button>
            <Link to={createPageUrl("Settings")}>
              <Button variant="ghost" size="icon" className="hover:bg-slate-100 hidden sm:flex h-8 w-8">
                <Settings className="w-4 h-4 text-slate-600" />
              </Button>
            </Link>
            
            {/* User Profile Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-sm hover:shadow-md transition-shadow cursor-pointer">
                  <span className="text-white font-semibold text-xs">
                    {currentUser?.full_name?.[0]?.toUpperCase() || "U"}
                  </span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem disabled className="flex flex-col items-start gap-1 py-3">
                  <div className="font-medium text-sm">
                    {currentUser?.full_name || "User"}
                  </div>
                  <div className="text-xs text-gray-500">
                    {currentUser?.email || "Loading..."}
                  </div>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to={createPageUrl("Settings")} className="flex items-center gap-2 cursor-pointer">
                    <UserIcon className="w-4 h-4" />
                    <span>Profile Settings</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={handleLogout}
                  className="flex items-center gap-2 cursor-pointer text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Mobile Slide-out Sidebar - Only for mobile */}
        <Sidebar className="lg:hidden border-r border-slate-200/60 bg-white/95 backdrop-blur-xl">
          <SidebarHeader className="border-b border-slate-200/60 p-6">
            <div className="flex items-center gap-3">
              <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68cc4b937429b1b8992ce1e4/5a6950d23_hootspy-website-favicon-black.png" alt="Hootspy Logo" className="w-10 h-10" />
              <div>
                <h2 className="font-bold text-slate-900 text-lg">Hootspy</h2>
                <p className="text-xs text-slate-500 font-medium">Business Suite</p>
              </div>
            </div>
          </SidebarHeader>
          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-2 mb-2">
                Navigation
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu className="space-y-1">
                  {navigationItems.map((item) => {
                    if (item.dropdown) {
                      return (
                        <div key={item.title} className="space-y-1">
                          <div className="px-4 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider">
                            {item.title}
                          </div>
                          {item.dropdown.map((subItem) => {
                            const isActive = location.pathname === subItem.url;
                            return (
                              <SidebarMenuItem key={subItem.title}>
                                <SidebarMenuButton 
                                  asChild 
                                  className={`group rounded-xl transition-all duration-300 ease-out ml-4 ${
                                    isActive 
                                      ? 'bg-gradient-to-r from-blue-50 to-purple-50 text-blue-700' 
                                      : 'hover:bg-slate-50 text-slate-700'
                                  }`}
                                >
                                  <Link to={subItem.url} className="flex flex-col items-start gap-1 px-4 py-3">
                                    <span className="font-medium text-sm">{subItem.title}</span>
                                    <span className="text-xs text-gray-500">{subItem.description}</span>
                                  </Link>
                                </SidebarMenuButton>
                              </SidebarMenuItem>
                            );
                          })}
                        </div>
                      );
                    } else {
                      const isActive = location.pathname === item.url;
                      return (
                        <SidebarMenuItem key={item.title}>
                          <SidebarMenuButton 
                            asChild 
                            className={`group rounded-xl transition-all duration-300 ease-out ${
                              isActive 
                                ? 'bg-gradient-to-r from-blue-50 to-purple-50 text-blue-700' 
                                : 'hover:bg-slate-50 text-slate-700'
                            }`}
                          >
                            <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                              <item.icon className={`w-5 h-5 ${isActive ? 'text-blue-600' : ''}`} />
                              <span className="font-medium text-sm">{item.title}</span>
                              {item.badge && (
                                <Badge variant="secondary" className="ml-auto text-xs bg-red-100 text-red-700">
                                  {item.badge}
                                </Badge>
                              )}
                            </Link>
                          </SidebarMenuButton>
                        </SidebarMenuItem>
                      );
                    }
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        {/* Main Content Area - Takes remaining height below fixed header */}
        <main className="flex-1 min-h-0">
          {children}
        </main>
      </div>
    </SidebarProvider>
  );
}

