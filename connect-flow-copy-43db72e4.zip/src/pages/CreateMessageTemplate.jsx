import React, { useState, useEffect } from "react";
import { MessageTemplate } from "@/api/entities";
import { Team } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  ArrowLeft, 
  Plus, 
  X, 
  Image, 
  Video, 
  Music, 
  FileText,
  Link,
  MessageSquareReply,
  Eye,
  Save,
  Smartphone,
  Users,
  Hash
} from "lucide-react";
import { Link as RouterLink, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function CreateMessageTemplatePage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    content: "",
    channel_type: "whatsapp",
    category: "utility",
    language: "en",
    variables: [],
    media_url: "",
    footer: "",
    buttons: [],
    available_teams: []
  });
  
  const [teams, setTeams] = useState([]);
  const [organizationId, setOrganizationId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showVariableDialog, setShowVariableDialog] = useState(false);
  const [showButtonDialog, setShowButtonDialog] = useState(false);
  const [newVariable, setNewVariable] = useState({ name: "", type: "contact_field", field: "" });
  const [newButton, setNewButton] = useState({ type: "url", text: "", value: "" });

  useEffect(() => {
    const init = async () => {
      try {
        const user = await User.me();
        if (user.organization_id) {
          setOrganizationId(user.organization_id);
          const teamsData = await Team.filter({ organization_id: user.organization_id });
          setTeams(teamsData);
        }
      } catch (error) {
        console.error("Error loading initial data:", error);
      }
    };
    init();
  }, []);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const insertVariable = (variableName) => {
    const cursorPos = document.getElementById('content-textarea').selectionStart || 0;
    const content = formData.content;
    const before = content.substring(0, cursorPos);
    const after = content.substring(cursorPos);
    const newContent = before + `{{${variableName}}}` + after;
    
    handleInputChange('content', newContent);
    
    if (!formData.variables.includes(variableName)) {
      handleInputChange('variables', [...formData.variables, variableName]);
    }
  };

  const addVariable = () => {
    if (!newVariable.name) return;
    
    insertVariable(newVariable.name);
    setNewVariable({ name: "", type: "contact_field", field: "" });
    setShowVariableDialog(false);
  };

  const addButton = () => {
    if (!newButton.text || !newButton.value) return;
    
    const button = {
      id: Date.now(),
      type: newButton.type,
      text: newButton.text,
      value: newButton.value
    };
    
    handleInputChange('buttons', [...formData.buttons, button]);
    setNewButton({ type: "url", text: "", value: "" });
    setShowButtonDialog(false);
  };

  const removeButton = (buttonId) => {
    handleInputChange('buttons', formData.buttons.filter(btn => btn.id !== buttonId));
  };

  const handleSave = async () => {
    if (!formData.name || !formData.content) {
      alert('Please fill in all required fields');
      return;
    }

    setIsLoading(true);
    try {
      await MessageTemplate.create({
        ...formData,
        organization_id: organizationId,
        status: 'draft'
      });
      
      navigate(createPageUrl("Settings"));
    } catch (error) {
      console.error("Error saving template:", error);
      alert('Error saving template. Please try again.');
    }
    setIsLoading(false);
  };

  const contactFields = [
    { value: "name", label: "Contact Name" },
    { value: "phone", label: "Phone Number" },
    { value: "email", label: "Email Address" },
    { value: "company", label: "Company" }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <RouterLink to={createPageUrl("Settings")}>
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Settings
              </Button>
            </RouterLink>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Create Message Template</h1>
              <p className="text-gray-500">Design a reusable WhatsApp message template</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Button variant="outline">
              <Eye className="w-4 h-4 mr-2" />
              Preview
            </Button>
            <Button onClick={handleSave} disabled={isLoading} className="bg-blue-600 hover:bg-blue-700">
              <Save className="w-4 h-4 mr-2" />
              {isLoading ? 'Saving...' : 'Save Template'}
            </Button>
          </div>
        </div>
      </div>

      <div className="flex h-[calc(100vh-81px)]">
        {/* Main Content Area */}
        <div className="flex-1 p-6 overflow-auto">
          <div className="max-w-4xl mx-auto space-y-6">
            
            {/* Message Content */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Smartphone className="w-5 h-5" />
                  Message Content
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                
                {/* Media Attachment */}
                <div>
                  <Label>Media Attachment (Optional)</Label>
                  <div className="mt-2 flex gap-2">
                    <Button variant="outline" size="sm">
                      <Image className="w-4 h-4 mr-2" />
                      Image
                    </Button>
                    <Button variant="outline" size="sm">
                      <Video className="w-4 h-4 mr-2" />
                      Video
                    </Button>
                    <Button variant="outline" size="sm">
                      <Music className="w-4 h-4 mr-2" />
                      Audio
                    </Button>
                    <Button variant="outline" size="sm">
                      <FileText className="w-4 h-4 mr-2" />
                      Document
                    </Button>
                  </div>
                  {formData.media_url && (
                    <div className="mt-2 p-2 bg-blue-50 rounded-md">
                      <p className="text-sm text-blue-700">Media attached: {formData.media_url}</p>
                    </div>
                  )}
                </div>

                {/* Template Message */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label htmlFor="content-textarea">Template Message *</Label>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setShowVariableDialog(true)}
                    >
                      <Hash className="w-4 h-4 mr-2" />
                      Add Variable
                    </Button>
                  </div>
                  <Textarea
                    id="content-textarea"
                    value={formData.content}
                    onChange={(e) => handleInputChange('content', e.target.value)}
                    placeholder="Type your message here... Use {{variable_name}} for dynamic content."
                    rows={6}
                    className="resize-none"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Character count: {formData.content.length}/1024
                  </p>
                </div>

                {/* Variables Display */}
                {formData.variables.length > 0 && (
                  <div>
                    <Label>Variables Used</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {formData.variables.map((variable, index) => (
                        <Badge key={index} variant="secondary">
                          {variable}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Footer */}
                <div>
                  <Label htmlFor="footer">Footer (Optional)</Label>
                  <Input
                    id="footer"
                    value={formData.footer}
                    onChange={(e) => handleInputChange('footer', e.target.value)}
                    placeholder="Add a footer message..."
                    maxLength={60}
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Footer appears at the bottom of the message (max 60 characters)
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Action Buttons</CardTitle>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setShowButtonDialog(true)}
                    disabled={formData.buttons.length >= 3}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Button
                  </Button>
                </div>
                <p className="text-sm text-gray-500">
                  Add call-to-action buttons (maximum 3 buttons)
                </p>
              </CardHeader>
              <CardContent>
                {formData.buttons.length === 0 ? (
                  <p className="text-gray-500 text-center py-4">
                    No buttons added yet. Click "Add Button" to create action buttons.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {formData.buttons.map((button) => (
                      <div key={button.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          {button.type === 'url' ? (
                            <Link className="w-4 h-4 text-blue-600" />
                          ) : (
                            <MessageSquareReply className="w-4 h-4 text-green-600" />
                          )}
                          <div>
                            <p className="font-medium">{button.text}</p>
                            <p className="text-sm text-gray-500">
                              {button.type === 'url' ? 'URL' : 'Quick Reply'}: {button.value}
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => removeButton(button.id)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Right Sidebar - Template Settings */}
        <div className="w-80 bg-white border-l border-gray-200 p-6 overflow-auto">
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Template Settings</h3>
            </div>

            {/* Template Name */}
            <div>
              <Label htmlFor="name">Template Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="Enter template name..."
              />
            </div>

            {/* Channel */}
            <div>
              <Label>Channel</Label>
              <Select value={formData.channel_type} onValueChange={(value) => handleInputChange('channel_type', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="whatsapp">WhatsApp Business</SelectItem>
                  <SelectItem value="instagram">Instagram</SelectItem>
                  <SelectItem value="facebook">Facebook Messenger</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Category */}
            <div>
              <Label>Category</Label>
              <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="utility">Utility</SelectItem>
                  <SelectItem value="authentication">Authentication</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Available Teams */}
            <div>
              <Label>Available for Teams</Label>
              <div className="mt-2 space-y-2 max-h-40 overflow-auto">
                {teams.map((team) => (
                  <div key={team.id} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`team-${team.id}`}
                      checked={formData.available_teams.includes(team.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          handleInputChange('available_teams', [...formData.available_teams, team.id]);
                        } else {
                          handleInputChange('available_teams', formData.available_teams.filter(id => id !== team.id));
                        }
                      }}
                      className="rounded border-gray-300"
                    />
                    <Label htmlFor={`team-${team.id}`} className="text-sm">
                      {team.name}
                    </Label>
                  </div>
                ))}
              </div>
              {teams.length === 0 && (
                <p className="text-sm text-gray-500 mt-2">No teams available</p>
              )}
            </div>

            {/* Language */}
            <div>
              <Label>Language</Label>
              <Select value={formData.language} onValueChange={(value) => handleInputChange('language', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Spanish</SelectItem>
                  <SelectItem value="pt">Portuguese</SelectItem>
                  <SelectItem value="fr">French</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      {/* Add Variable Dialog */}
      <Dialog open={showVariableDialog} onOpenChange={setShowVariableDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Variable</DialogTitle>
            <DialogDescription>
              Insert a dynamic variable into your message template.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label>Variable Type</Label>
              <Select 
                value={newVariable.type} 
                onValueChange={(value) => setNewVariable(prev => ({...prev, type: value}))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="contact_field">Contact Field</SelectItem>
                  <SelectItem value="custom">Custom Variable</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {newVariable.type === 'contact_field' ? (
              <div>
                <Label>Contact Field</Label>
                <Select 
                  value={newVariable.field} 
                  onValueChange={(value) => {
                    const field = contactFields.find(f => f.value === value);
                    setNewVariable(prev => ({
                      ...prev, 
                      field: value,
                      name: field?.label.toLowerCase().replace(' ', '_') || value
                    }));
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select contact field" />
                  </SelectTrigger>
                  <SelectContent>
                    {contactFields.map((field) => (
                      <SelectItem key={field.value} value={field.value}>
                        {field.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <div>
                <Label>Variable Name</Label>
                <Input
                  value={newVariable.name}
                  onChange={(e) => setNewVariable(prev => ({...prev, name: e.target.value}))}
                  placeholder="e.g., first_name, order_number, etc."
                />
                <p className="text-sm text-gray-500 mt-1">
                  Users will be prompted to fill this when sending the template
                </p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowVariableDialog(false)}>
              Cancel
            </Button>
            <Button onClick={addVariable}>
              Add Variable
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Button Dialog */}
      <Dialog open={showButtonDialog} onOpenChange={setShowButtonDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Action Button</DialogTitle>
            <DialogDescription>
              Create a call-to-action button for your message template.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label>Button Type</Label>
              <Select 
                value={newButton.type} 
                onValueChange={(value) => setNewButton(prev => ({...prev, type: value}))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="url">URL Button</SelectItem>
                  <SelectItem value="quick_reply">Quick Reply</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Button Text</Label>
              <Input
                value={newButton.text}
                onChange={(e) => setNewButton(prev => ({...prev, text: e.target.value}))}
                placeholder="Button label (max 20 characters)"
                maxLength={20}
              />
            </div>

            <div>
              <Label>
                {newButton.type === 'url' ? 'URL' : 'Reply Text'}
              </Label>
              <Input
                value={newButton.value}
                onChange={(e) => setNewButton(prev => ({...prev, value: e.target.value}))}
                placeholder={
                  newButton.type === 'url' 
                    ? "https://example.com" 
                    : "Text to send when clicked"
                }
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowButtonDialog(false)}>
              Cancel
            </Button>
            <Button onClick={addButton}>
              Add Button
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}