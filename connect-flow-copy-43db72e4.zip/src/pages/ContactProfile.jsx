
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Contact, CustomField, User as AppUser } from "@/api/entities"; // Import CustomField and AppUser
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import EditContactForm from "@/components/inbox/EditContactForm";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  ArrowLeft, Mail, Building, Phone, Edit, User, Clock, FileText, MessageCircle, Info 
} from "lucide-react";

export default function ContactProfilePage() {
  const [contact, setContact] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState("details");
  const [customFieldDefs, setCustomFieldDefs] = useState([]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const contactId = params.get("id");
    if (contactId) {
      loadContact(contactId);
    } else {
      setIsLoading(false);
    }
  }, []);

  const loadContact = async (id) => {
    setIsLoading(true);
    try {
      const data = await Contact.get(id);
      setContact(data);
      if (data.organization_id) {
        const fields = await CustomField.filter({ organization_id: data.organization_id }, "sort_order");
        setCustomFieldDefs(fields);
      }
    } catch (error) {
      console.error("Error loading contact:", error);
    }
    setIsLoading(false);
  };

  const handleSave = (updatedContact) => {
    setContact(updatedContact);
    setIsEditing(false);
    // Reload custom field definitions as they might be tied to organization, though not directly modified by contact save,
    // it's a good practice to ensure consistency if the contact's organization could ever change (unlikely for now)
    // or if custom fields themselves are configured dynamically. For now, it's fine not to re-fetch if organization_id doesn't change.
    // If the contact's organization *could* change via edit, we'd need to re-evaluate custom field defs.
    // For this specific change, we only fetch custom field defs once on initial load.
  };

  const tabs = [
    { id: "details", icon: User, label: "Details" },
    { id: "scheduled", icon: Clock, label: "Scheduled" },
    { id: "files", icon: FileText, label: "Files" },
    { id: "conversations", icon: MessageCircle, label: "History" }
  ];

  if (isLoading) {
    return <ContactProfileSkeleton />;
  }

  if (!contact) {
    return (
      <div className="p-6 text-center text-gray-500">
        Contact not found.
        <Link to={createPageUrl("Contacts")} className="text-blue-600 block mt-4">
          Return to Contacts
        </Link>
      </div>
    );
  }

  if (isEditing) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <EditContactForm
          contact={contact}
          onSave={handleSave}
          onCancel={() => setIsEditing(false)}
        />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-6">
        <Link to={createPageUrl("Contacts")} className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back to Contacts
        </Link>
      </div>

      {/* Profile Header */}
      <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 p-6 border border-gray-200 rounded-xl mb-6 bg-white">
        <div className="w-24 h-24 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center flex-shrink-0">
          <span className="text-white font-bold text-4xl">
            {contact.name?.[0]?.toUpperCase() || "?"}
          </span>
        </div>
        <div className="flex-1 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">{contact.name}</h1>
              <p className="text-lg text-gray-500 mt-1">{contact.phone}</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
              <Edit className="w-3 h-3 mr-2" />
              Edit Profile
            </Button>
          </div>
          {contact.tags && contact.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-4 justify-center sm:justify-start">
              {contact.tags.map((tag, index) => (
                <Badge key={index} variant="secondary">{tag}</Badge>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-gray-200 mb-6">
        <div className="flex gap-4">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 py-3 px-1 text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? "text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content */}
      <div className="bg-white p-6 rounded-xl border border-gray-200">
        {activeTab === "details" && <DetailsTab contact={contact} customFieldDefs={customFieldDefs} />}
        {activeTab === "scheduled" && <ScheduledMessagesTab contact={contact} />}
        {activeTab === "files" && <FilesTab contact={contact} />}
        {activeTab === "conversations" && <ConversationHistoryTab contact={contact} />}
      </div>
    </div>
  );
}


// --- Tab Components (for consistency with sidebar) ---

function DetailsTab({ contact, customFieldDefs }) {
  const formatCustomFieldValue = (field, value) => {
    if (value === null || value === undefined || value === '') return <span className="text-gray-400">Not set</span>;

    switch (field.field_type) {
        case 'boolean':
            return <Badge variant={value ? 'default' : 'outline'}>{value ? 'Yes' : 'No'}</Badge>;
        case 'currency':
            return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
        case 'date':
        case 'datetime':
            try {
                return new Date(value).toLocaleDateString();
            } catch {
                return value;
            }
        default:
            return value.toString();
    }
  };

  return (
    <div className="space-y-6">
      <InfoItem icon={User} label="Name" value={contact.name} />
      <InfoItem icon={Phone} label="Phone" value={contact.phone} />
      {contact.email && <InfoItem icon={Mail} label="Email" value={contact.email} />}
      {contact.company && <InfoItem icon={Building} label="Company" value={contact.company} />}
      <Separator />
      {/* Custom Fields */}
      {customFieldDefs.length > 0 && contact.custom_fields && (
        <>
          {customFieldDefs.map(field => {
            const value = contact.custom_fields[field.integration_key];
            return (
              <InfoItem 
                key={field.id}
                icon={Info} 
                label={field.name} 
                value={formatCustomFieldValue(field, value)} 
              />
            );
          })}
        </>
      )}

      {contact.notes && (
        <div>
          <h4 className="font-medium text-gray-800 mb-3">Notes</h4>
          <div className="p-3 bg-gray-50 rounded-lg border">
            <p className="text-sm text-gray-700 whitespace-pre-wrap">{contact.notes}</p>
          </div>
        </div>
      )}
    </div>
  );
}

function InfoItem({ icon: Icon, label, value }) {
  return (
    <div className="flex items-start gap-4">
      <Icon className="w-5 h-5 text-gray-400 mt-1 flex-shrink-0" />
      <div>
        <p className="text-sm text-gray-500">{label}</p>
        <p className="font-medium text-base text-gray-800">{value}</p>
      </div>
    </div>
  );
}

function ScheduledMessagesTab({ contact }) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Scheduled Messages</h3>
      <div className="text-center py-10 bg-gray-50 rounded-lg">
        <Clock className="w-10 h-10 mx-auto text-gray-400 mb-3" />
        <h4 className="font-medium text-gray-700">No Scheduled Messages</h4>
        <p className="text-sm text-gray-500">Future scheduled messages for {contact.name} will appear here.</p>
      </div>
    </div>
  );
}

function FilesTab({ contact }) {
  return (
     <div>
      <h3 className="text-lg font-semibold mb-4">Shared Files</h3>
      <div className="text-center py-10 bg-gray-50 rounded-lg">
        <FileText className="w-10 h-10 mx-auto text-gray-400 mb-3" />
        <h4 className="font-medium text-gray-700">No Files Shared</h4>
        <p className="text-sm text-gray-500">Files shared in conversations with {contact.name} will appear here.</p>
      </div>
    </div>
  );
}

function ConversationHistoryTab({ contact }) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Conversation History</h3>
      <div className="text-center py-10 bg-gray-50 rounded-lg">
        <MessageCircle className="w-10 h-10 mx-auto text-gray-400 mb-3" />
        <h4 className="font-medium text-gray-700">No Past Conversations</h4>
        <p className="text-sm text-gray-500">Archived or closed conversations with {contact.name} will appear here.</p>
      </div>
    </div>
  );
}

function ContactProfileSkeleton() {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <Skeleton className="h-6 w-32 mb-6" />
      <div className="flex items-start gap-6 p-6 border rounded-xl mb-6">
        <Skeleton className="w-24 h-24 rounded-full" />
        <div className="flex-1">
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-6 w-32 mb-4" />
          <div className="flex gap-2">
            <Skeleton className="h-5 w-16" />
            <Skeleton className="h-5 w-20" />
          </div>
        </div>
      </div>
      <Skeleton className="h-12 w-full" />
    </div>
  );
}
