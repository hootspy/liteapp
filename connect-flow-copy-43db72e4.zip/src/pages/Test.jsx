import React, { useEffect, useState } from 'react';
import { User } from '@/api/entities';
import { ChannelGroup } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, Beaker, Globe, Code } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function TestPage() {
  const [currentUser, setCurrentUser] = useState(null);
  const [apiKey, setApiKey] = useState('');
  const [channelGroups, setChannelGroups] = useState([]);
  const [selectedGroupId, setSelectedGroupId] = useState('');

  // Fetch user data to get organization ID
  useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
        if (user.organization_id) {
          const demoKey = `hootspy_${user.organization_id.substring(0, 8)}_${Math.random().toString(36).substring(2, 10)}`;
          setApiKey(demoKey);
          
          // Load channel groups
          const groups = await ChannelGroup.filter({ organization_id: user.organization_id });
          setChannelGroups(groups);
          
          // Auto-select first group if available
          if (groups.length > 0) {
            setSelectedGroupId(groups[0].id);
          }
        }
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  // Simulate the client's embed code execution
  useEffect(() => {
    if (!currentUser?.organization_id || !apiKey || !selectedGroupId) return;

    // Wait a bit to ensure the DOM is ready
    const timer = setTimeout(() => {
      // This is the exact same code that clients will paste
      const config = {
        organizationId: currentUser.organization_id,
        groupId: selectedGroupId,
        apiKey: apiKey,
        containerId: "hootspy-inbox-container"
      };

      // Find the container
      const container = document.getElementById(config.containerId);
      if (!container) {
        console.error("Hootspy SDK Error: Container element with id '" + config.containerId + "' not found.");
        return;
      }

      // Create and configure the iframe
      const iframe = document.createElement('iframe');
      const iframeSrc = new URL(window.location.origin + '/InboxWidget');
      iframeSrc.searchParams.append('organizationId', config.organizationId);
      iframeSrc.searchParams.append('groupId', config.groupId);
      iframeSrc.searchParams.append('apiKey', config.apiKey);
      
      iframe.src = iframeSrc.toString();
      iframe.style.width = '100%';
      iframe.style.height = '100%';
      iframe.style.border = 'none';
      iframe.style.borderRadius = 'inherit';

      // Clear the container and add the iframe
      container.innerHTML = '';
      container.appendChild(iframe);
    }, 100);

    return () => clearTimeout(timer);
  }, [currentUser, apiKey, selectedGroupId]);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Simulate a client's website header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-3">
              <Globe className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Client's Website</h1>
                <p className="text-sm text-gray-500">Demo Company Dashboard</p>
              </div>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <a href="#" className="text-gray-600 hover:text-gray-900">Home</a>
              <a href="#" className="text-gray-600 hover:text-gray-900">Products</a>
              <a href="#" className="text-gray-600 hover:text-gray-900">Support</a>
              <a href="#" className="text-blue-600 font-medium">Dashboard</a>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Beaker className="w-6 h-6 text-purple-600" />
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Hootspy Widget Integration Test</h2>
              <p className="text-gray-600">This simulates how your clients will see the embedded inbox</p>
            </div>
          </div>
          
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-blue-600" />
                Client View Simulation
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-gray-700 space-y-2">
              <p>This page shows exactly what your clients will see when they embed the Hootspy Inbox widget.</p>
              <p>The widget below is loaded using the same HTML snippet that clients will copy from the SDK section.</p>
              <div className="space-y-2 mt-4">
                <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg">
                  <Code className="w-4 h-4 text-blue-600" />
                  <span className="text-blue-800 font-medium">Organization ID: {currentUser?.organization_id}</span>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <label className="block text-xs font-medium text-gray-700 mb-2">Select Channel Group:</label>
                  <Select value={selectedGroupId} onValueChange={setSelectedGroupId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a channel group" />
                    </SelectTrigger>
                    <SelectContent>
                      {channelGroups.map((group) => (
                        <SelectItem key={group.id} value={group.id}>
                          {group.name} ({group.group_key})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* This is where the client would paste the widget code */}
        <Card className="border-2 border-dashed border-blue-300 bg-white">
          <CardHeader>
            <CardTitle className="text-lg">Embedded Hootspy Inbox Widget</CardTitle>
            <p className="text-sm text-gray-600">This is how it appears on your client's website</p>
          </CardHeader>
          <CardContent>
            {/* The container where the widget will be injected */}
            <div 
              id="hootspy-inbox-container" 
              style={{ 
                width: '100%', 
                height: '700px',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                overflow: 'hidden'
              }}
            >
              {/* The JavaScript code above will inject the iframe here */}
              {!currentUser && (
                <div className="flex items-center justify-center h-full text-gray-500">
                  Loading configuration...
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Implementation Notes */}
        <Card className="mt-6 bg-green-50 border-green-200">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Code className="w-5 h-5 text-green-600" />
              Implementation Notes
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-gray-700 space-y-2">
            <p>✅ <strong>API Key Authentication:</strong> The widget now uses API key-based authentication instead of requiring user login.</p>
            <p>✅ <strong>Cross-Domain Ready:</strong> This widget can be embedded on any domain without additional configuration.</p>
            <p>✅ <strong>Group Filtering:</strong> The widget only shows conversations from channels in the selected group.</p>
            <p>✅ <strong>Secure:</strong> All data fetching is done server-side with proper API key validation.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}