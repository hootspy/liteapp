import React from 'react';
import { Play } from 'lucide-react';

export default function StartNode({ data }) {
  return (
    <div className="p-4 border-2 border-green-500 bg-white rounded-lg shadow-md w-64">
      <div className="flex items-center gap-2 mb-2">
        <Play className="w-5 h-5 text-green-600" />
        <strong className="text-sm font-bold text-gray-800">{data.label}</strong>
      </div>
      <p className="text-xs text-gray-600">{data.message}</p>
    </div>
  );
}