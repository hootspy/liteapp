import React from 'react';
import { 
  GripVertical, 
  MessageSquare, 
  Tag, 
  Plus, 
  Trash2,
  Mailbox,
  HelpCircle,
  List,
  PlusCircle,
  MinusCircle,
  Users,
  CheckCircle,
  Clock,
  GitBranch,
  Settings2,
  Send,
  Hourglass
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const actionIcons = {
  send_message: MessageSquare,
  send_template_message: Mailbox,
  send_question: HelpCircle,
  send_menu: List,
  automation_enroll: PlusCircle, // or MinusCircle depending on action
  tag_contact: Tag,
  transfer_conversation: Users,
  finish_conversation: CheckCircle,
  wait_for_reply: Hourglass,
  wait_time: Clock,
  condition: GitBranch,
  set_metadata: Settings2,
  send_webhook: Send,
};

const ActionSummary = ({ action, onSelect, onDelete }) => {
  const Icon = actionIcons[action.type] || MessageSquare;
  let summaryText = 'Click to configure';

  switch(action.type) {
    case 'send_message':
      summaryText = action.data?.message?.substring(0, 30) + (action.data?.message?.length > 30 ? '...' : '');
      break;
    case 'tag_contact':
      summaryText = `${action.data?.action === 'add' ? 'Add' : 'Remove'} Tag: ${action.data?.tag || 'Not set'}`;
      break;
    case 'send_question':
      summaryText = `Ask: ${action.data?.question?.substring(0, 30) + (action.data?.question?.length > 30 ? '...' : '')}`;
      break;
    case 'condition':
      summaryText = `If ${action.data?.conditions?.[0]?.field || ''}...`;
      break;
    case 'wait_time':
      summaryText = `Wait for ${action.data?.duration || ''} ${action.data?.unit || ''}`;
      break;
    case 'automation_enroll':
      summaryText = `${action.data?.action === 'enroll' ? 'Enroll in' : 'Unenroll from'} automation: ${action.data?.automationId || 'Not set'}`;
      break;
    case 'transfer_conversation':
      summaryText = `Transfer to: ${action.data?.queueName || 'Default'}`;
      break;
    case 'finish_conversation':
      summaryText = 'Finish conversation';
      break;
    case 'wait_for_reply':
      summaryText = 'Wait for contact reply';
      break;
    case 'set_metadata':
      summaryText = `Set ${action.data?.key || 'key'} = ${action.data?.value || 'value'}`;
      break;
    case 'send_webhook':
      summaryText = `Send webhook to ${action.data?.url ? new URL(action.data.url).hostname : 'URL not set'}`;
      break;
    case 'send_template_message':
      summaryText = `Template: ${action.data?.templateName || 'Not set'}`;
      break;
    case 'send_menu':
      summaryText = `Menu with ${action.data?.items?.length || 0} options`;
      break;
  }

  const handleActionClick = (e) => {
    e.stopPropagation(); // Stop the click from bubbling up to the parent block
    onSelect();
  };

  const handleDeleteClick = (e) => {
    e.stopPropagation(); // Stop the click from bubbling up to the parent block
    onDelete();
  };

  return (
    <div className="group flex items-center justify-between p-2 hover:bg-gray-100 rounded-md cursor-pointer" onClick={handleActionClick}>
      <div className="flex items-center gap-3">
        <Icon className="w-4 h-4 text-gray-500" />
        <div className="flex flex-col">
          <span className="text-xs font-bold text-gray-700 capitalize">{action.type.replace(/_/g, ' ')}</span>
          <span className="text-xs text-gray-500">{summaryText}</span>
        </div>
      </div>
       <Button
          variant="ghost"
          size="icon"
          className="w-6 h-6 rounded-full opacity-0 group-hover:opacity-100"
          onClick={handleDeleteClick}
        >
          <Trash2 className="w-3 h-3 text-red-500" />
        </Button>
    </div>
  );
};

export default function FlowNode({ data, onSelectAction, onDeleteAction, onAddAction }) {
  // Ensure data.actions exists and is an array
  const actions = data.actions || [];
  
  const handleAddClick = (e) => {
    e.stopPropagation(); // Stop the click from bubbling up to the parent node
    onAddAction();
  };

  return (
    <div className="border bg-white rounded-lg shadow-lg w-72">
      <div className="bg-gray-50 p-3 border-b rounded-t-lg">
        <input 
          type="text" 
          defaultValue={data.name || 'Untitled Block'} 
          className="text-sm font-bold text-gray-800 bg-transparent w-full focus:outline-none focus:ring-1 focus:ring-blue-400 rounded px-1"
          // Add onchange handler later to update state
        />
      </div>
      <div className="p-2 space-y-1">
        {actions.map((action) => (
          <ActionSummary 
            key={action.id} 
            action={action} 
            onSelect={() => onSelectAction(action.id)}
            onDelete={() => onDeleteAction(action.id)}
          />
        ))}
        {actions.length === 0 && (
          <div className="text-center py-4 text-gray-500 text-xs">
            No actions yet. Click "Add Action" below.
          </div>
        )}
      </div>
      <div className="p-2 border-t">
        <Button variant="ghost" className="w-full justify-center" onClick={handleAddClick}>
          <Plus className="w-4 h-4 mr-2" />
          Add Action
        </Button>
      </div>
    </div>
  );
}