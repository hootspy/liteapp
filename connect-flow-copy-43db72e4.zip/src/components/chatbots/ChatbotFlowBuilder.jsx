import React, { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Save, Eye, Plus, Trash2 } from "lucide-react";

import FlowInspector from './FlowInspector';
import FlowCanvas from './FlowCanvas';
import { getDefaultNodeData } from "../utils/flowUtils";

let blockIdCounter = 1;
const generateBlockId = () => `block_${Date.now()}_${blockIdCounter++}`;

export default function ChatbotFlowBuilder({ chatbot, onSave, onBack }) {
  const [nodes, setNodes] = useState(chatbot?.flow_data?.nodes || []);
  const [edges, setEdges] = useState(chatbot?.flow_data?.edges || []);
  const [selectedItem, setSelectedItem] = useState(null); // { blockId, actionId, mode: 'edit_block' | 'edit_action' | 'add_action' }

  // -- BLOCK-LEVEL OPERATIONS --

  const handleAddBlock = useCallback(() => {
    const newBlock = {
      id: generateBlockId(),
      type: 'custom', // All new blocks are custom containers
      position: { x: Math.random() * 400 + 100, y: Math.random() * 200 + 100 },
      data: { name: 'New Block', actions: [] },
    };
    setNodes(prev => [...prev, newBlock]);
    setSelectedItem({ blockId: newBlock.id, mode: 'edit_block' });
  }, []);

  const handleDeleteBlock = useCallback((blockId) => {
    setNodes(prev => prev.filter(node => node.id !== blockId));
    setEdges(prev => prev.filter(edge => edge.source !== blockId && edge.target !== blockId));
    if (selectedItem?.blockId === blockId) {
      setSelectedItem(null);
    }
  }, [selectedItem]);

  const handleBlockMove = useCallback((blockId, position) => {
    setNodes(prev => prev.map(node => node.id === blockId ? { ...node, position } : node));
  }, []);
  
  const handleBlockDataUpdate = useCallback((blockId, updatedData) => {
     setNodes(prev => prev.map(node => {
      if (node.id === blockId) {
        return { ...node, data: { ...node.data, ...updatedData }};
      }
      return node;
    }));
  }, []);

  // -- ACTION-LEVEL OPERATIONS --

  const handleAddAction = useCallback((blockId, actionType) => {
    const newAction = getDefaultNodeData(actionType);
    
    setNodes(prev => prev.map(node => {
      if (node.id === blockId) {
        const newActions = [...(node.data.actions || []), newAction];
        return { ...node, data: { ...node.data, actions: newActions }};
      }
      return node;
    }));
    
    setSelectedItem({ blockId, actionId: newAction.id, mode: 'edit_action' });
  }, []);

  const handleActionUpdate = useCallback((blockId, actionId, updatedActionData) => {
    setNodes(prev => prev.map(node => {
      if (node.id === blockId) {
        const newActions = (node.data.actions || []).map(action => 
          action.id === actionId 
            ? { ...action, data: { ...action.data, ...updatedActionData } }
            : action
        );
        return { ...node, data: { ...node.data, actions: newActions } };
      }
      return node;
    }));
  }, []);

  const handleDeleteAction = useCallback((blockId, actionId) => {
    setNodes(prev => prev.map(node => {
      if (node.id === blockId) {
        const newActions = (node.data.actions || []).filter(action => action.id !== actionId);
        return { ...node, data: { ...node.data, actions: newActions }};
      }
      return node;
    }));
    // If the deleted action was selected, close the inspector
    if (selectedItem?.actionId === actionId) {
        setSelectedItem(null);
    }
  }, [selectedItem]);


  // -- CONNECTION & UI OPERATIONS --

  const handleConnect = useCallback((connection) => {
    const newEdge = {
      id: `edge-${connection.source}-${connection.target}`,
      source: connection.source,
      target: connection.target,
    };
    setEdges(prev => [...prev, newEdge]);
  }, []);

  const handleDeleteEdge = useCallback((edgeId) => {
    setEdges(prev => prev.filter(edge => edge.id !== edgeId));
  }, []);

  const handleSaveFlow = () => {
    const flowData = { nodes, edges };
    onSave({ ...chatbot, flow_data: flowData });
  };

  const handleCanvasClick = (e) => {
    if (e.target === e.currentTarget) {
      setSelectedItem(null);
    }
  };

  const onSelectBlock = (node) => setSelectedItem({ blockId: node.id, mode: 'edit_block' });
  const onSelectAction = (blockId, actionId) => setSelectedItem({ blockId, actionId, mode: 'edit_action' });
  const onTriggerAddAction = (blockId) => setSelectedItem({ blockId, mode: 'add_action' });
  const closeInspector = () => setSelectedItem(null);


  // -- INITIALIZATION --
  React.useEffect(() => {
    if (nodes.length === 0) {
      const startNode = {
        id: 'start_node',
        type: 'start',
        position: { x: 300, y: 100 },
        data: { name: 'Start', message: 'Conversation Started', actions: [] },
      };
      setNodes([startNode]);
    }
  }, [nodes.length]);

  return (
    <div className="h-full flex flex-col bg-gray-100">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 bg-white flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <div>
            <h1 className="text-xl font-bold text-gray-900">Flow Builder: {chatbot.name}</h1>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={handleAddBlock}>
            <Plus className="w-4 h-4 mr-2" /> Add Block
          </Button>
          <Button variant="outline" size="sm">
            <Eye className="w-4 h-4 mr-2" /> Preview
          </Button>
          <Button onClick={handleSaveFlow} size="sm" className="bg-blue-600 hover:bg-blue-700">
            <Save className="w-4 h-4 mr-2" /> Save Flow
          </Button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Main Canvas */}
        <div className="flex-1 relative">
          <FlowCanvas
            nodes={nodes}
            edges={edges}
            selectedItem={selectedItem}
            onBlockClick={onSelectBlock}
            onNodeMove={handleBlockMove}
            onConnect={handleConnect}
            onDeleteNode={handleDeleteBlock}
            onDeleteEdge={handleDeleteEdge}
            onCanvasClick={handleCanvasClick}
            onSelectAction={onSelectAction}
            onDeleteAction={handleDeleteAction}
            onTriggerAddAction={onTriggerAddAction}
          />
        </div>
        
        {/* Inspector Panel - only show when an item is selected */}
        {selectedItem && (
          <FlowInspector 
            nodes={nodes}
            selectedItem={selectedItem}
            onBlockUpdate={handleBlockDataUpdate}
            onActionUpdate={handleActionUpdate}
            onActionAdd={handleAddAction}
            onClose={closeInspector}
          />
        )}
      </div>
    </div>
  );
}