import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Edit, 
  Trash2, 
  Play, 
  Pause, 
  Settings,
  MessageCircleReply,
  MoreVertical,
  Workflow
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";

export default function ChatbotsList({ 
  chatbots, 
  isLoading, 
  onEdit, 
  onBuildFlow, 
  onToggleActive, 
  onDelete,
  type = "inbound"
}) {
  if (isLoading) {
    return (
      <div className="border rounded-lg bg-white">
        <div className="space-y-2 p-4">
          {Array(3).fill(0).map((_, i) => (
            <div key={i} className="flex items-center justify-between py-2">
              <div className="flex items-center gap-4">
                <Skeleton className="h-10 w-10 rounded-lg" />
                <div>
                  <Skeleton className="h-5 w-40 mb-2" />
                  <Skeleton className="h-4 w-60" />
                </div>
              </div>
              <div className="flex items-center gap-6">
                <Skeleton className="h-6 w-20" />
                <Skeleton className="h-6 w-24" />
                <Skeleton className="h-8 w-8 rounded-full" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (chatbots.length === 0) {
    const emptyStateConfig = {
      inbound: {
        icon: MessageCircleReply,
        title: "No inbound chatbots yet",
        description: "Create your first inbound chatbot to automatically respond to customer messages",
        color: "text-blue-400"
      },
      automation: {
        icon: Workflow,
        title: "No automations yet", 
        description: "Create your first automation to streamline your business processes",
        color: "text-purple-400"
      }
    };

    const config = emptyStateConfig[type];
    const IconComponent = config.icon;

    return (
      <div className="text-center py-12 border bg-white rounded-lg">
        <div className={`w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4`}>
          <IconComponent className={`w-10 h-10 ${config.color}`} />
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">{config.title}</h3>
        <p className="text-gray-500 mb-6">{config.description}</p>
      </div>
    );
  }

  return (
    <div className="border rounded-lg bg-white">
      {chatbots.map((chatbot, index) => {
        const isInbound = chatbot.type === "inbound";
        const iconConfig = isInbound 
          ? { icon: MessageCircleReply, gradient: "from-blue-500 to-blue-600" }
          : { icon: Workflow, gradient: "from-purple-500 to-purple-600" };

        const IconComponent = iconConfig.icon;

        return (
          <div key={chatbot.id} className={`flex items-center justify-between p-4 ${index < chatbots.length - 1 ? 'border-b' : ''} hover:bg-gray-50 transition-colors`}>
            {/* Left Section: Icon, Name, Type */}
            <div className="flex items-center gap-4 flex-1 min-w-0">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                chatbot.is_active 
                  ? `bg-gradient-to-r ${iconConfig.gradient}` 
                  : "bg-gray-400"
              }`}>
                <IconComponent className="w-5 h-5 text-white" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{chatbot.name}</p>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline" className={`text-xs ${isInbound ? "text-blue-600 border-blue-200" : "text-purple-600 border-purple-200"}`}>
                    {isInbound ? "Inbound" : "Automation"}
                  </Badge>
                  <p className="text-xs text-gray-500 truncate">{chatbot.description || "No description"}</p>
                </div>
              </div>
            </div>
            
            {/* Right Section: Status, Date, Actions */}
            <div className="flex items-center gap-6 ml-4">
              <Badge variant={chatbot.is_active ? "default" : "secondary"} className="w-20 justify-center">
                {chatbot.is_active ? "Active" : "Inactive"}
              </Badge>

              <div className="hidden lg:block text-xs text-gray-500 w-28 text-center">
                Updated <br/> {format(new Date(chatbot.updated_date), 'MMM d, yyyy')}
              </div>
              
              <div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => onEdit(chatbot)}>
                      <Edit className="w-4 h-4 mr-2" />
                      Edit Details
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onBuildFlow(chatbot)}>
                      <Settings className="w-4 h-4 mr-2" />
                      Build Flow
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onToggleActive(chatbot)}>
                      {chatbot.is_active ? (
                        <>
                          <Pause className="w-4 h-4 mr-2" />
                          Deactivate
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 mr-2" />
                          Activate
                        </>
                      )}
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      onClick={() => onDelete(chatbot)}
                      className="text-red-600"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}