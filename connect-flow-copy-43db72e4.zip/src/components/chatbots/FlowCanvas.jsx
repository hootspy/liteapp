
import React, { useState, useRef, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";

// Import custom node components
import StartNode from './nodes/StartNode';
import FlowNode from './nodes/FlowNode';

const nodeComponents = {
  start: StartNode,
  custom: FlowNode,
};

const ConnectionHandle = ({ nodeId, type, position, onMouseDown }) => (
  <div
    className={`absolute w-4 h-4 bg-blue-500 border-2 border-white rounded-full cursor-crosshair hover:bg-blue-600 shadow-lg z-20 transition-colors ${
      position === 'left' ? '-left-2 top-1/2 -translate-y-1/2' :
      '-right-2 top-1/2 -translate-y-1/2'
    }`}
    onMouseDown={(e) => {
      e.stopPropagation();
      onMouseDown(e, nodeId, type, position);
    }}
  />
);

const NodeWrapper = ({ 
  node, isSelected, onClick, onMove, onDelete, onConnectionStart, 
  scrollOffset, onSelectAction, onDeleteAction, onTriggerAddAction 
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  const handleMouseDown = useCallback((e) => {
    // Prevent dragging if a handle or an input inside the node is clicked
    if (e.target.closest('.connection-handle') || e.target.closest('input, button, .action-item')) return;
    
    setIsDragging(true);
    setDragStart({
      x: e.clientX + scrollOffset.x - node.position.x,
      y: e.clientY + scrollOffset.y - node.position.y,
    });
    
    e.preventDefault();
  }, [node.position, scrollOffset.x, scrollOffset.y]);

  const handleMouseMove = useCallback((e) => {
    if (!isDragging) return;
    
    const newPosition = {
      x: e.clientX + scrollOffset.x - dragStart.x,
      y: e.clientY + scrollOffset.y - dragStart.y,
    };
    
    onMove(node.id, newPosition);
  }, [isDragging, dragStart, node.id, onMove, scrollOffset.x, scrollOffset.y]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  React.useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, handleMouseMove, handleMouseUp]);

  const NodeComponent = nodeComponents[node.type] || FlowNode;
  
  return (
    <div
      className={`absolute cursor-move ${isDragging ? 'z-50' : 'z-10'} group`}
      style={{
        left: node.position.x,
        top: node.position.y,
      }}
      onMouseDown={handleMouseDown}
    >
      {/* Source handle on the right side */}
      <ConnectionHandle 
        nodeId={node.id} 
        type="source" 
        position="right" 
        onMouseDown={onConnectionStart} 
      />
      
      {/* Target handle on the left side */}
      <ConnectionHandle 
        nodeId={node.id} 
        type="target" 
        position="left" 
        onMouseDown={onConnectionStart} 
      />
      
      <div 
        className={`${isSelected ? 'ring-2 ring-blue-500 ring-offset-2' : ''} ${isDragging ? 'shadow-2xl scale-105' : ''} transition-all`}
        onClick={() => onClick(node)}
      >
        <NodeComponent 
          data={node.data} 
          onSelectAction={(actionId) => onSelectAction(node.id, actionId)}
          onDeleteAction={(actionId) => onDeleteAction(node.id, actionId)}
          onAddAction={() => onTriggerAddAction(node.id)}
        />
      </div>
      
      {node.type !== 'start' && (
        <Button
          variant="destructive"
          size="icon"
          className="absolute -top-2 -right-2 w-6 h-6 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={(e) => {
            e.stopPropagation();
            onDelete(node.id);
          }}
        >
          <Trash2 className="w-3 h-3" />
        </Button>
      )}
    </div>
  );
};

const ConnectionLine = ({ edge, nodes, onDelete }) => {
  const sourceNode = nodes.find(n => n.id === edge.source);
  const targetNode = nodes.find(n => n.id === edge.target);
  
  if (!sourceNode || !targetNode) return null;

  // Calculate connection points (right side of source, left side of target)
  const sourceX = sourceNode.position.x + 288; // Right side of 288px wide node
  const sourceY = sourceNode.position.y + 60; // Middle of node (approximate)
  const targetX = targetNode.position.x; // Left side of target node
  const targetY = targetNode.position.y + 60; // Middle of node (approximate)

  // Create 90-degree angled path
  const deltaX = targetX - sourceX;
  // Calculate the midpoint for the horizontal segment
  const midX = sourceX + Math.abs(deltaX) * 0.5;
  
  // Create path with right angles
  const pathData = `M ${sourceX} ${sourceY} 
                   L ${midX} ${sourceY} 
                   L ${midX} ${targetY} 
                   L ${targetX} ${targetY}`;

  // Calculate position for delete button (at the middle of the path)
  const deleteButtonX = midX;
  const deleteButtonY = (sourceY + targetY) / 2;

  return (
    <g className="group">
      {/* Main connection line with rounded corners at bends */}
      <path 
        d={pathData} 
        stroke="#3b82f6" 
        strokeWidth="2" 
        fill="none" 
        markerEnd="url(#arrowhead)" 
        className="drop-shadow-sm"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
      
      {/* Invisible wider path for easier clicking */}
      <path 
        d={pathData} 
        stroke="transparent" 
        strokeWidth="16" 
        fill="none" 
        className="cursor-pointer" 
        onClick={() => onDelete(edge.id)} 
      />
      
      {/* Delete button that appears on hover */}
      <circle 
        cx={deleteButtonX} 
        cy={deleteButtonY} 
        r="10" 
        fill="#ef4444" 
        className="opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer drop-shadow-md" 
        onClick={() => onDelete(edge.id)} 
      />
      <text 
        x={deleteButtonX} 
        y={deleteButtonY + 3} 
        textAnchor="middle" 
        fill="white" 
        fontSize="12" 
        fontWeight="bold"
        className="pointer-events-none opacity-0 group-hover:opacity-100 select-none"
      >
        ×
      </text>
    </g>
  );
};

export default function FlowCanvas({ 
  nodes, edges, selectedItem, onBlockClick, onNodeMove, onConnect, onDeleteNode, onDeleteEdge, onCanvasClick,
  onSelectAction, onDeleteAction, onTriggerAddAction
}) {
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionStart, setConnectionStart] = useState(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isPannable, setIsPannable] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });

  const canvasRef = useRef(null);

  const getScrollOffset = () => ({
    x: canvasRef.current?.scrollLeft || 0,
    y: canvasRef.current?.scrollTop || 0,
  });

  const handleConnectionStart = useCallback((e, nodeId, type, position) => {
    setIsConnecting(true);
    const sourceNode = nodes.find(n => n.id === nodeId);
    if (!sourceNode) return;
    
    setConnectionStart({ nodeId, type, position });
    setMousePosition({
      x: sourceNode.position.x + (position === 'right' ? 288 : 0),
      y: sourceNode.position.y + 60,
    });
  }, [nodes]);

  const handleMouseMove = useCallback((e) => {
    const scrollOffset = getScrollOffset();
    const canvasRect = canvasRef.current?.getBoundingClientRect();

    if (isConnecting) {
      if (canvasRect) {
        setMousePosition({
          x: e.clientX - canvasRect.left + scrollOffset.x,
          y: e.clientY - canvasRect.top + scrollOffset.y,
        });
      }
    }
    if (isPannable) {
      const dx = e.clientX - panStart.x;
      const dy = e.clientY - panStart.y;
      canvasRef.current.scrollLeft = panStart.scrollX - dx;
      canvasRef.current.scrollTop = panStart.scrollY - dy;
    }
  }, [isConnecting, isPannable, panStart]);

  const handleMouseUp = useCallback((e) => {
    if (isConnecting && connectionStart) {
      const targetElement = e.target.closest('[data-node-id]');
      if (targetElement) {
        const targetNodeId = targetElement.getAttribute('data-node-id');
        if (targetNodeId && targetNodeId !== connectionStart.nodeId) {
          onConnect({
            source: connectionStart.nodeId,
            target: targetNodeId,
          });
        }
      }
    }
    setIsConnecting(false);
    setConnectionStart(null);
    setIsPannable(false);
    if (canvasRef.current) canvasRef.current.style.cursor = 'grab';
  }, [isConnecting, connectionStart, onConnect]);
  
  const handleCanvasMouseDown = (e) => {
    if (e.target === e.currentTarget.children[0] || e.target === e.currentTarget) {
      setIsPannable(true);
      setPanStart({
        x: e.clientX,
        y: e.clientY,
        scrollX: canvasRef.current.scrollLeft,
        scrollY: canvasRef.current.scrollTop,
      });
      if(canvasRef.current) canvasRef.current.style.cursor = 'grabbing';
      onCanvasClick(e);
    }
  };

  return (
    <div 
      ref={canvasRef}
      className={`w-full h-full relative overflow-auto cursor-grab`}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseDown={handleCanvasMouseDown}
    >
      <div 
        className="absolute"
        style={{ 
          width: '4000px', 
          height: '4000px', 
          backgroundImage: 'radial-gradient(circle, #e5e7eb 1px, transparent 1px)', 
          backgroundSize: '20px 20px' 
        }}
      >
        <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 1 }}>
          <defs>
            <marker 
              id="arrowhead" 
              markerWidth="10" 
              markerHeight="7" 
              refX="9" 
              refY="3.5" 
              orient="auto"
            >
              <polygon points="0 0, 10 3.5, 0 7" fill="#3b82f6" />
            </marker>
          </defs>
          {edges.map((edge) => (
            <ConnectionLine key={edge.id} edge={edge} nodes={nodes} onDelete={onDeleteEdge} />
          ))}
          {isConnecting && connectionStart && (() => {
            const sourceNode = nodes.find(n => n.id === connectionStart.nodeId);
            if (!sourceNode) return null;
            const startX = sourceNode.position.x + (connectionStart.position === 'right' ? 288 : 0);
            const startY = sourceNode.position.y + 60;
            
            // Create a 90-degree angled preview line
            const deltaXPreview = mousePosition.x - startX;
            const previewMidX = startX + Math.abs(deltaXPreview) * 0.5;

            const previewPath = `M ${startX} ${startY} 
                               L ${previewMidX} ${startY} 
                               L ${previewMidX} ${mousePosition.y} 
                               L ${mousePosition.x} ${mousePosition.y}`;
            
            return (
              <path
                d={previewPath}
                stroke="#3b82f6" 
                strokeWidth="2" // Changed to match connection line stroke width
                strokeDasharray="8,4"
                fill="none"
                className="opacity-70"
                strokeLinejoin="round" // Added for rounded corners
                strokeLinecap="round" // Added for rounded corners
              />
            );
          })()}
        </svg>

        {nodes.map((node) => (
          <div key={node.id} data-node-id={node.id}>
            <NodeWrapper
              node={node}
              isSelected={selectedItem?.blockId === node.id}
              onClick={onBlockClick}
              onMove={onNodeMove}
              onDelete={onDeleteNode}
              onConnectionStart={handleConnectionStart}
              scrollOffset={getScrollOffset()}
              onSelectAction={onSelectAction}
              onDeleteAction={onDeleteAction}
              onTriggerAddAction={onTriggerAddAction}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
