import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { X, Plus } from "lucide-react";

export default function ChatbotForm({ chatbot, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    type: "inbound",
    trigger_keywords: [],
    welcome_message: "",
    fallback_message: "I'm sorry, I didn't understand that. Can you please try again?",
    is_active: false
  });
  
  const [keywordInput, setKeywordInput] = useState("");

  useEffect(() => {
    if (chatbot) {
      setFormData({
        name: chatbot.name || "",
        description: chatbot.description || "",
        type: chatbot.type || "inbound",
        trigger_keywords: chatbot.trigger_keywords || [],
        welcome_message: chatbot.welcome_message || "",
        fallback_message: chatbot.fallback_message || "I'm sorry, I didn't understand that. Can you please try again?",
        is_active: chatbot.is_active || false
      });
    }
  }, [chatbot]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addKeyword = () => {
    if (keywordInput.trim() && !formData.trigger_keywords.includes(keywordInput.trim())) {
      handleInputChange("trigger_keywords", [...formData.trigger_keywords, keywordInput.trim()]);
      setKeywordInput("");
    }
  };

  const removeKeyword = (keyword) => {
    handleInputChange("trigger_keywords", formData.trigger_keywords.filter(k => k !== keyword));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  const handleKeywordKeyPress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addKeyword();
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>
          {chatbot ? "Edit Chatbot" : "Create New Chatbot"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="name">Chatbot Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleInputChange("name", e.target.value)}
              placeholder="Enter chatbot name"
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
              placeholder="Describe what this chatbot does"
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="type">Type</Label>
            <Select value={formData.type} onValueChange={(value) => handleInputChange("type", value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="inbound">Inbound Chatbot</SelectItem>
                <SelectItem value="automation">Automation</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {formData.type === "inbound" && (
            <div>
              <Label>Trigger Keywords</Label>
              <p className="text-sm text-gray-500 mb-2">
                Keywords that will trigger this chatbot when customers message them
              </p>
              <div className="flex gap-2 mb-3">
                <Input
                  value={keywordInput}
                  onChange={(e) => setKeywordInput(e.target.value)}
                  onKeyPress={handleKeywordKeyPress}
                  placeholder="Enter a keyword and press Enter"
                />
                <Button type="button" onClick={addKeyword} variant="outline">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.trigger_keywords.map((keyword, index) => (
                  <Badge key={index} variant="secondary" className="flex items-center gap-1">
                    {keyword}
                    <X 
                      className="w-3 h-3 cursor-pointer" 
                      onClick={() => removeKeyword(keyword)}
                    />
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <div>
            <Label htmlFor="welcome_message">Welcome Message</Label>
            <Textarea
              id="welcome_message"
              value={formData.welcome_message}
              onChange={(e) => handleInputChange("welcome_message", e.target.value)}
              placeholder="The first message users will see"
              rows={2}
            />
          </div>

          <div>
            <Label htmlFor="fallback_message">Fallback Message</Label>
            <Textarea
              id="fallback_message"
              value={formData.fallback_message}
              onChange={(e) => handleInputChange("fallback_message", e.target.value)}
              placeholder="Message when chatbot doesn't understand"
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
              {chatbot ? "Update Chatbot" : "Create Chatbot"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}