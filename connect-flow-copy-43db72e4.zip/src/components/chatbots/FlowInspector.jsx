
import React from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  X, 
  MessageSquare, 
  Tag,
  Mailbox,
  HelpCircle,
  List,
  PlusCircle,
  Users,
  CheckCircle,
  Clock,
  GitBranch,
  Settings2,
  Send,
  Hourglass
} from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const actionCategories = [
  {
    name: 'Messages',
    actions: [
      { type: 'send_message', label: 'Send Message', icon: MessageSquare },
      { type: 'send_template_message', label: 'Send Template Message', icon: Mailbox },
      { type: 'send_question', label: 'Send Question', icon: HelpCircle },
      { type: 'send_menu', label: 'Send a Menu', icon: List },
    ]
  },
  {
    name: 'Contact',
    actions: [
      { type: 'automation_enroll', label: 'Add or Remove from Automation', icon: PlusCircle },
      { type: 'tag_contact', label: 'Add or Remove a Tag', icon: Tag },
    ]
  },
  {
    name: 'Conversation',
    actions: [
      { type: 'transfer_conversation', label: 'Transfer', icon: Users },
      { type: 'finish_conversation', label: 'Finish Conversation', icon: CheckCircle },
    ]
  },
  {
    name: 'Time',
    actions: [
      { type: 'wait_for_reply', label: 'Wait for contact\'s message', icon: Hourglass },
      { type: 'wait_time', label: 'Waiting Time', icon: Clock },
    ]
  },
  {
    name: 'Flow',
    actions: [
      { type: 'condition', label: 'Add Conditions', icon: GitBranch },
    ]
  },
  {
    name: 'Advanced',
    actions: [
      { type: 'set_metadata', label: 'Change Metadata', icon: Settings2 },
      { type: 'send_webhook', label: 'Send Webhook', icon: Send },
    ]
  }
];

const BlockEditor = ({ block, onUpdate }) => {
  if (!block) return null;
  return (
    <div className="space-y-4">
      <h4 className="font-semibold text-gray-700">Block Settings</h4>
      <div>
        <Label htmlFor="block-name">Block Name</Label>
        <Input
          id="block-name"
          value={block.data.name}
          onChange={(e) => onUpdate({ name: e.target.value })}
          placeholder="Enter block name"
        />
      </div>
    </div>
  );
};

const ActionEditor = ({ action, onUpdate }) => {
  if (!action) return null;

  const getActionLabel = (type) => {
    for (const category of actionCategories) {
      const foundAction = category.actions.find(a => a.type === type);
      if (foundAction) return foundAction.label;
    }
    return type.replace(/_/g, ' '); // Fallback for unknown types
  };

  const actionLabel = getActionLabel(action.type);

  return (
    <div className="space-y-4">
      <h4 className="font-semibold text-gray-700">{actionLabel} Settings</h4>
      {action.type === 'send_message' && (
        <div>
          <Label htmlFor="action-message">Message</Label>
          <Textarea
            id="action-message"
            value={action.data.message || ''}
            onChange={(e) => onUpdate({ message: e.target.value })}
            placeholder="Enter your message"
            rows={4}
          />
        </div>
      )}
      
      {action.type === 'send_template_message' && (
        <div>
          <Label htmlFor="action-template">Template ID</Label>
          <Input
            id="action-template"
            value={action.data.templateId || ''}
            onChange={(e) => onUpdate({ templateId: e.target.value })}
            placeholder="template_id_123"
          />
        </div>
      )}
      
      {action.type === 'send_question' && (
        <div>
          <Label htmlFor="action-question">Question</Label>
          <Textarea
            id="action-question"
            value={action.data.question || ''}
            onChange={(e) => onUpdate({ question: e.target.value })}
            placeholder="What is your name?"
          />
        </div>
      )}
      
      {action.type === 'send_menu' && (
        <div>
          <Label htmlFor="action-menu">Menu Text</Label>
          <Textarea
            id="action-menu"
            value={action.data.text || ''}
            onChange={(e) => onUpdate({ text: e.target.value })}
            placeholder="Please select an option:"
          />
        </div>
      )}
      
      {action.type === 'automation_enroll' && (
        <div className="space-y-4">
          <div>
            <Label htmlFor="action-automation-action">Action</Label>
            <Select value={action.data.action || 'add'} onValueChange={(value) => onUpdate({ action: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Select action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="add">Add to Automation</SelectItem>
                <SelectItem value="remove">Remove from Automation</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="action-automation">Automation ID</Label>
            <Input
              id="action-automation"
              value={action.data.automationId || ''}
              onChange={(e) => onUpdate({ automationId: e.target.value })}
              placeholder="automation_id_abc"
            />
          </div>
        </div>
      )}
      
      {action.type === 'tag_contact' && (
        <div className="space-y-4">
          <div>
            <Label htmlFor="action-tag-action">Action</Label>
            <Select value={action.data.action || 'add'} onValueChange={(value) => onUpdate({ action: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Select action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="add">Add Tag</SelectItem>
                <SelectItem value="remove">Remove Tag</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="action-tag">Tag</Label>
            <Input
              id="action-tag"
              value={action.data.tag || ''}
              onChange={(e) => onUpdate({ tag: e.target.value })}
              placeholder="Enter tag to add/remove"
            />
          </div>
        </div>
      )}
      
      {action.type === 'transfer_conversation' && (
        <div>
          <Label htmlFor="action-team">Team ID</Label>
          <Input
            id="action-team"
            value={action.data.teamId || ''}
            onChange={(e) => onUpdate({ teamId: e.target.value })}
            placeholder="team_id_xyz"
          />
        </div>
      )}
      
      {action.type === 'finish_conversation' && (
        <div>
          <p className="text-sm text-gray-500">This action will finish the conversation. No additional settings needed.</p>
        </div>
      )}
      
      {action.type === 'wait_for_reply' && (
        <div>
          <Label htmlFor="action-timeout">Timeout (minutes)</Label>
          <Input
            id="action-timeout"
            type="number"
            value={action.data.timeout || 60}
            onChange={(e) => onUpdate({ timeout: parseInt(e.target.value) })}
            placeholder="60"
          />
        </div>
      )}
      
      {action.type === 'wait_time' && (
        <div className="space-y-4">
          <div>
            <Label htmlFor="action-duration">Duration</Label>
            <Input
              id="action-duration"
              type="number"
              value={action.data.duration || 5}
              onChange={(e) => onUpdate({ duration: parseInt(e.target.value) })}
              placeholder="5"
            />
          </div>
          <div>
            <Label htmlFor="action-unit">Unit</Label>
            <Select value={action.data.unit || 'minutes'} onValueChange={(value) => onUpdate({ unit: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Select unit" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="minutes">Minutes</SelectItem>
                <SelectItem value="hours">Hours</SelectItem>
                <SelectItem value="days">Days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      )}
      
      {action.type === 'condition' && (
        <div>
          <Label htmlFor="action-condition">Condition</Label>
          <Input
            id="action-condition"
            value={action.data.conditions?.[0]?.field || ''}
            onChange={(e) => onUpdate({ conditions: [{ field: e.target.value, operator: 'equals', value: '' }] })}
            placeholder="e.g., contact.tag equals 'VIP'"
          />
        </div>
      )}
      
      {action.type === 'set_metadata' && (
        <div className="space-y-4">
          <div>
            <Label htmlFor="action-meta-key">Metadata Key</Label>
            <Input
              id="action-meta-key"
              value={action.data.key || ''}
              onChange={(e) => onUpdate({ key: e.target.value })}
              placeholder="e.g., order_status"
            />
          </div>
          <div>
            <Label htmlFor="action-meta-value">Metadata Value</Label>
            <Input
              id="action-meta-value"
              value={action.data.value || ''}
              onChange={(e) => onUpdate({ value: e.target.value })}
              placeholder="e.g., completed"
            />
          </div>
        </div>
      )}
      
      {action.type === 'send_webhook' && (
        <div className="space-y-4">
          <div>
            <Label htmlFor="action-webhook-url">Webhook URL</Label>
            <Input
              id="action-webhook-url"
              value={action.data.url || ''}
              onChange={(e) => onUpdate({ url: e.target.value })}
              placeholder="https://api.example.com/hook"
            />
          </div>
          <div>
            <Label htmlFor="action-webhook-payload">Payload (JSON)</Label>
            <Textarea
              id="action-webhook-payload"
              value={action.data.payload || '{}'}
              onChange={(e) => onUpdate({ payload: e.target.value })}
              placeholder='{"key": "value"}'
              rows={3}
            />
          </div>
        </div>
      )}
      
      {/* Fallback for actions with no specific editor UI or unrecognized types */}
      {!(['send_message', 'send_template_message', 'send_question', 'send_menu',
          'automation_enroll', 'tag_contact', 'transfer_conversation', 'finish_conversation',
          'wait_for_reply', 'wait_time', 'condition', 'set_metadata', 'send_webhook'].includes(action.type)) && (
        <p className="text-sm text-gray-500">This action has no configurable settings.</p>
      )}
    </div>
  );
};

const AddActionSelector = ({ onSelect }) => {
  const getIconColor = (actionType) => {
    switch (actionType) {
      // Messages - Green shades
      case 'send_message':
        return 'text-green-600';
      case 'send_template_message':
        return 'text-green-500';
      case 'send_question':
        return 'text-green-700';
      case 'send_menu':
        return 'text-green-600';
      
      // Contact - Blue shades
      case 'automation_enroll':
        return 'text-blue-600';
      case 'tag_contact':
        return 'text-blue-500';
      
      // Conversation - Purple shades
      case 'transfer_conversation':
        return 'text-purple-600';
      case 'finish_conversation':
        return 'text-purple-500';
      
      // Time - Orange shades
      case 'wait_for_reply':
        return 'text-orange-600';
      case 'wait_time':
        return 'text-orange-500';
      
      // Flow - Indigo shades
      case 'condition':
        return 'text-indigo-600';
      
      // Advanced - Red shades
      case 'set_metadata':
        return 'text-red-600';
      case 'send_webhook':
        return 'text-red-500';
      
      default:
        return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-4">
      {actionCategories.map(category => (
        <div key={category.name}>
          <h4 className="font-semibold text-sm text-gray-500 mb-2">{category.name}</h4>
          <div className="space-y-2">
            {category.actions.map(option => {
              const Icon = option.icon;
              const iconColor = getIconColor(option.type);
              return (
                <Button
                  key={option.type}
                  variant="outline"
                  className="w-full justify-start gap-3 p-4 h-auto hover:bg-gray-50 transition-colors"
                  onClick={() => onSelect(option.type)}
                >
                  <Icon className={`w-5 h-5 ${iconColor}`} />
                  <span className="font-medium">{option.label}</span>
                </Button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
};

export default function FlowInspector({ nodes, selectedItem, onBlockUpdate, onActionUpdate, onActionAdd, onClose }) {
  if (!selectedItem) {
    return (
      <div className="w-80 bg-white border-l border-gray-200 p-6 overflow-y-auto flex flex-col">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-semibold text-gray-900">Flow Inspector</h3>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex-1 flex items-center justify-center text-gray-500 text-sm">
          No item selected. Select a block or action to edit its properties.
        </div>
      </div>
    );
  }

  const { blockId, actionId, mode } = selectedItem;
  const currentBlock = nodes.find(n => n.id === blockId);
  const currentAction = currentBlock?.data.actions?.find(a => a.id === actionId);

  const getTitle = () => {
    switch (mode) {
      case 'edit_block':
        return `Edit Block: ${currentBlock?.data.name || 'Untitled Block'}`;
      case 'edit_action':
        // Find the action label from actionCategories for a user-friendly title
        const actionLabel = actionCategories
          .flatMap(cat => cat.actions)
          .find(a => a.type === currentAction?.type)?.label;
        return `Edit Action: ${actionLabel || (currentAction?.type.replace(/_/g, ' ') || 'Untitled Action')}`;
      case 'add_action':
        return 'Add New Action';
      default:
        return 'Inspector';
    }
  };
  
  return (
    <div className="w-80 bg-white border-l border-gray-200 p-6 overflow-y-auto flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-semibold text-gray-900">{getTitle()}</h3>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      <div className="space-y-4 flex-1">
        {mode === 'edit_block' && currentBlock && (
          <BlockEditor 
            block={currentBlock} 
            onUpdate={(data) => onBlockUpdate(blockId, data)} 
          />
        )}
        {mode === 'edit_action' && currentAction && (
          <ActionEditor 
            action={currentAction}
            onUpdate={(data) => onActionUpdate(blockId, actionId, data)}
          />
        )}
        {mode === 'add_action' && (
          <AddActionSelector onSelect={(actionType) => onActionAdd(blockId, actionType)} />
        )}
      </div>
    </div>
  );
}
