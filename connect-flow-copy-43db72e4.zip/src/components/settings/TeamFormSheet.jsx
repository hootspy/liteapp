
import React, { useState, useEffect, useCallback } from "react";
import { Chatbot } from "@/api/entities";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Globe, Users, UserCog, Clock, Zap } from "lucide-react";

export default function TeamFormSheet({
  isOpen,
  onOpenChange,
  team,
  onSave,
  allUsers,
  allChannels,
  organizationId,
}) {
  const [formData, setFormData] = useState({});
  const [availableAutomations, setAvailableAutomations] = useState([]);
  const [loadingAutomations, setLoadingAutomations] = useState(false);

  useEffect(() => {
    if (team) {
      setFormData({
        id: team.id,
        name: team.name || "",
        description: team.description || "",
        is_standard_team: team.is_standard_team || false,
        channels: team.channels || [],
        conversation_access: team.conversation_access || "team",
        smart_distribution: team.smart_distribution || false,
        waiting_time_minutes: team.waiting_time_minutes || 5,
        timeout_action: team.timeout_action || "next_user",
        timeout_automation_id: team.timeout_automation_id || "",
        members: team.members || [],
        team_admins: team.team_admins || [],
      });
    } else {
      // Default for new team
      setFormData({
        name: "",
        description: "",
        is_standard_team: false,
        channels: [],
        conversation_access: "team",
        smart_distribution: false,
        waiting_time_minutes: 5,
        timeout_action: "next_user",
        timeout_automation_id: "",
        members: [],
        team_admins: [],
      });
    }
  }, [team, isOpen]);

  const loadAutomations = useCallback(async () => {
    if (!organizationId) return;
    setLoadingAutomations(true);
    try {
      const automations = await Chatbot.filter({ 
        organization_id: organizationId, 
        type: "automation",
        is_active: true 
      });
      setAvailableAutomations(automations);
    } catch (error) {
      console.error("Error loading automations:", error);
      setAvailableAutomations([]);
    }
    setLoadingAutomations(false);
  }, [organizationId]);

  // Load automations when smart distribution is enabled and sheet is open
  useEffect(() => {
    if (isOpen && formData.smart_distribution && organizationId) {
      loadAutomations();
    }
  }, [isOpen, formData.smart_distribution, organizationId, loadAutomations]);

  const handleValueChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleMultiSelectChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter((item) => item !== value)
        : [...prev[field], value],
    }));
  };

  const handleSave = () => {
    onSave(formData);
  };
  
  const isEditing = !!team?.id;

  return (
    <Sheet open={isOpen} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-lg w-full flex flex-col">
        <SheetHeader className="px-6 pt-6">
          <SheetTitle>{isEditing ? "Edit Team" : "Create New Team"}</SheetTitle>
          <SheetDescription>
            {isEditing ? "Update the details for this team." : "Set up a new team for your workspace."}
          </SheetDescription>
        </SheetHeader>
        <Separator className="my-4" />
        <ScrollArea className="flex-1 px-6">
          <div className="space-y-6">
            <div>
              <Label htmlFor="name">Team Name</Label>
              <Input
                id="name"
                value={formData.name || ""}
                onChange={(e) => handleValueChange("name", e.target.value)}
                placeholder="e.g., Sales Team"
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div>
                <Label htmlFor="is_standard_team">Standard Team</Label>
                <p className="text-xs text-gray-500">Default for new unassigned conversations.</p>
              </div>
              <Switch
                id="is_standard_team"
                checked={formData.is_standard_team || false}
                onCheckedChange={(checked) => handleValueChange("is_standard_team", checked)}
              />
            </div>
            
            <div className="space-y-3">
              <Label>Conversations Access</Label>
              <RadioGroup
                value={formData.conversation_access || "team"}
                onValueChange={(value) => handleValueChange("conversation_access", value)}
                className="space-y-1"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="team" id="access-team" />
                  <Label htmlFor="access-team" className="font-normal">
                    Access all conversations assigned to the team
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="individual" id="access-individual" />
                  <Label htmlFor="access-individual" className="font-normal">
                    Only access conversations assigned to them
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 rounded-lg border">
                <div>
                  <Label htmlFor="smart_distribution">Smart Distribution</Label>
                  <p className="text-xs text-gray-500">Round-robin conversation assignment.</p>
                </div>
                <Switch
                  id="smart_distribution"
                  checked={formData.smart_distribution || false}
                  onCheckedChange={(checked) => handleValueChange("smart_distribution", checked)}
                />
              </div>

              {/* Smart Distribution Options - Only show when enabled */}
              {formData.smart_distribution && (
                <div className="ml-4 space-y-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center gap-2 mb-3">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <Label className="text-blue-800 font-medium">Smart Distribution Settings</Label>
                  </div>
                  
                  <div>
                    <Label htmlFor="waiting_time">Waiting Time (minutes)</Label>
                    <Input
                      id="waiting_time"
                      type="number"
                      min="1"
                      max="60"
                      value={formData.waiting_time_minutes || 5}
                      onChange={(e) => handleValueChange("waiting_time_minutes", parseInt(e.target.value) || 5)}
                      placeholder="5"
                      className="bg-white"
                    />
                    <p className="text-xs text-gray-600 mt-1">Time before escalating to next action</p>
                  </div>

                  <div className="space-y-3">
                    <Label>When waiting time expires:</Label>
                    <RadioGroup
                      value={formData.timeout_action || "next_user"}
                      onValueChange={(value) => handleValueChange("timeout_action", value)}
                      className="space-y-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="next_user" id="timeout-next-user" />
                        <Label htmlFor="timeout-next-user" className="font-normal">
                          Send to next user in round-robin
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="automation" id="timeout-automation" />
                        <Label htmlFor="timeout-automation" className="font-normal">
                          Trigger an automation
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {/* Automation Selection - Only show when automation option is selected */}
                  {formData.timeout_action === "automation" && (
                    <div>
                      <Label htmlFor="timeout_automation">Select Automation</Label>
                      <Select
                        value={formData.timeout_automation_id || ""}
                        onValueChange={(value) => handleValueChange("timeout_automation_id", value)}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="Choose an automation..." />
                        </SelectTrigger>
                        <SelectContent>
                          {loadingAutomations ? (
                            <SelectItem value={null} disabled>Loading automations...</SelectItem>
                          ) : availableAutomations.length > 0 ? (
                            availableAutomations.map((automation) => (
                              <SelectItem key={automation.id} value={automation.id}>
                                <div className="flex items-center gap-2">
                                  <Zap className="w-3 h-3 text-purple-600" />
                                  <span>{automation.name}</span>
                                </div>
                              </SelectItem>
                            ))
                          ) : (
                            <SelectItem value={null} disabled>No active automations available</SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-gray-600 mt-1">
                        The automation will be triggered when no team member responds within the waiting time
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>

            <Separator />

            <div>
              <h3 className="text-sm font-medium flex items-center gap-2 mb-3"><Globe className="w-4 h-4" />Team Channels</h3>
              <div className="space-y-2">
                {allChannels.map((channel) => (
                  <div key={channel.id} className="flex items-center gap-3">
                    <Checkbox
                      id={`channel-${channel.id}`}
                      checked={(formData.channels || []).includes(channel.id)}
                      onCheckedChange={() => handleMultiSelectChange("channels", channel.id)}
                    />
                    <Label htmlFor={`channel-${channel.id}`} className="font-normal capitalize">
                      {channel.name} ({channel.channel_type})
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <Separator />
            
            <div>
              <h3 className="text-sm font-medium flex items-center gap-2 mb-3"><Users className="w-4 h-4" />Team Members</h3>
              <ScrollArea className="h-40 border rounded-md p-2">
                <div className="space-y-2">
                  {allUsers.map((user) => (
                    <div key={user.id} className="flex items-center gap-3">
                      <Checkbox
                        id={`member-${user.id}`}
                        checked={(formData.members || []).includes(user.id)}
                        onCheckedChange={() => handleMultiSelectChange("members", user.id)}
                      />
                      <Label htmlFor={`member-${user.id}`} className="font-normal">
                        {user.full_name} <span className="text-gray-500">({user.email})</span>
                      </Label>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
            
            <div>
              <h3 className="text-sm font-medium flex items-center gap-2 mb-3"><UserCog className="w-4 h-4" />Team Admins</h3>
              <ScrollArea className="h-40 border rounded-md p-2">
                <div className="space-y-2">
                  {allUsers.map((user) => (
                    <div key={user.id} className="flex items-center gap-3">
                      <Checkbox
                        id={`admin-${user.id}`}
                        checked={(formData.team_admins || []).includes(user.id)}
                        onCheckedChange={() => handleMultiSelectChange("team_admins", user.id)}
                      />
                      <Label htmlFor={`admin-${user.id}`} className="font-normal">
                        {user.full_name} <span className="text-gray-500">({user.email})</span>
                      </Label>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </div>
        </ScrollArea>
        <SheetFooter className="px-6 py-4 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
            Save Team
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
