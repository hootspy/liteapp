
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Organization } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, MoreVertical, Mail, Shield, Edit, Building } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import EditUserDialog from "./EditUserDialog";

export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [organizations, setOrganizations] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);

  useEffect(() => {
    const init = async () => {
        try {
            const user = await User.me();
            setCurrentUser(user);
            if (user.role === 'platform_admin') {
              const [usersData, orgsData] = await Promise.all([
                  User.list(),
                  Organization.list()
              ]);
              setUsers(usersData);
              setOrganizations(orgsData);
            } else if (user.organization_id) {
                await loadUsers(user.organization_id); // Await this call
                const orgData = await Organization.get(user.organization_id);
                setOrganizations([orgData]);
            } else {
                setUsers([]);
            }
        } catch(e) {
            console.error("Error fetching initial data:", e);
        }
        setIsLoading(false);
    }
    init();
  }, []);

  const loadUsers = async (orgId) => {
    setIsLoading(true);
    try {
      const data = orgId
        ? await User.filter({ organization_id: orgId })
        : await User.list();
      setUsers(data);
    } catch (error) {
      console.error("Error loading users:", error);
    }
    setIsLoading(false);
  };

  const handleEditClick = (user) => {
    setEditingUser(user);
    setIsEditDialogOpen(true);
  };

  const handleSaveUser = async (updatedData) => {
    if (!editingUser) return;
    try {
      const response = await User.update(editingUser.id, updatedData);
      setUsers(users.map(u => u.id === editingUser.id ? { ...u, ...response } : u));
      setIsEditDialogOpen(false);
      setEditingUser(null);
    } catch (error) {
      console.error("Failed to update user:", error);
      // Optionally show a user-friendly error message
    }
  };

  const filteredUsers = users.filter(user =>
    user.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getRoleColor = (role) => {
    switch (role) {
      case 'platform_admin': return 'bg-red-100 text-red-800';
      case 'admin': return 'bg-purple-100 text-purple-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getOrgName = (orgId) => {
      if (!orgId) return <Badge variant="outline" className="bg-gray-100 text-gray-700">Unassigned</Badge>;
      const org = organizations.find(o => o.id === orgId);
      return org ? org.name : "Unknown Org";
  };

  return (
    <div className="p-6">
      {/* Invite User Dialog */}
      <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>How to Invite Users</DialogTitle>
            <DialogDescription>
              To add new users to your organization, please use the platform's built-in invitation system.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="font-semibold text-gray-800">Follow these steps:</p>
            <ol className="list-decimal list-inside mt-2 space-y-2 text-sm text-gray-700">
              <li>Navigate to the <span className="font-semibold text-blue-600">Dashboard</span> tab on the main platform sidebar.</li>
              <li>Select the <span className="font-semibold text-blue-600">Users</span> section.</li>
              <li>Click the <span className="font-semibold text-blue-600">"Invite User"</span> button and enter the new user's email address.</li>
            </ol>
            <p className="mt-4 text-xs text-gray-500">
              This ensures a secure invitation process. The invited user will receive an email with instructions to join your organization.
            </p>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsInviteDialogOpen(false)}>Got it</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      {isEditDialogOpen && (
        <EditUserDialog
          user={editingUser}
          currentUser={currentUser}
          organizations={organizations}
          isOpen={isEditDialogOpen}
          onClose={() => setIsEditDialogOpen(false)}
          onSave={handleSaveUser}
        />
      )}

      {/* Page Header */}
      <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">User Management</h1>
            <p className="text-gray-500 mt-1">Manage team members and their permissions</p>
          </div>
          <Button onClick={() => setIsInviteDialogOpen(true)} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Invite User
          </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Team Members</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-gray-500">Loading users...</div>
          ) : filteredUsers.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No users found.
            </div>
          ) : (
            <div className="space-y-4">
              {filteredUsers.map((user) => (
                <div key={user.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-semibold text-sm">
                        {user.full_name?.[0]?.toUpperCase() || "U"}
                      </span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{user.full_name}</h3>
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Mail className="w-4 h-4" />
                        {user.email}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    {currentUser?.role === 'platform_admin' && (
                        <div className="hidden sm:flex items-center gap-2 text-sm text-gray-600">
                            <Building className="w-4 h-4"/>
                            {getOrgName(user.organization_id)}
                        </div>
                    )}

                    <Badge className={getRoleColor(user.role)}>
                      <Shield className="w-3 h-3 mr-1" />
                      {user.role}
                    </Badge>

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleEditClick(user)}>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit User
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          Remove User
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
