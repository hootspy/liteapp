import React, { useState, useEffect } from "react";
import { ChannelIntegration, ChannelGroup, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Plus, 
  MessageCircle, 
  MoreVertical, 
  Edit2, 
  Trash2,
  FolderPlus,
  QrCode,
  ChevronDown,
  ChevronRight
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

export default function ChannelManagement() {
  const [channels, setChannels] = useState([]);
  const [groups, setGroups] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [organizationId, setOrganizationId] = useState(null);
  const [expandedGroups, setExpandedGroups] = useState(new Set());
  
  // Dialog states
  const [isGroupDialogOpen, setIsGroupDialogOpen] = useState(false);
  const [isChannelDialogOpen, setIsChannelDialogOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState(null);
  const [selectedGroupId, setSelectedGroupId] = useState(null);
  
  // Form states
  const [groupForm, setGroupForm] = useState({ name: "", group_key: "", description: "" });
  const [channelForm, setChannelForm] = useState({ name: "", channel_key: "" });

  useEffect(() => {
    const init = async () => {
        try {
            const user = await User.me();
            if (user.organization_id) {
                setOrganizationId(user.organization_id);
                await loadData(user.organization_id);
            } else {
                setIsLoading(false);
            }
        } catch(e) {
            console.error("Error fetching user data:", e);
            setIsLoading(false);
        }
    }
    init();
  }, []);

  const loadData = async (orgId) => {
    if (!orgId) {
        setIsLoading(false);
        return;
    }
    setIsLoading(true);
    try {
      const [channelsData, groupsData] = await Promise.all([
        ChannelIntegration.filter({ organization_id: orgId }),
        ChannelGroup.filter({ organization_id: orgId })
      ]);
      setChannels(channelsData);
      setGroups(groupsData);
      
      // If no groups exist, create a default one
      if (groupsData.length === 0) {
        const defaultGroup = await ChannelGroup.create({
          organization_id: orgId,
          name: "Default Group",
          group_key: "default",
          description: "Default channel group",
          is_default: true
        });
        setGroups([defaultGroup]);
      }
    } catch (error) {
      console.error("Error loading channels and groups:", error);
    }
    setIsLoading(false);
  };

  const handleCreateGroup = async () => {
    if (!groupForm.name || !groupForm.group_key || !organizationId) return;
    
    try {
      const newGroup = await ChannelGroup.create({
        ...groupForm,
        organization_id: organizationId
      });
      setGroups([...groups, newGroup]);
      setGroupForm({ name: "", group_key: "", description: "" });
      setIsGroupDialogOpen(false);
    } catch (error) {
      console.error("Error creating group:", error);
      alert("Failed to create group. Please try again.");
    }
  };

  const handleUpdateGroup = async () => {
    if (!editingGroup || !groupForm.name || !groupForm.group_key) return;
    
    try {
      const updatedGroup = await ChannelGroup.update(editingGroup.id, groupForm);
      setGroups(groups.map(g => g.id === editingGroup.id ? updatedGroup : g));
      setGroupForm({ name: "", group_key: "", description: "" });
      setEditingGroup(null);
      setIsGroupDialogOpen(false);
    } catch (error) {
      console.error("Error updating group:", error);
      alert("Failed to update group. Please try again.");
    }
  };

  const handleDeleteGroup = async (groupId) => {
    const groupChannels = channels.filter(c => c.group_id === groupId);
    if (groupChannels.length > 0) {
      alert("Cannot delete group with existing channels. Please delete all channels first.");
      return;
    }
    
    if (window.confirm("Are you sure you want to delete this group?")) {
      try {
        await ChannelGroup.delete(groupId);
        setGroups(groups.filter(g => g.id !== groupId));
      } catch (error) {
        console.error("Error deleting group:", error);
        alert("Failed to delete group.");
      }
    }
  };

  const handleCreateChannel = async () => {
    if (!channelForm.name || !channelForm.channel_key || !selectedGroupId || !organizationId) return;
    
    try {
      const newChannel = await ChannelIntegration.create({
        name: channelForm.name,
        channel_key: channelForm.channel_key,
        group_id: selectedGroupId,
        channel_type: "whatsapp_qr",
        status: "pending",
        organization_id: organizationId,
        config_data: {}
      });
      setChannels([...channels, newChannel]);
      setChannelForm({ name: "", channel_key: "" });
      setSelectedGroupId(null);
      setIsChannelDialogOpen(false);
    } catch (error) {
      console.error("Error creating channel:", error);
      alert("Failed to create channel. Please try again.");
    }
  };

  const handleDeleteChannel = async (channelId) => {
    if (window.confirm("Are you sure you want to delete this channel?")) {
      try {
        await ChannelIntegration.delete(channelId);
        setChannels(channels.filter(c => c.id !== channelId));
      } catch (error) {
        console.error("Error deleting channel:", error);
        alert("Failed to delete channel.");
      }
    }
  };

  const toggleGroupExpansion = (groupId) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(groupId)) {
      newExpanded.delete(groupId);
    } else {
      newExpanded.add(groupId);
    }
    setExpandedGroups(newExpanded);
  };

  const openGroupDialog = (group = null) => {
    if (group) {
      setEditingGroup(group);
      setGroupForm({
        name: group.name,
        group_key: group.group_key,
        description: group.description || ""
      });
    } else {
      setEditingGroup(null);
      setGroupForm({ name: "", group_key: "", description: "" });
    }
    setIsGroupDialogOpen(true);
  };

  const openChannelDialog = (groupId) => {
    setSelectedGroupId(groupId);
    setChannelForm({ name: "", channel_key: "" });
    setIsChannelDialogOpen(true);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'connected': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'waiting_qr': return 'bg-blue-100 text-blue-800';
      case 'error': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
        <div className="p-6 text-center text-gray-500">
            Loading channels...
        </div>
    );
  }

  if (!organizationId) {
    return (
        <div className="p-6 text-center text-red-500">
            You must belong to an organization to manage channels.
        </div>
    );
  }

  return (
    <div className="p-6">
      {/* Group Dialog */}
      <Dialog open={isGroupDialogOpen} onOpenChange={setIsGroupDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingGroup ? "Edit Group" : "Create Channel Group"}</DialogTitle>
            <DialogDescription>
              {editingGroup ? "Update group information" : "Create a new group to organize your channels"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="group-name">Group Name</Label>
              <Input
                id="group-name"
                value={groupForm.name}
                onChange={(e) => setGroupForm({...groupForm, name: e.target.value})}
                placeholder="e.g. Sales Team"
              />
            </div>
            <div>
              <Label htmlFor="group-key">Group Key</Label>
              <Input
                id="group-key"
                value={groupForm.group_key}
                onChange={(e) => setGroupForm({...groupForm, group_key: e.target.value})}
                placeholder="e.g. sales_team"
              />
            </div>
            <div>
              <Label htmlFor="group-description">Description (Optional)</Label>
              <Input
                id="group-description"
                value={groupForm.description}
                onChange={(e) => setGroupForm({...groupForm, description: e.target.value})}
                placeholder="Description of this channel group"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsGroupDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={editingGroup ? handleUpdateGroup : handleCreateGroup}>
              {editingGroup ? "Update Group" : "Create Group"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Channel Dialog */}
      <Dialog open={isChannelDialogOpen} onOpenChange={setIsChannelDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create WhatsApp Channel</DialogTitle>
            <DialogDescription>
              Add a new WhatsApp QR Code channel to the selected group
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="channel-name">Channel Name</Label>
              <Input
                id="channel-name"
                value={channelForm.name}
                onChange={(e) => setChannelForm({...channelForm, name: e.target.value})}
                placeholder="e.g. Support WhatsApp"
              />
            </div>
            <div>
              <Label htmlFor="channel-key">Channel Key</Label>
              <Input
                id="channel-key"
                value={channelForm.channel_key}
                onChange={(e) => setChannelForm({...channelForm, channel_key: e.target.value})}
                placeholder="e.g. support_wa"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsChannelDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateChannel}>
              Create Channel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <div className="mb-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Channel Management</h1>
            <p className="text-gray-500 mt-1">Organize and manage your WhatsApp communication channels</p>
          </div>
          <Button onClick={() => openGroupDialog()} className="bg-blue-600 hover:bg-blue-700">
            <FolderPlus className="w-4 h-4 mr-2" />
            Create Group
          </Button>
        </div>
      </div>

      {/* Channel Groups List */}
      <div className="space-y-4">
        {groups.map((group) => {
          const groupChannels = channels.filter(c => c.group_id === group.id);
          const isExpanded = expandedGroups.has(group.id);
          
          return (
            <Card key={group.id}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => toggleGroupExpansion(group.id)}
                      className="p-1 hover:bg-gray-100 rounded"
                    >
                      {isExpanded ? (
                        <ChevronDown className="w-4 h-4" />
                      ) : (
                        <ChevronRight className="w-4 h-4" />
                      )}
                    </button>
                    <div>
                      <h3 className="font-semibold flex items-center gap-2">
                        {group.name}
                        <Badge variant="outline" className="text-xs">
                          {group.group_key}
                        </Badge>
                      </h3>
                      {group.description && (
                        <p className="text-sm text-gray-500">{group.description}</p>
                      )}
                      <p className="text-xs text-gray-400">
                        {groupChannels.length} channel{groupChannels.length !== 1 ? 's' : ''}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      onClick={() => openChannelDialog(group.id)}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Channel
                    </Button>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openGroupDialog(group)}>
                          <Edit2 className="w-4 h-4 mr-2" />
                          Edit Group
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDeleteGroup(group.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete Group
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardHeader>
              
              {isExpanded && (
                <CardContent>
                  {groupChannels.length > 0 ? (
                    <div className="space-y-3">
                      {groupChannels.map((channel) => (
                        <div key={channel.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                              <QrCode className="w-4 h-4 text-green-600" />
                            </div>
                            <div>
                              <h4 className="font-medium text-sm">{channel.name}</h4>
                              <div className="flex items-center gap-2">
                                <Badge variant="outline" className="text-xs">
                                  {channel.channel_key}
                                </Badge>
                                <Badge className={`text-xs ${getStatusColor(channel.status)}`}>
                                  {channel.status.replace('_', ' ')}
                                </Badge>
                              </div>
                              {channel.phone_number && (
                                <p className="text-xs text-gray-500">{channel.phone_number}</p>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <Button size="sm" variant="outline">
                              Configure
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreVertical className="w-4 h-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem 
                                  onClick={() => handleDeleteChannel(channel.id)}
                                  className="text-red-600"
                                >
                                  <Trash2 className="w-4 h-4 mr-2" />
                                  Delete Channel
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <QrCode className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                      <p className="text-sm">No channels in this group</p>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => openChannelDialog(group.id)}
                        className="mt-2"
                      >
                        Add First Channel
                      </Button>
                    </div>
                  )}
                </CardContent>
              )}
            </Card>
          );
        })}
        
        {groups.length === 0 && (
          <Card>
            <CardContent className="text-center py-12">
              <FolderPlus className="w-12 h-12 mx-auto mb-4 text-gray-400" />
              <h3 className="font-medium text-gray-900 mb-2">No Channel Groups</h3>
              <p className="text-gray-500 mb-4">Create your first group to organize channels</p>
              <Button onClick={() => openGroupDialog()}>
                <FolderPlus className="w-4 h-4 mr-2" />
                Create First Group
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}