import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { ChannelGroup } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { 
  Code, 
  Copy, 
  Eye, 
  ExternalLink,
  Key,
  AlertCircle,
  CheckCircle2
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function SDKManagement({ currentUser }) {
  const [organizationId, setOrganizationId] = useState(null);
  const [apiKey, setApiKey] = useState('');
  const [channelGroups, setChannelGroups] = useState([]);
  const [selectedGroupId, setSelectedGroupId] = useState('');
  const [copiedStates, setCopiedStates] = useState({});

  useEffect(() => {
    const init = async () => {
      try {
        const user = await User.me();
        if (user.organization_id) {
          setOrganizationId(user.organization_id);
          // Generate a demo API key (in production, this would be generated server-side)
          const demoKey = `hootspy_${user.organization_id.substring(0, 8)}_${Math.random().toString(36).substring(2, 10)}`;
          setApiKey(demoKey);
          
          // Load channel groups
          const groups = await ChannelGroup.filter({ organization_id: user.organization_id });
          setChannelGroups(groups);
          
          // Auto-select first group if available
          if (groups.length > 0) {
            setSelectedGroupId(groups[0].id);
          }
        }
      } catch (error) {
        console.error("Error initializing SDK Management:", error);
      }
    };
    init();
  }, []);

  const copyToClipboard = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopiedStates({ ...copiedStates, [key]: true });
    setTimeout(() => {
      setCopiedStates({ ...copiedStates, [key]: false });
    }, 2000);
  };

  const selectedGroup = channelGroups.find(g => g.id === selectedGroupId);
  
  // Generate the widget URL
  const widgetUrl = selectedGroupId 
    ? `${window.location.origin}/InboxWidget?organizationId=${organizationId}&groupId=${selectedGroupId}&apiKey=${apiKey}`
    : '';

  // Vanilla JavaScript Embed Code
  const vanillaJsCode = selectedGroupId ? `<!-- Hootspy Inbox Widget -->
<div id="hootspy-inbox-container" style="width: 100%; height: 600px;"></div>

<script>
(function() {
  // Configuration
  const config = {
    organizationId: "${organizationId}",
    groupId: "${selectedGroupId}",
    apiKey: "${apiKey}",
    containerId: "hootspy-inbox-container"
  };

  // Find the container
  const container = document.getElementById(config.containerId);
  if (!container) {
    console.error("Hootspy SDK Error: Container element with id '" + config.containerId + "' not found.");
    return;
  }

  // Create and configure the iframe
  const iframe = document.createElement('iframe');
  const iframeSrc = new URL('${window.location.origin}/InboxWidget');
  iframeSrc.searchParams.append('organizationId', config.organizationId);
  iframeSrc.searchParams.append('groupId', config.groupId);
  iframeSrc.searchParams.append('apiKey', config.apiKey);
  
  iframe.src = iframeSrc.toString();
  iframe.style.width = '100%';
  iframe.style.height = '100%';
  iframe.style.border = 'none';
  iframe.style.borderRadius = 'inherit';
  iframe.setAttribute('allow', 'clipboard-write');

  // Clear the container and add the iframe
  container.innerHTML = '';
  container.appendChild(iframe);
})();
</script>` : 'Please select a Channel Group first';

  // React Component Code
  const reactComponentCode = selectedGroupId ? `import React, { useEffect, useRef } from 'react';

const HootspyInboxWidget = ({ 
  organizationId = "${organizationId}",
  groupId = "${selectedGroupId}",
  apiKey = "${apiKey}",
  height = "600px"
}) => {
  const containerRef = useRef(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Create and configure the iframe
    const iframe = document.createElement('iframe');
    const iframeSrc = new URL('${window.location.origin}/InboxWidget');
    iframeSrc.searchParams.append('organizationId', organizationId);
    iframeSrc.searchParams.append('groupId', groupId);
    iframeSrc.searchParams.append('apiKey', apiKey);
    
    iframe.src = iframeSrc.toString();
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';
    iframe.style.borderRadius = 'inherit';
    iframe.setAttribute('allow', 'clipboard-write');

    // Clear the container and add the iframe
    containerRef.current.innerHTML = '';
    containerRef.current.appendChild(iframe);

    // Cleanup
    return () => {
      if (containerRef.current) {
        containerRef.current.innerHTML = '';
      }
    };
  }, [organizationId, groupId, apiKey]);

  return (
    <div 
      ref={containerRef}
      style={{ 
        width: '100%', 
        height, 
        border: '1px solid #e5e7eb', 
        borderRadius: '8px' 
      }}
    />
  );
};

export default HootspyInboxWidget;

// Usage example:
// <HootspyInboxWidget />` : 'Please select a Channel Group first';

  if (!organizationId) {
    return (
      <div className="p-6 text-center text-gray-500">
        Loading SDK configuration...
      </div>
    );
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">SDK & Integration</h1>
        <p className="text-gray-600">
          Embed the Hootspy Inbox into your application. Select a Channel Group to generate the integration code.
        </p>
      </div>

      {/* Configuration Section */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="w-5 h-5 text-blue-600" />
            Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="organizationId">Organization ID</Label>
            <Input
              id="organizationId"
              value={organizationId}
              readOnly
              className="font-mono text-sm bg-gray-50"
            />
            <p className="text-xs text-gray-500 mt-1">Your unique organization identifier</p>
          </div>

          <div>
            <Label htmlFor="channelGroup">Channel Group</Label>
            <Select value={selectedGroupId} onValueChange={setSelectedGroupId}>
              <SelectTrigger id="channelGroup">
                <SelectValue placeholder="Select a channel group" />
              </SelectTrigger>
              <SelectContent>
                {channelGroups.map((group) => (
                  <SelectItem key={group.id} value={group.id}>
                    <div className="flex items-center gap-2">
                      <span>{group.name}</span>
                      {group.is_default && (
                        <Badge variant="outline" className="text-xs">Default</Badge>
                      )}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-gray-500 mt-1">
              {selectedGroup 
                ? `Group Key: ${selectedGroup.group_key}${selectedGroup.description ? ` - ${selectedGroup.description}` : ''}`
                : 'Select which channel group this widget will display'}
            </p>
          </div>

          <div>
            <Label htmlFor="apiKey">API Key</Label>
            <Input
              id="apiKey"
              value={apiKey}
              readOnly
              className="font-mono text-sm bg-gray-50"
            />
            <p className="text-xs text-gray-500 mt-1">Keep this key secure and never expose it publicly</p>
          </div>

          {selectedGroupId && (
            <div>
              <Label htmlFor="widgetUrl">Direct Widget URL</Label>
              <div className="flex gap-2">
                <Input
                  id="widgetUrl"
                  value={widgetUrl}
                  readOnly
                  className="font-mono text-xs bg-gray-50"
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => copyToClipboard(widgetUrl, 'widgetUrl')}
                >
                  {copiedStates['widgetUrl'] ? (
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => window.open(widgetUrl, '_blank')}
                >
                  <ExternalLink className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Direct URL to the inbox widget for this channel group. Use this in an iframe or share with your team.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Integration Code Section */}
      {!selectedGroupId && (
        <Card className="mb-6 border-yellow-200 bg-yellow-50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
              <div>
                <h3 className="font-medium text-yellow-900 mb-1">Select a Channel Group</h3>
                <p className="text-sm text-yellow-700">
                  Please select a Channel Group above to generate the integration code for your application.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {selectedGroupId && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Code className="w-5 h-5 text-purple-600" />
              Integration Code
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="vanilla">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="vanilla">HTML / Vanilla JS</TabsTrigger>
                <TabsTrigger value="react">React Component</TabsTrigger>
              </TabsList>

              <TabsContent value="vanilla" className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <Label>HTML & JavaScript Embed Code</Label>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(vanillaJsCode, 'vanilla')}
                    >
                      {copiedStates['vanilla'] ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 mr-2 text-green-600" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copy Code
                        </>
                      )}
                    </Button>
                  </div>
                  <Textarea
                    value={vanillaJsCode}
                    readOnly
                    className="font-mono text-xs h-96 bg-gray-50"
                  />
                  <p className="text-xs text-gray-500 mt-2">
                    Paste this code snippet into your HTML file where you want the inbox to appear.
                  </p>
                </div>
              </TabsContent>

              <TabsContent value="react" className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <Label>React Component</Label>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(reactComponentCode, 'react')}
                    >
                      {copiedStates['react'] ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 mr-2 text-green-600" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copy Code
                        </>
                      )}
                    </Button>
                  </div>
                  <Textarea
                    value={reactComponentCode}
                    readOnly
                    className="font-mono text-xs h-96 bg-gray-50"
                  />
                  <p className="text-xs text-gray-500 mt-2">
                    Create a new file (e.g., HootspyInboxWidget.jsx) and paste this code. Then import and use the component in your React app.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}

      {/* Usage Instructions */}
      {selectedGroupId && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5 text-green-600" />
              Quick Start Guide
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-medium mb-2">Option 1: Direct iframe</h3>
              <p className="text-sm text-gray-600 mb-2">
                Use the direct widget URL in an iframe:
              </p>
              <Textarea
                value={`<iframe 
  src="${widgetUrl}"
  style="width: 100%; height: 600px; border: none; border-radius: 8px;"
  allow="clipboard-write"
></iframe>`}
                readOnly
                className="font-mono text-xs h-24 bg-gray-50"
              />
            </div>

            <div>
              <h3 className="font-medium mb-2">Option 2: Vanilla JavaScript</h3>
              <ol className="text-sm text-gray-600 space-y-2 list-decimal list-inside">
                <li>Copy the HTML & JavaScript code from the "HTML / Vanilla JS" tab above</li>
                <li>Paste it into your HTML file where you want the inbox to appear</li>
                <li>The widget will automatically load and display the inbox for the selected channel group</li>
              </ol>
            </div>

            <div>
              <h3 className="font-medium mb-2">Option 3: React Component</h3>
              <ol className="text-sm text-gray-600 space-y-2 list-decimal list-inside">
                <li>Copy the React component code from the "React Component" tab</li>
                <li>Create a new file in your React project (e.g., <code className="bg-gray-100 px-1 rounded">HootspyInboxWidget.jsx</code>)</li>
                <li>Import and use it: <code className="bg-gray-100 px-1 rounded">&lt;HootspyInboxWidget /&gt;</code></li>
              </ol>
            </div>

            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h3 className="font-medium text-blue-900 mb-2">Dynamic Group Selection</h3>
              <p className="text-sm text-blue-700">
                You can dynamically change the <code className="bg-blue-100 px-1 rounded">groupId</code> parameter based on your application's context. 
                For example, different pages or user roles can load different channel groups by passing different <code className="bg-blue-100 px-1 rounded">groupId</code> values.
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}