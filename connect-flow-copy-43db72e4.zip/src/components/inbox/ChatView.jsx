
import React, { useState, useRef, useEffect } from "react";
import { 
  Send, 
  Paperclip, 
  MoreVertical, 
  Info, 
  User, 
  Users, 
  UserPlus, 
  ArrowRightLeft,
  Mic,
  Smile,
  StickyNote,
  Zap,
  MessageSquarePlus,
  FileText,
  File,
  Music,
  Video,
  Image,
  Clock, 
  Play,
  CheckCircle2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

const assignableUsers = [
  { id: 1, name: "Alice" },
  { id: 2, name: "Bob" },
  { id: 3, name: "Charlie" },
  { id: 4, name: "Manager" },
];

const assignableTeams = [
  { id: 1, name: "Sales" },
  { id: 2, name: "Support Tier 1" },
  { id: 3, name: "Billing" },
];

// Mock data for current conversation members
const conversationMembers = [
  { id: 1, name: "Alice", initials: "A", color: "bg-blue-100 text-blue-800" },
  { id: 4, name: "Manager", initials: "M", color: "bg-purple-100 text-purple-800" },
];

// Mock active templates for WhatsApp Business API
const activeTemplates = [
  { id: 1, name: "Welcome Message", content: "Hello {{name}}, welcome to our service!" },
  { id: 2, name: "Appointment Reminder", content: "Hi {{name}}, this is a reminder for your appointment on {{date}}" },
  { id: 3, name: "Follow Up", content: "Thank you for your interest, {{name}}. Let us know if you need any help!" },
  { id: 4, name: "Special Offer", content: "Hi {{name}}, we have a special offer just for you!" }
];

export default function ChatView({ 
  conversation, 
  contact, 
  messages, 
  isLoadingMessages, // Add loading prop
  onSendMessage, 
  onSendInternalNote,
  onToggleContactInfo,
  onStartConversation,
  onFinishConversation
}) {
  const [newMessage, setNewMessage] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [showScheduler, setShowScheduler] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [scheduledDate, setScheduledDate] = useState("");
  const [scheduledTime, setScheduledTime] = useState("");
  const [isNoteMode, setIsNoteMode] = useState(false); // State for internal note mode
  const [previousMessageCount, setPreviousMessageCount] = useState(0);
  const [hasInitiallyScrolled, setHasInitiallyScrolled] = useState(false);
  const messagesEndRef = useRef(null);

  // Smart scroll logic - only scroll when needed
  useEffect(() => {
    if (!messagesEndRef.current) return;

    const shouldScroll = 
      // Initial load of conversation (when messages first appear and we haven't scrolled yet)
      (!hasInitiallyScrolled && messages.length > 0) ||
      // New message added (message count increased)
      (messages.length > previousMessageCount && previousMessageCount > 0);

    if (shouldScroll) {
      messagesEndRef.current.scrollIntoView({ behavior: hasInitiallyScrolled ? "smooth" : "instant" });
      
      if (!hasInitiallyScrolled) {
        setHasInitiallyScrolled(true);
      }
    }

    setPreviousMessageCount(messages.length);
  }, [messages.length, hasInitiallyScrolled, previousMessageCount]);

  // Reset scroll state when conversation changes
  useEffect(() => {
    setHasInitiallyScrolled(false);
    setPreviousMessageCount(0);
  }, [conversation?.id]);

  const handleSend = (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    
    if (isNoteMode) {
      onSendInternalNote(newMessage);
      setIsNoteMode(false); // Exit note mode after sending
    } else {
      onSendMessage(newMessage);
    }
    setNewMessage("");
    // Note: scroll will happen automatically when the new message is added to the messages array
  };

  const getMessageStatusColor = (status) => {
    switch (status) {
      case "read": return "text-blue-500";
      case "delivered": return "text-green-500";
      case "sent": return "text-gray-400";
      case "failed": return "text-red-500";
      default: return "text-gray-400";
    }
  };

  const handleAction = (action, target) => {
    // Placeholder function to simulate actions
    alert(`${action}: ${target}`);
  };

  const handleAudioRecord = () => {
    if (isRecording) {
      // Stop recording logic
      setIsRecording(false);
      // Here you would typically stop the recording and send the audio
      alert("Audio recording stopped - would send audio message here");
    } else {
      // Start recording logic  
      setIsRecording(true);
      alert("Audio recording started");
    }
  };

  const handleEmojiSelect = (emoji) => {
    setNewMessage(prev => prev + emoji);
  };

  // New function for scheduling messages
  const handleScheduleMessage = () => {
    if (!selectedTemplate || !scheduledDate || !scheduledTime) {
      alert("Please select a template and set date/time");
      return;
    }
    
    const template = activeTemplates.find(t => t.id === parseInt(selectedTemplate));
    const formattedContent = template.content
      .replace('{{name}}', contact?.name || 'Customer')
      .replace('{{date}}', scheduledDate || '[Date]');

    alert(`Scheduled message: "${formattedContent}" \nfor ${scheduledDate} at ${scheduledTime}`);
    
    // Reset form
    setSelectedTemplate("");
    setScheduledDate("");
    setScheduledTime("");
    setShowScheduler(false);
  };

  const handleFinishConversation = () => {
    if (conversation && onFinishConversation) {
      onFinishConversation(conversation);
    }
  };

  const sampleEmojis = ['😀', '😂', '😍', '👍', '❤️', '🙏', '🎉', '🔥', '🤔', '👋', '😊', '😢'];

  return (
    <>
      {/* Chat Header */}
      <div className="p-4 border-b border-gray-200 bg-white">
        <div className="flex items-center justify-between">
          <div 
            className="flex items-center gap-3 cursor-pointer group"
            onClick={onToggleContactInfo}
          >
            <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center">
              <span className="text-white font-semibold text-sm">
                {contact?.name?.[0]?.toUpperCase() || "?"}
              </span>
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">{contact?.name || "Unknown"}</h3>
              <p className="text-sm text-gray-500">{contact?.phone}</p>
              
              {/* Contact Tags in Header */}
              {contact?.tags && contact.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-1">
                  {contact.tags.map((tag, index) => (
                    <Badge 
                      key={index} 
                      variant="secondary" 
                      className="text-xs px-2 py-0 h-5 bg-blue-100 text-blue-700"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Members view */}
            <div className="hidden sm:flex items-center">
                <div className="flex items-center -space-x-2 pr-2">
                    {conversationMembers.map(member => (
                        <div 
                            key={member.id}
                            title={member.name} 
                            className={`w-8 h-8 rounded-full border-2 border-white flex items-center justify-center text-xs font-bold ${member.color} cursor-help transition-transform hover:scale-110`}
                        >
                            {member.initials}
                        </div>
                    ))}
                </div>
            </div>

            {/* Action Buttons - Swapped order */}
            <div className="flex items-center gap-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <UserPlus className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Add to conversation...</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuSub>
                    <DropdownMenuSubTrigger>
                      <Users className="w-4 h-4 mr-2" />
                      <span>Team</span>
                    </DropdownMenuSubTrigger>
                    <DropdownMenuSubContent>
                      {assignableTeams.map(team => (
                        <DropdownMenuItem key={team.id} onClick={() => handleAction('Add Team', team.name)}>
                          {team.name}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuSubContent>
                  </DropdownMenuSub>
                  <DropdownMenuSub>
                    <DropdownMenuSubTrigger>
                      <User className="w-4 h-4 mr-2" />
                      <span>User</span>
                    </DropdownMenuSubTrigger>
                    <DropdownMenuSubContent>
                      {assignableUsers.map(user => (
                        <DropdownMenuItem key={user.id} onClick={() => handleAction('Add User', user.name)}>
                          {user.name}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuSubContent>
                  </DropdownMenuSub>
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <ArrowRightLeft className="w-3 h-3 mr-2" />
                    Transfer
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Transfer conversation to...</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuSub>
                    <DropdownMenuSubTrigger>
                      <Users className="w-4 h-4 mr-2" />
                      <span>Team</span>
                    </DropdownMenuSubTrigger>
                    <DropdownMenuSubContent>
                      {assignableTeams.map(team => (
                        <DropdownMenuItem key={team.id} onClick={() => handleAction('Transfer to Team', team.name)}>
                          {team.name}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuSubContent>
                  </DropdownMenuSub>
                  <DropdownMenuSub>
                    <DropdownMenuSubTrigger>
                      <User className="w-4 h-4 mr-2" />
                      <span>User</span>
                    </DropdownMenuSubTrigger>
                    <DropdownMenuSubContent>
                      {assignableUsers.map(user => (
                        <DropdownMenuItem key={user.id} onClick={() => handleAction('Transfer to User', user.name)}>
                          {user.name}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuSubContent>
                  </DropdownMenuSub>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Button variant="ghost" size="icon" onClick={onToggleContactInfo}>
                <Info className="w-4 h-4" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem 
                    onClick={handleFinishConversation}
                    className="text-green-600"
                  >
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Finish Conversation
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
        {isLoadingMessages ? (
          // Loading state for messages
          <div className="flex items-center justify-center h-full">
            <div className="flex items-center gap-3 text-gray-500">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
              <span className="text-sm">Loading messages...</span>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message) => {
              if (message.is_internal) {
                return (
                  <div key={message.id} className="flex justify-center my-2 group">
                    <div className="max-w-lg w-full bg-orange-100 text-orange-900 p-3 rounded-lg text-sm flex items-start gap-3 border border-orange-200">
                      <StickyNote className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <p className="whitespace-pre-wrap">{message.content}</p>
                        <div className="text-xs text-orange-600 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          Internal note added at {format(new Date(message.timestamp), "h:mm a")}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              }
              return (
                <div
                  key={message.id}
                  className={`flex ${message.direction === "outbound" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl shadow-sm ${
                      message.direction === "outbound"
                        ? "bg-blue-600 text-white"
                        : "bg-white text-gray-900 border"
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <div className={`flex items-center justify-end gap-1 mt-1 text-xs ${
                      message.direction === "outbound" ? "text-blue-100/80" : "text-gray-500"
                    }`}>
                      <span>
                        {format(new Date(message.timestamp), "h:mm a")}
                      </span>
                      {message.direction === "outbound" && (
                        <span className={getMessageStatusColor(message.status) + ' text-base'}>
                          ✓✓
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Message Input */}
      <div className={`p-4 border-t border-gray-200 transition-colors ${isNoteMode ? 'bg-orange-50 border-t-orange-200' : 'bg-white'}`}>
        {conversation && (conversation.status === 'concluded' || !conversation.assigned_to) ? (
            <div className="flex justify-center">
              <Button onClick={() => onStartConversation(conversation)} size="lg" className="bg-blue-600 hover:bg-blue-700">
                <Play className="mr-2 h-4 w-4" /> 
                {conversation.status === 'concluded' ? 'Re-open Conversation' : 'Start Conversation'}
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSend} className="flex items-center gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button type="button" variant="ghost" size="icon">
                    <Smile className="w-5 h-5" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-2 border-none shadow-xl rounded-2xl">
                  <div className="grid grid-cols-6 gap-1">
                    {sampleEmojis.map((emoji) => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => handleEmojiSelect(emoji)}
                        className="text-2xl p-1 rounded-lg hover:bg-gray-100 transition-colors"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>

              {/* Dropdown for attachments and actions */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button type="button" variant="ghost" size="icon">
                    <Paperclip className="w-5 h-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start">
                  <DropdownMenuItem onSelect={() => setIsNoteMode(true)}>
                    <StickyNote className="w-4 h-4 mr-2" />
                    <span>Internal Notes</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => alert('Trigger Automation action triggered')}>
                    <Zap className="w-4 h-4 mr-2" />
                    <span>Trigger Automation</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => alert('Quick Messages action triggered')}>
                    <MessageSquarePlus className="w-4 h-4 mr-2" />
                    <span>Quick Messages</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => alert('Templates action triggered')}>
                    <FileText className="w-4 h-4 mr-2" />
                    <span>Templates</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onSelect={() => alert('Document upload action triggered')}>
                    <File className="w-4 h-4 mr-2" />
                    <span>Document</span>
                  </DropdownMenuItem>
                   <DropdownMenuItem onSelect={() => alert('Audio upload action triggered')}>
                    <Music className="w-4 h-4 mr-2" />
                    <span>Audio</span>
                  </DropdownMenuItem>
                   <DropdownMenuItem onSelect={() => alert('Video upload action triggered')}>
                    <Video className="w-4 h-4 mr-2" />
                    <span>Video</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => alert('Image upload action triggered')}>
                    <Image className="w-4 h-4 mr-2" />
                    <span>Image</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder={isNoteMode ? "Type an internal note... (visible only to your team)" : "Type a message..."}
                className={`flex-1 rounded-full px-4 focus:border-blue-500 ${isNoteMode ? 'bg-orange-100 border-orange-300 placeholder:text-orange-700/80' : 'bg-gray-100 border-transparent'}`}
                onFocus={() => isNoteMode && setIsNoteMode(true)}
              />
              
              {isNoteMode && (
                <Button type="button" variant="ghost" size="sm" onClick={() => setIsNoteMode(false)}>
                  Cancel
                </Button>
              )}
              
              {/* Popover for Message Scheduler */}
              <Popover open={showScheduler} onOpenChange={setShowScheduler}>
                <PopoverTrigger asChild>
                  <Button type="button" variant="ghost" size="icon" className="rounded-full">
                    <Clock className="w-5 h-5" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80 p-4" align="end">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-gray-600" />
                      <h4 className="font-medium text-gray-800">Schedule Template Message</h4>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <Label htmlFor="template" className="text-xs text-gray-700">Select Template</Label>
                        <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Choose an active template..." />
                          </SelectTrigger>
                          <SelectContent>
                            {activeTemplates.map((template) => (
                              <SelectItem key={template.id} value={template.id.toString()}>
                                <div>
                                  <div className="font-medium text-sm">{template.name}</div>
                                  <div className="text-xs text-gray-500 truncate max-w-48">
                                    {template.content}
                                  </div>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label htmlFor="date" className="text-xs text-gray-700">Date</Label>
                          <Input
                            id="date"
                            type="date"
                            value={scheduledDate}
                            onChange={(e) => setScheduledDate(e.target.value)}
                            min={format(new Date(), 'yyyy-MM-dd')}
                            className="p-2 border rounded-md text-sm"
                          />
                        </div>
                        <div>
                          <Label htmlFor="time" className="text-xs text-gray-700">Time</Label>
                          <Input
                            id="time"
                            type="time"
                            value={scheduledTime}
                            onChange={(e) => setScheduledTime(e.target.value)}
                            className="p-2 border rounded-md text-sm"
                          />
                        </div>
                      </div>

                      {selectedTemplate && (
                        <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                          <Label className="text-xs text-blue-700">Preview:</Label>
                          <p className="text-sm mt-1 text-blue-900">
                            {activeTemplates.find(t => t.id === parseInt(selectedTemplate))?.content
                              .replace('{{name}}', contact?.name || 'Customer')
                              .replace('{{date}}', scheduledDate || '[Date]')}
                          </p>
                        </div>
                      )}

                      <div className="flex gap-2 pt-2">
                        <Button 
                          type="button" 
                          variant="outline" 
                          size="sm" 
                          onClick={() => setShowScheduler(false)}
                          className="flex-1"
                        >
                          Cancel
                        </Button>
                        <Button 
                          type="button" 
                          size="sm" 
                          onClick={handleScheduleMessage}
                          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                          disabled={!selectedTemplate || !scheduledDate || !scheduledTime}
                        >
                          Schedule
                        </Button>
                      </div>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
              
              {newMessage.trim() === "" && !isNoteMode ? (
                <Button 
                  type="button" 
                  variant={isRecording ? "destructive" : "ghost"} 
                  size="icon"
                  onClick={handleAudioRecord}
                  className="rounded-full w-10 h-10 p-0"
                >
                  <Mic className={`w-5 h-5 ${isRecording ? 'animate-pulse' : ''}`} />
                </Button>
              ) : (
                <Button type="submit" className={`rounded-full w-10 h-10 p-0 ${isNoteMode ? 'bg-orange-500 hover:bg-orange-600' : 'bg-blue-600 hover:bg-blue-700'}`}>
                  <Send className="w-5 h-5" />
                </Button>
              )}
            </form>
          )}
      </div>
    </>
  );
}
