
import React, { useState, useEffect } from "react";
import { X, Mail, Building, Phone, Tag, Edit, User, Clock, FileText, MessageCircle, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import EditContactForm from "./EditContactForm";
import { CustomField, User as AppUser } from "@/api/entities"; // Renamed User to AppUser to avoid conflict with Icon

export default function ContactInfo({ contact, conversation, onClose, onContactUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [currentContact, setCurrentContact] = useState(contact);
  const [activeTab, setActiveTab] = useState("details");

  if (!currentContact) return null;

  const handleSave = (updatedContact) => {
    setCurrentContact(updatedContact);
    setIsEditing(false);
    if (onContactUpdate) {
      onContactUpdate(updatedContact);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
  };

  const tabs = [
    { id: "details", icon: User, label: "Details" },
    { id: "scheduled", icon: Clock, label: "Scheduled" },
    { id: "files", icon: FileText, label: "Files" },
    { id: "conversations", icon: MessageCircle, label: "History" }
  ];

  if (isEditing) {
    return (
      <div className="h-full bg-white flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">Edit Contact</h3>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto">
          <EditContactForm
            contact={currentContact}
            onSave={handleSave}
            onCancel={handleCancel}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-white flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">Contact Profile</h3>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Contact Avatar and Name */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mb-3">
            <span className="text-white font-bold text-xl">
              {currentContact.name?.[0]?.toUpperCase() || "?"}
            </span>
          </div>
          <h2 className="text-lg font-semibold text-gray-900">{currentContact.name}</h2>
          <p className="text-sm text-gray-500">{currentContact.phone}</p>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-gray-200">
        <div className="flex">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex flex-col items-center gap-1 py-3 px-2 text-xs font-medium transition-colors ${
                  activeTab === tab.id
                    ? "text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto">
        {activeTab === "details" && (
          <DetailsTab contact={currentContact} conversation={conversation} onEdit={() => setIsEditing(true)} />
        )}
        {activeTab === "scheduled" && (
          <ScheduledMessagesTab contact={currentContact} />
        )}
        {activeTab === "files" && (
          <FilesTab contact={currentContact} />
        )}
        {activeTab === "conversations" && (
          <ConversationHistoryTab contact={currentContact} />
        )}
      </div>
    </div>
  );
}

// Details Tab Component
function DetailsTab({ contact, conversation, onEdit }) {
  const [customFieldDefs, setCustomFieldDefs] = useState([]);

  useEffect(() => {
    const fetchCustomFields = async () => {
      try {
        const user = await AppUser.me();
        if (user.organization_id) {
          const fields = await CustomField.filter({ organization_id: user.organization_id }, "sort_order");
          setCustomFieldDefs(fields);
        }
      } catch (error) {
        console.error("Failed to fetch custom fields", error);
      }
    };
    fetchCustomFields();
  }, [contact?.organization_id]);

  const formatCustomFieldValue = (field, value) => {
    if (value === null || value === undefined || value === '') return <span className="text-gray-400">Not set</span>;

    switch (field.field_type) {
        case 'boolean':
            return <Badge variant={value ? 'default' : 'outline'}>{value ? 'Yes' : 'No'}</Badge>;
        case 'currency':
            return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
        case 'date':
        case 'datetime':
            try {
                return new Date(value).toLocaleDateString();
            } catch {
                return value;
            }
        default:
            return value.toString();
    }
  };

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h4 className="font-medium text-gray-800">Contact Details</h4>
        <Button variant="outline" size="sm" className="text-xs" onClick={onEdit}>
          <Edit className="w-3 h-3 mr-2" />
          Edit
        </Button>
      </div>

      <div className="space-y-4">
        <div className="flex items-start gap-3">
          <User className="w-4 h-4 text-gray-400 mt-1 flex-shrink-0" />
          <div>
            <p className="text-xs text-gray-500">Name</p>
            <p className="font-medium text-sm">{contact.name}</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Phone className="w-4 h-4 text-gray-400 mt-1 flex-shrink-0" />
          <div>
            <p className="text-xs text-gray-500">Phone</p>
            <p className="font-medium text-sm">{contact.phone}</p>
          </div>
        </div>
        {contact.email && (
          <div className="flex items-start gap-3">
            <Mail className="w-4 h-4 text-gray-400 mt-1 flex-shrink-0" />
            <div>
              <p className="text-xs text-gray-500">Email</p>
              <p className="font-medium text-sm">{contact.email}</p>
            </div>
          </div>
        )}
        {contact.company && (
          <div className="flex items-start gap-3">
            <Building className="w-4 h-4 text-gray-400 mt-1 flex-shrink-0" />
            <div>
              <p className="text-xs text-gray-500">Company</p>
              <p className="font-medium text-sm">{contact.company}</p>
            </div>
          </div>
        )}
      </div>

      {/* Custom Fields */}
      {customFieldDefs.length > 0 && contact.custom_fields && (
        <>
          <Separator className="my-4" />
          <h4 className="font-medium text-gray-800 mb-3">Custom Details</h4>
          <div className="space-y-4">
            {customFieldDefs.map(field => {
              const value = contact.custom_fields[field.integration_key];
              return (
                <div key={field.id} className="flex items-start gap-3">
                  <Info className="w-4 h-4 text-gray-400 mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-gray-500">{field.name}</p>
                    <p className="font-medium text-sm">{formatCustomFieldValue(field, value)}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      <Separator className="my-4" />

      {/* Tags */}
      {contact.tags && contact.tags.length > 0 && (
        <div className="mb-4">
          <h4 className="font-medium text-gray-800 mb-3">Tags</h4>
          <div className="flex flex-wrap gap-2">
            {contact.tags.map((tag, index) => (
              <Badge key={index} variant="secondary">
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Notes */}
      {contact.notes && (
        <div className="mb-4">
          <h4 className="font-medium text-gray-800 mb-3">Notes</h4>
          <div className="p-3 bg-gray-50 rounded-lg border">
            <p className="text-sm text-gray-700 whitespace-pre-wrap">{contact.notes}</p>
          </div>
        </div>
      )}

      <Separator className="my-4" />

      {/* Conversation Status - Only show if conversation exists */}
      {conversation && (
        <div>
          <h4 className="font-medium text-gray-800 mb-3">Conversation Details</h4>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Status</span>
              <Badge variant="outline">{conversation.status}</Badge>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Priority</span>
              <Badge variant="outline">{conversation.priority}</Badge>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Scheduled Messages Tab Component
function ScheduledMessagesTab({ contact }) {
  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-medium text-gray-800">Scheduled Messages</h4>
        <Badge variant="outline" className="text-xs">2 Pending</Badge>
      </div>
      
      {/* Mock scheduled messages */}
      <div className="space-y-3">
        <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-center justify-between mb-2">
            <Badge className="text-xs bg-blue-100 text-blue-700">Welcome Message</Badge>
            <span className="text-xs text-blue-600">Jan 15, 2024 - 10:00 AM</span>
          </div>
          <p className="text-sm text-gray-700">Hello {contact.name}, welcome to our service! We're excited to help you...</p>
        </div>
        
        <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
          <div className="flex items-center justify-between mb-2">
            <Badge className="text-xs bg-amber-100 text-amber-700">Follow Up</Badge>
            <span className="text-xs text-amber-600">Jan 20, 2024 - 2:00 PM</span>
          </div>
          <p className="text-sm text-gray-700">Thank you for your interest, {contact.name}. Let us know if you need any help!</p>
        </div>
      </div>
      
      <div className="text-center py-6 text-sm text-gray-500">
        Future scheduled messages will appear here
      </div>
    </div>
  );
}

// Files Tab Component
function FilesTab({ contact }) {
  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-medium text-gray-800">Shared Files</h4>
        <Badge variant="outline" className="text-xs">5 Files</Badge>
      </div>
      
      {/* Mock files */}
      <div className="space-y-3">
        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
            <FileText className="w-5 h-5 text-blue-600" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-gray-900">Product_Catalog.pdf</p>
            <p className="text-xs text-gray-500">Sent by {contact.name} • Jan 10, 2024</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
            <FileText className="w-5 h-5 text-green-600" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-gray-900">Contract_Signed.pdf</p>
            <p className="text-xs text-gray-500">Sent by You • Jan 8, 2024</p>
          </div>
        </div>
      </div>
      
      <div className="text-center py-6 text-sm text-gray-500">
        Files shared in conversations will appear here
      </div>
    </div>
  );
}

// Conversation History Tab Component
function ConversationHistoryTab({ contact }) {
  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-medium text-gray-800">Conversation History</h4>
        <Badge variant="outline" className="text-xs">3 Past</Badge>
      </div>
      
      {/* Mock conversation history */}
      <div className="space-y-3">
        <div className="p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
          <div className="flex items-center justify-between mb-2">
            <Badge variant="secondary" className="text-xs">Closed</Badge>
            <span className="text-xs text-gray-500">Dec 15, 2024 - Dec 18, 2024</span>
          </div>
          <p className="text-sm text-gray-700">Product inquiry and purchase discussion</p>
          <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
            <span>Duration: 3 days</span>
            <span>•</span>
            <span>25 messages</span>
          </div>
        </div>
        
        <div className="p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
          <div className="flex items-center justify-between mb-2">
            <Badge variant="secondary" className="text-xs">Closed</Badge>
            <span className="text-xs text-gray-500">Nov 28, 2024 - Nov 30, 2024</span>
          </div>
          <p className="text-sm text-gray-700">Initial contact and service information</p>
          <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
            <span>Duration: 2 days</span>
            <span>•</span>
            <span>12 messages</span>
          </div>
        </div>
      </div>
      
      <div className="text-center py-6 text-sm text-gray-500">
        Past conversations will appear here when available
      </div>
    </div>
  );
}
