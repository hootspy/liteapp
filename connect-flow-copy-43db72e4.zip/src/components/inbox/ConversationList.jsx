
import React, { useState } from "react";
import { Search, Filter, X, ArrowUpDown, Inbox, Archive } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { formatRelative, format } from 'date-fns';

export default function ConversationList({
  conversations,
  contacts,
  selectedConversation,
  onConversationSelect,
  isLoading,
  currentUser // Added currentUser prop
}) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("novos"); // Default to 'novos'
  const [activeFilters, setActiveFilters] = useState({
    channels: [],
    tags: [],
    users: [],
    teams: []
  });
  const [sortOrder, setSortOrder] = useState("newest"); // "newest" or "oldest"
  const [showUnreadOnly, setShowUnreadOnly] = useState(false);
  const [showArchivedOnly, setShowArchivedOnly] = useState(false);

  // Sample filter data - these would come from your entities in real implementation
  const filterOptions = {
    channels: ["WhatsApp", "Telegram", "Instagram", "Facebook"],
    tags: ["VIP", "Lead", "Support", "Marketing", "Follow-up", "Resolved"],
    users: ["Agent 1", "Agent 2", "Agent 3", "Manager"],
    teams: ["Sales Team", "Support Team", "Marketing Team"]
  };

  const getContactForConversation = (conversation) => {
    return contacts.find(c => c.id === conversation?.contact_id) || {};
  };

  const filterConversationsByTab = (conversationsToFilter, tab) => {
    if (!currentUser) return [];

    // This function now only handles non-concluded conversations
    const nonArchived = conversationsToFilter.filter(c => c.status !== 'concluded');

    switch (tab) {
      case "novos":
        return nonArchived.filter(conv => !conv.assigned_to);
      case "meus":
        return nonArchived.filter(conv => conv.assigned_to === currentUser.id);
      case "outros":
        return nonArchived.filter(conv => conv.assigned_to && conv.assigned_to !== currentUser.id);
      default:
        return nonArchived; // Should not happen with current tabs
    }
  };

  const applyFilters = (conversationsToFilter) => {
    return conversationsToFilter.filter(conversation => {
      const contact = getContactForConversation(conversation);

      // Channel filter
      if (activeFilters.channels.length > 0) {
        // Assuming conversation has a 'channel' field (e.g., "WhatsApp", "Telegram")
        if (!conversation.channel || !activeFilters.channels.includes(conversation.channel)) {
            return false;
        }
      }

      // Tags filter
      if (activeFilters.tags.length > 0) {
        const conversationTags = conversation.tags || []; // Assuming conversation.tags is an array
        const contactTags = contact.tags || [];           // Assuming contact.tags is an array
        const allTags = [...conversationTags, ...contactTags];
        const hasMatchingTag = activeFilters.tags.some(tag => allTags.includes(tag));
        if (!hasMatchingTag) return false;
      }

      // User filter
      if (activeFilters.users.length > 0) {
        // Assuming conversation has an 'assigned_to' field that stores the assigned user's name
        // This needs to be adjusted if assigned_to is an ID and not a name string.
        // For now, assuming filterOptions.users contains names.
        // For real implementation, you'd match by user ID.
        if (!conversation.assigned_to || !activeFilters.users.includes(conversation.assigned_to)) {
            return false;
        }
      }

      // Team filter
      if (activeFilters.teams.length > 0) {
        // Assuming conversation has a `assigned_to_team` property that holds the team name.
        if (!conversation.assigned_to_team || !activeFilters.teams.includes(conversation.assigned_to_team)) {
            return false;
        }
      }

      return true;
    });
  };
  
  // Decide which conversations to start with based on the archive toggle
  const conversationsForDisplay = showArchivedOnly
    ? conversations.filter(c => c.status === 'concluded')
    : filterConversationsByTab(conversations, activeTab);
  
  const filteredByActiveFilters = applyFilters(conversationsForDisplay);

  const finalFilteredConversations = filteredByActiveFilters.filter(conversation => {
    const contact = getContactForConversation(conversation);
    const contactName = contact.name || '';
    const contactPhone = contact.phone || '';
    const lastMessage = conversation.last_message_content || ''; // Use new field
    const query = searchQuery.toLowerCase();

    const matchesSearch = contactName.toLowerCase().includes(query) ||
           contactPhone.toLowerCase().includes(query) ||
           lastMessage.toLowerCase().includes(query);

    const matchesUnread = !showUnreadOnly || (conversation.unread_count && conversation.unread_count > 0);

    // No need for matchesArchived here, as conversationsForDisplay already handled it.

    return matchesSearch && matchesUnread;
  });

  const sortedConversations = [...finalFilteredConversations].sort((a, b) => {
    const dateA = new Date(a.last_message_date);
    const dateB = new Date(b.last_message_date);
    if (sortOrder === "newest") {
      return dateB.getTime() - dateA.getTime();
    }
    return dateA.getTime() - dateB.getTime();
  });

  const handleFilterSelect = (category, value, event) => {
    event.preventDefault();
    event.stopPropagation();
    setActiveFilters(prev => ({
      ...prev,
      [category]: prev[category].includes(value)
        ? prev[category].filter(item => item !== value)
        : [...prev[category], value]
    }));
  };

  const clearFilter = (category, value, event) => {
    event.preventDefault();
    event.stopPropagation();
    setActiveFilters(prev => ({
      ...prev,
      [category]: prev[category].filter(item => item !== value)
    }));
  };

  const clearAllFilters = () => {
    setActiveFilters({
      channels: [],
      tags: [],
      users: [],
      teams: []
    });
  };

  const getRelativeTime = (date) => {
      if (!date) return '';
      try {
        const pastDate = new Date(date);
        return formatRelative(pastDate, new Date());
      } catch(e) {
          return '';
      }
  }
  
  const handleTabClick = (tabId) => {
    setActiveTab(tabId);
    // Clicking a main tab always shows active conversations, so hide archived
    setShowArchivedOnly(false);
  };
  
  const getTabCount = (tabId) => {
    if (!currentUser) return 0;
    const nonArchivedConversations = conversations.filter(c => c.status !== 'concluded');
    switch (tabId) {
      case "novos":
        return nonArchivedConversations.filter(conv => !conv.assigned_to).length;
      case "meus":
        return nonArchivedConversations.filter(conv => conv.assigned_to === currentUser.id).length;
      case "outros":
        return nonArchivedConversations.filter(conv => conv.assigned_to && conv.assigned_to !== currentUser.id).length;
      default:
        return 0;
    }
  }

  // Ensure counts are re-calculated with the updated filter logic
  const tabs = [
    { id: "novos", label: "Novos", count: getTabCount("novos") },
    { id: "meus", label: "Meus", count: getTabCount("meus") },
    { id: "outros", label: "Outros", count: getTabCount("outros") }
  ];

  const totalActiveFilters = Object.values(activeFilters).flat().length;

  return (
    <>
      <div className="p-2 border-b border-gray-200/60">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-gray-900">Conversas</h2>
          <div className="flex items-center gap-1">
            <Button
              variant={showUnreadOnly ? "secondary" : "ghost"}
              size="icon"
              className="w-7 h-7"
              onClick={() => setShowUnreadOnly(!showUnreadOnly)}
              title="Show unread only"
            >
              <Inbox className="w-3.5 h-3.5" />
            </Button>

            <Button
              variant={showArchivedOnly ? "secondary" : "ghost"}
              size="icon"
              className="w-7 h-7"
              onClick={() => {
                setShowArchivedOnly(!showArchivedOnly);
                // When showing archived, reset activeTab to prevent conflicts
                // Or handle tab state carefully with archived state
                if (!showArchivedOnly) { // If turning on archived, ensure no main tab is active conceptually
                  setActiveTab(""); // Clear activeTab state for main tabs
                } else { // If turning off archived, go back to default tab
                  setActiveTab("novos");
                }
              }}
              title="Show archived conversations"
            >
              <Archive className="w-3.5 h-3.5" />
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="w-7 h-7">
                  <ArrowUpDown className="w-3 h-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem
                  onClick={() => setSortOrder('newest')}
                  className={`text-xs justify-between ${sortOrder === 'newest' ? 'text-blue-600 font-medium' : ''}`}
                >
                  Sort by last message date
                  {sortOrder === 'newest' && <div className="w-2 h-2 bg-blue-500 rounded-full" />}
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => setSortOrder('oldest')}
                  className={`text-xs justify-between ${sortOrder === 'oldest' ? 'text-blue-600 font-medium' : ''}`}
                >
                  Sort by oldest message first
                  {sortOrder === 'oldest' && <div className="w-2 h-2 bg-blue-500 rounded-full" />}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative w-7 h-7">
                  <Filter className="w-3 h-3" />
                  {totalActiveFilters > 0 && (
                    <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 flex items-center justify-center text-[9px] bg-blue-500 text-white">
                      {totalActiveFilters}
                    </Badge>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuSub>
                  <DropdownMenuSubTrigger className="text-xs">
                    Channels
                    {activeFilters.channels.length > 0 && (
                      <Badge className="ml-auto h-4 px-1 text-[9px]">
                        {activeFilters.channels.length}
                      </Badge>
                    )}
                  </DropdownMenuSubTrigger>
                  <DropdownMenuSubContent>
                    {filterOptions.channels.map((channel) => (
                      <DropdownMenuItem
                        key={channel}
                        onSelect={(e) => e.preventDefault()}
                        onClick={(e) => handleFilterSelect('channels', channel, e)}
                        className="text-xs justify-between"
                      >
                        <span>{channel}</span>
                        {activeFilters.channels.includes(channel) && (
                          <div className="w-2 h-2 bg-blue-500 rounded-full" />
                        )}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuSubContent>
                </DropdownMenuSub>

                <DropdownMenuSub>
                  <DropdownMenuSubTrigger className="text-xs">
                    Tags
                    {activeFilters.tags.length > 0 && (
                      <Badge className="ml-auto h-4 px-1 text-[9px]">
                        {activeFilters.tags.length}
                      </Badge>
                    )}
                  </DropdownMenuSubTrigger>
                  <DropdownMenuSubContent>
                    {filterOptions.tags.map((tag) => (
                      <DropdownMenuItem
                        key={tag}
                        onSelect={(e) => e.preventDefault()}
                        onClick={(e) => handleFilterSelect('tags', tag, e)}
                        className="text-xs justify-between"
                      >
                        <span>{tag}</span>
                        {activeFilters.tags.includes(tag) && (
                          <div className="w-2 h-2 bg-blue-500 rounded-full" />
                        )}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuSubContent>
                </DropdownMenuSub>

                <DropdownMenuSub>
                  <DropdownMenuSubTrigger className="text-xs">
                    Users
                    {activeFilters.users.length > 0 && (
                      <Badge className="ml-auto h-4 px-1 text-[9px]">
                        {activeFilters.users.length}
                      </Badge>
                    )}
                  </DropdownMenuSubTrigger>
                  <DropdownMenuSubContent>
                    {filterOptions.users.map((user) => (
                      <DropdownMenuItem
                        key={user}
                        onSelect={(e) => e.preventDefault()}
                        onClick={(e) => handleFilterSelect('users', user, e)}
                        className="text-xs justify-between"
                      >
                        <span>{user}</span>
                        {activeFilters.users.includes(user) && (
                          <div className="w-2 h-2 bg-blue-500 rounded-full" />
                        )}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuSubContent>
                </DropdownMenuSub>

                <DropdownMenuSub>
                  <DropdownMenuSubTrigger className="text-xs">
                    Teams
                    {activeFilters.teams.length > 0 && (
                      <Badge className="ml-auto h-4 px-1 text-[9px]">
                        {activeFilters.teams.length}
                      </Badge>
                    )}
                  </DropdownMenuSubTrigger>
                  <DropdownMenuSubContent>
                    {filterOptions.teams.map((team) => (
                      <DropdownMenuItem
                        key={team}
                        onSelect={(e) => e.preventDefault()}
                        onClick={(e) => handleFilterSelect('teams', team, e)}
                        className="text-xs justify-between"
                      >
                        <span>{team}</span>
                        {activeFilters.teams.includes(team) && (
                          <div className="w-2 h-2 bg-blue-500 rounded-full" />
                        )}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuSubContent>
                </DropdownMenuSub>

                {totalActiveFilters > 0 && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={clearAllFilters} className="text-xs text-red-600">
                      Clear All Filters
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Active Filters Display */}
        {totalActiveFilters > 0 && (
          <div className="mb-3">
            <div className="flex flex-wrap gap-1">
              {Object.entries(activeFilters).map(([category, values]) =>
                values.map((value) => (
                  <Badge
                    key={`${category}-${value}`}
                    variant="secondary"
                    className="text-[10px] flex items-center gap-1"
                  >
                    <span>{value}</span>
                    <button
                      onClick={(e) => clearFilter(category, value, e)}
                      className="hover:text-red-500"
                    >
                      <X className="w-2 h-2" />
                    </button>
                  </Badge>
                ))
              )}
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="flex flex-col mb-3 gap-1">
          {/* Main Tabs Row */}
          <div className="flex bg-gray-100 rounded-lg p-0.5">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => handleTabClick(tab.id)}
                className={`flex-1 px-2 py-1.5 rounded-md text-xs font-medium transition-all duration-200 ${
                  activeTab === tab.id && !showArchivedOnly // Only highlight if not showing archived
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
                disabled={showArchivedOnly} // Disable main tabs when archived view is active
              >
                <div className="flex items-center justify-center gap-1">
                  <span>{tab.label}</span>
                  {tab.count > 0 && (
                    <Badge className="h-4 px-1 text-[10px] bg-gray-300 text-gray-700">
                      {tab.count}
                    </Badge>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 text-gray-400 w-3 h-3" />
          <Input
            placeholder="Buscar..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8 h-8 text-xs"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {isLoading ? (
          <div className="p-2 space-y-1">
            {Array(9).fill(0).map((_, i) => (
              <div key={i} className="flex items-center gap-2 p-1.5">
                <Skeleton className="w-7 h-7 rounded-full" />
                <div className="flex-1">
                  <Skeleton className="h-2.5 w-24 mb-1" />
                  <Skeleton className="h-2.5 w-32" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {sortedConversations.map((conversation) => {
              const contact = getContactForConversation(conversation);
              const isSelected = selectedConversation?.id === conversation.id;

              return (
                <div
                  key={conversation.id}
                  onClick={() => onConversationSelect(conversation)}
                  className={`p-2 cursor-pointer transition-colors duration-150 hover:bg-slate-50 ${
                    isSelected ? "bg-blue-50/80 border-l-2 border-blue-600" : "border-l-2 border-transparent"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="relative flex-shrink-0">
                        <div className="w-7 h-7 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center">
                          <span className="text-white font-medium text-xs">
                            {contact.name?.[0]?.toUpperCase() || "?"}
                          </span>
                        </div>
                         {conversation.unread_count > 0 && (
                            <Badge className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[9px] h-3 w-3 flex items-center justify-center p-0 rounded-full">
                              {conversation.unread_count}
                            </Badge>
                        )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline justify-between">
                        <h3 className="font-medium text-xs text-gray-800 truncate pr-1">
                          {contact.name || contact.phone}
                        </h3>
                        <p className="text-[10px] text-gray-400 flex-shrink-0">
                            {getRelativeTime(conversation.last_message_date)}
                        </p>
                      </div>

                      <p className="text-[11px] text-gray-500 truncate">
                        {conversation.last_message_content || "Sem mensagens"}
                      </p>

                      {/* Contact Tags */}
                      {contact.tags && contact.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {contact.tags.slice(0, 2).map((tag, index) => (
                            <Badge
                              key={index}
                              variant="secondary"
                              className="text-[9px] px-1 py-0 h-4 bg-blue-100 text-blue-700"
                            >
                              {tag}
                            </Badge>
                          ))}
                          {contact.tags.length > 2 && (
                            <Badge
                              variant="secondary"
                              className="text-[9px] px-1 py-0 h-4 bg-gray-100 text-gray-600"
                            >
                              +{contact.tags.length - 2}
                            </Badge>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {!isLoading && sortedConversations.length === 0 && (
          <div className="p-6 text-center">
            <p className="text-xs text-gray-500">
              {searchQuery || totalActiveFilters > 0 || showArchivedOnly ? "Nenhuma conversa encontrada" : "Nenhuma conversa ativa"}
            </p>
          </div>
        )}
      </div>
    </>
  );
}
