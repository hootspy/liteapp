
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Save, X } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Contact, CustomField, User } from "@/api/entities";

export default function EditContactForm({ contact, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    name: contact?.name || "",
    phone: contact?.phone || "",
    email: contact?.email || "",
    company: contact?.company || "",
    status: contact?.status || "active",
    tags: contact?.tags || [],
    notes: contact?.notes || "",
    custom_fields: contact?.custom_fields || {}
  });

  const [newTag, setNewTag] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [customFieldDefs, setCustomFieldDefs] = useState([]);

  useEffect(() => {
    const fetchCustomFields = async () => {
      try {
        const user = await User.me();
        if (user.organization_id) {
          const fields = await CustomField.filter({ organization_id: user.organization_id }, "sort_order");
          setCustomFieldDefs(fields);
        }
      } catch (error) {
        console.error("Failed to fetch custom fields", error);
      }
    };
    fetchCustomFields();
  }, []);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleCustomFieldChange = (key, value) => {
    setFormData(prev => ({
      ...prev,
      custom_fields: {
        ...prev.custom_fields,
        [key]: value
      }
    }));
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()]
      }));
      setNewTag("");
    }
  };

  const removeTag = (tagToRemove) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    
    try {
      await Contact.update(contact.id, formData);
      onSave({ ...contact, ...formData });
    } catch (error) {
      console.error("Error updating contact:", error);
    }
    
    setIsSaving(false);
  };
  
  const renderCustomFieldInput = (field) => {
    const value = formData.custom_fields?.[field.integration_key] ?? (field.field_type === 'boolean' ? false : "");

    switch (field.field_type) {
      case 'text':
      case 'currency':
      case 'decimal':
      case 'number':
        return <Input 
                  id={`custom-${field.id}`}
                  type={field.field_type === 'text' ? 'text' : 'number'}
                  value={value}
                  onChange={(e) => handleCustomFieldChange(field.integration_key, e.target.value)} 
                  placeholder={field.default_value || ''}
                  className="text-xs"
               />;
      case 'date':
      case 'time':
      case 'datetime':
        return <Input 
                  id={`custom-${field.id}`}
                  type={field.field_type === 'datetime' ? 'datetime-local' : field.field_type} 
                  value={value}
                  onChange={(e) => handleCustomFieldChange(field.integration_key, e.target.value)} 
                  className="text-xs"
               />;
      case 'boolean':
        return <Switch 
                  id={`custom-${field.id}`}
                  checked={!!value} 
                  onCheckedChange={(checked) => handleCustomFieldChange(field.integration_key, checked)} 
               />;
      default:
        return null;
    }
  };

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-medium text-gray-800">Edit Contact</h4>
        <Button variant="ghost" size="icon" onClick={onCancel}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Name */}
        <div>
          <Label htmlFor="edit-name" className="text-xs">Name</Label>
          <Input
            id="edit-name"
            value={formData.name}
            onChange={(e) => handleInputChange("name", e.target.value)}
            placeholder="Contact name"
            className="text-xs"
            required
          />
        </div>

        {/* Phone */}
        <div>
          <Label htmlFor="edit-phone" className="text-xs">Phone</Label>
          <Input
            id="edit-phone"
            value={formData.phone}
            onChange={(e) => handleInputChange("phone", e.target.value)}
            placeholder="+1234567890"
            className="text-xs"
            required
          />
        </div>

        {/* Email */}
        <div>
          <Label htmlFor="edit-email" className="text-xs">Email</Label>
          <Input
            id="edit-email"
            type="email"
            value={formData.email}
            onChange={(e) => handleInputChange("email", e.target.value)}
            placeholder="contact@company.com"
            className="text-xs"
          />
        </div>

        {/* Company */}
        <div>
          <Label htmlFor="edit-company" className="text-xs">Company</Label>
          <Input
            id="edit-company"
            value={formData.company}
            onChange={(e) => handleInputChange("company", e.target.value)}
            placeholder="Company name"
            className="text-xs"
          />
        </div>

        {/* Status */}
        <div>
          <Label htmlFor="edit-status" className="text-xs">Status</Label>
          <Select value={formData.status} onValueChange={(value) => handleInputChange("status", value)}>
            <SelectTrigger className="text-xs">
              <SelectValue placeholder="Select status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="blocked">Blocked</SelectItem>
              <SelectItem value="archived">Archived</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Tags */}
        <div>
          <Label className="text-xs">Tags</Label>
          <div className="flex gap-2 mb-2">
            <Input
              value={newTag}
              onChange={(e) => setNewTag(e.target.value)}
              placeholder="Add tag..."
              onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
              className="text-xs"
            />
            <Button type="button" onClick={addTag} variant="outline" size="icon" className="w-8 h-8">
              <Plus className="w-3 h-3" />
            </Button>
          </div>
          
          {formData.tags.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {formData.tags.map((tag, index) => (
                <Badge key={index} variant="secondary" className="flex items-center gap-1 text-xs">
                  {tag}
                  <button
                    type="button"
                    onClick={() => removeTag(tag)}
                    className="ml-1 hover:text-red-600"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}
        </div>

        {/* Notes */}
        <div>
          <Label htmlFor="edit-notes" className="text-xs">Notes</Label>
          <Textarea
            id="edit-notes"
            value={formData.notes}
            onChange={(e) => handleInputChange("notes", e.target.value)}
            placeholder="Internal notes..."
            rows={3}
            className="text-xs"
          />
        </div>
        
        {/* Custom Fields */}
        {customFieldDefs.length > 0 && (
          <div>
            <Label className="text-sm font-semibold mb-2 block border-t pt-4">Custom Fields</Label>
            <div className="space-y-4">
              {customFieldDefs.map(field => (
                <div key={field.id} className="flex flex-col">
                  <Label htmlFor={`custom-${field.id}`} className="text-xs mb-1">
                    {field.name}
                    {field.is_required && ' *'}
                  </Label>
                  {renderCustomFieldInput(field)}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Form Actions */}
        <div className="flex gap-2 pt-4">
          <Button type="button" variant="outline" onClick={onCancel} size="sm" className="text-xs">
            Cancel
          </Button>
          <Button type="submit" disabled={isSaving} size="sm" className="text-xs bg-blue-600 hover:bg-blue-700">
            <Save className="w-3 h-3 mr-1" />
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </form>
    </div>
  );
}
