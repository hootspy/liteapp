let actionIdCounter = 1;
const generateActionId = () => `action_${Date.now()}_${actionIdCounter++}`;

export function getDefaultNodeData(actionType) {
  const baseData = { id: generateActionId(), type: actionType, data: {} };
  
  switch (actionType) {
    // Messages
    case 'send_message':
      baseData.data = { message: '' };
      break;
    case 'send_template_message':
      baseData.data = { templateId: '', variables: [] };
      break;
    case 'send_question':
      baseData.data = { question: '', options: [] };
      break;
    case 'send_menu':
      baseData.data = { text: '', menuItems: [] };
      break;

    // Contact
    case 'automation_enroll':
      baseData.data = { automationId: '', action: 'add' };
      break;
    case 'tag_contact':
      baseData.data = { tag: '', action: 'add' };
      break;

    // Conversation
    case 'transfer_conversation':
      baseData.data = { teamId: '' };
      break;
    case 'finish_conversation':
      // No extra data needed
      break;

    // Time
    case 'wait_for_reply':
      baseData.data = { timeout: 60, unit: 'minutes' };
      break;
    case 'wait_time':
      baseData.data = { duration: 5, unit: 'minutes' };
      break;

    // Flow
    case 'condition':
      baseData.data = { conditions: [ { field: '', operator: 'equals', value: '' } ] };
      break;
      
    // Advanced
    case 'set_metadata':
      baseData.data = { key: '', value: '' };
      break;
    case 'send_webhook':
      baseData.data = { url: '', payload: '{}' };
      break;

    default:
      // Generic fallback
      baseData.data = {};
  }
  
  return baseData;
}