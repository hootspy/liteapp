
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Plus, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { CustomField, User } from "@/api/entities"; // Assuming CustomField and User are properly defined entities

export default function ContactForm({ contact, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    name: contact?.name || "",
    phone: contact?.phone || "",
    email: contact?.email || "",
    company: contact?.company || "",
    status: contact?.status || "active",
    tags: contact?.tags || [],
    notes: contact?.notes || "",
    custom_fields: contact?.custom_fields || {} // Initialize custom_fields as a nested object
  });

  const [newTag, setNewTag] = useState("");
  const [customFieldDefs, setCustomFieldDefs] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchCustomFields = async () => {
      setIsLoading(true);
      try {
        const user = await User.me();
        if (user && user.organization_id) { // Ensure user and organization_id exist
          const fields = await CustomField.filter({ organization_id: user.organization_id }, "sort_order");
          setCustomFieldDefs(fields);
        } else {
          setCustomFieldDefs([]); // No organization_id, no custom fields
        }
      } catch (error) {
        console.error("Failed to fetch custom fields", error);
        // Optionally, set an error state here
      } finally {
        setIsLoading(false);
      }
    };
    fetchCustomFields();
  }, []);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCustomFieldChange = (key, value) => {
    setFormData(prev => ({
      ...prev,
      custom_fields: {
        ...prev.custom_fields,
        [key]: value
      }
    }));
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()]
      }));
      setNewTag("");
    }
  };

  const removeTag = (tagToRemove) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData); // Pass the entire formData object directly
  };

  const renderCustomFieldInput = (field) => {
    const value = formData.custom_fields?.[field.integration_key]; // Use optional chaining to safely access
    
    switch (field.field_type) {
      case 'text':
        return <Input 
                  id={`custom-${field.id}`}
                  type="text"
                  value={value || ''} 
                  onChange={(e) => handleCustomFieldChange(field.integration_key, e.target.value)} 
                  placeholder={field.default_value || ''}
               />;
      case 'currency':
      case 'decimal':
      case 'number':
        return <Input 
                  id={`custom-${field.id}`}
                  type="number" // HTML type number for numerical inputs
                  value={value || ''} 
                  onChange={(e) => handleCustomFieldChange(field.integration_key, e.target.value)} 
                  placeholder={field.default_value || ''}
               />;
      case 'date':
        return <Input 
                  id={`custom-${field.id}`}
                  type="date"
                  value={value || ''} 
                  onChange={(e) => handleCustomFieldChange(field.integration_key, e.target.value)} 
               />;
      case 'time':
        return <Input 
                  id={`custom-${field.id}`}
                  type="time"
                  value={value || ''} 
                  onChange={(e) => handleCustomFieldChange(field.integration_key, e.target.value)} 
               />;
      case 'datetime':
        return <Input 
                  id={`custom-${field.id}`}
                  type="datetime-local"
                  value={value || ''} // datetime-local expects "YYYY-MM-DDThh:mm" format
                  onChange={(e) => handleCustomFieldChange(field.integration_key, e.target.value)} 
               />;
      case 'boolean':
        return <Switch 
                  id={`custom-${field.id}`}
                  checked={!!value} // Convert to boolean for Switch component
                  onCheckedChange={(checked) => handleCustomFieldChange(field.integration_key, checked)} 
               />;
      // Add other field types as needed
      default:
        return <p className="text-sm text-red-500">Unsupported field type: {field.field_type}</p>;
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>
            {contact ? "Edit Contact" : "Add New Contact"}
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                placeholder="Contact name"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="phone">Phone *</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                placeholder="+1234567890"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                placeholder="contact@company.com"
              />
            </div>
            
            <div>
              <Label htmlFor="company">Company</Label>
              <Input
                id="company"
                value={formData.company}
                onChange={(e) => handleInputChange("company", e.target.value)}
                placeholder="Company name"
              />
            </div>
          </div>

          {/* Status */}
          <div>
            <Label htmlFor="status">Status</Label>
            <Select value={formData.status} onValueChange={(value) => handleInputChange("status", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="blocked">Blocked</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Tags */}
          <div>
            <Label htmlFor="tags">Tags</Label>
            <div className="flex gap-2 mb-3">
              <Input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder="Add a tag..."
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
              />
              <Button type="button" onClick={addTag} variant="outline">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            
            {formData.tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {formData.tags.map((tag, index) => (
                  <Badge key={index} variant="secondary" className="flex items-center gap-1">
                    {tag}
                    <button
                      type="button"
                      onClick={() => removeTag(tag)}
                      className="ml-1 hover:text-red-600"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Notes */}
          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => handleInputChange("notes", e.target.value)}
              placeholder="Internal notes about this contact..."
              rows={4}
            />
          </div>

          {/* Custom Fields */}
          {!isLoading && customFieldDefs.length > 0 && (
            <div>
              <Label className="text-lg font-semibold mb-4 block border-t pt-4">Custom Information</Label>
              <div className="space-y-4">
                {customFieldDefs.map(field => (
                  <div key={field.id} className={field.field_type === 'boolean' ? 'flex items-center space-x-2' : ''}>
                    <Label htmlFor={`custom-${field.id}`} className={field.field_type === 'boolean' ? 'flex-grow' : 'block'}>
                      {field.name}
                      {field.is_required && ' *'}
                    </Label>
                    {renderCustomFieldInput(field)}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Form Actions */}
          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
              {contact ? "Update Contact" : "Create Contact"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
