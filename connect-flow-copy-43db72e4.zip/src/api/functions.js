import { base44 } from './base44Client';


export const whatsappCallback = base44.functions.whatsappCallback;

export const whatsappWebhook = base44.functions.whatsappWebhook;

export const healthCheck = base44.functions.healthCheck;

export const whatsappConnect = base44.functions.whatsappConnect;

export const whatsappMessages = base44.functions.whatsappMessages;

export const widgetAuth = base44.functions.widgetAuth;

export const widgetMessages = base44.functions.widgetMessages;

export const widgetSendMessage = base44.functions.widgetSendMessage;

export const widgetLogin = base44.functions.widgetLogin;

