import { base44 } from './base44Client';


export const Contact = base44.entities.Contact;

export const Conversation = base44.entities.Conversation;

export const Message = base44.entities.Message;

export const Campaign = base44.entities.Campaign;

export const Chatbot = base44.entities.Chatbot;

export const AIAgent = base44.entities.AIAgent;

export const Team = base44.entities.Team;

export const MessageTemplate = base44.entities.MessageTemplate;

export const ChannelIntegration = base44.entities.ChannelIntegration;

export const Organization = base44.entities.Organization;

export const CustomField = base44.entities.CustomField;

export const ChannelGroup = base44.entities.ChannelGroup;



// auth sdk:
export const User = base44.auth;